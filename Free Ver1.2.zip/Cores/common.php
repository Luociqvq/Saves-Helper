<?php
/*
 * 核心文件
 * Author：Casery
 * Date:2022/1/12
 */
 
error_reporting(E_ALL); ini_set("display_errors", 1);
error_reporting(0);
define('IN_CRONLITE', true);
define('SYSTEM_ROOT', dirname(__FILE__).'/');
define('ROOT', dirname(SYSTEM_ROOT).'/');
define('TEMPLATE_ROOT', ROOT.'/Thinkphp/');
define('SYS_KEY', '86b4ab7d2e16334e45126abb4703f914');

date_default_timezone_set("PRC");
$date = date("Y-m-d H:i:s");
$today = date("Y-m-d");
session_start();

$scriptpath=str_replace('\\','/',$_SERVER['SCRIPT_NAME']);
$sitepath = substr($scriptpath, 0, strrpos($scriptpath, '/'));
$siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].$sitepath.'/';


//检测安装
if (!file_exists(ROOT . '/Cores/config.php')) {
header('Content-type:text/html;charset=utf-8');
echo '
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
    <title>Saves-云功能中心 - 系统错误</title>
</head>
<body>
    <center>
        <h3>
            <font color="red">您还未安装Saves-云功能中心系统,<a href="/Install">点击安装</a>！</font>
        </h3><hr/>
        <small>© 2021 Luoci</small>
    </center>
</body>
</html>';
exit();
}

require SYSTEM_ROOT.'config.php';


if(!isset($port))$port='3306';
//连接数据库
include_once(SYSTEM_ROOT."db.class.php");
$DB=new DB($host,$user,$pwd,$dbname,$port);
$sql = $DB->query("select * from saves_config");

//获取系统配置
while($r = $DB->fetch($sql)){

    $conf[$r['k']] = $r['v'];

}

$password_hash='!@#%!s!';
include SYSTEM_ROOT."function.php";
include SYSTEM_ROOT."member.php";
include SYSTEM_ROOT."pczip.php";

$cloudapi = $conf['cloudapi'];
$wyyapi = $conf['wyyapiurl'];
$stepapi = $conf['stepapiurl'];
$biliapi = $conf['biliapiurl'];
$iqyapi = $conf['iqyapiurl'];


if ($Model == 'blank') {
} elseif (defined("AJAX_INT")) {
    include ROOT . 'Thinkphp/Ajax/' . $View . '.php';
} elseif ($Model == 'index') {
    include ROOT . 'Thinkphp/Index/' . $View . '.php';
} elseif (file_exists(ROOT . 'Thinkphp/' . $Model . '/' . $View . '.php')) {
    include ROOT . 'Thinkphp/' . $Model . '/' . $View . '.php';
} else {
    exit('Thinkphp file not found');
}
?>