<?php
/*
 * 核心函数库
 * Author：Casery
 * Date:2021/12/26
 */

//检测安装
function check_install(){
    if (!file_exists(ROOT . '/Cores/config.php')) {
        error('您还未安装Saves-云功能中心系统,<a href="/Install">点击安装</a>！');
    } else {
		$row = $DB->query("select * from saves_config");
        if (!$row) error('您的Saves-云功能中心系统数据库已损坏，请重新安装！');
    }
}


//报错信息
function error($msg)
{
    $year = date('Y');
    $msg = <<<EOF
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
    <title>Saves-云功能中心 - 系统错误</title>
</head>
<body>
    <center>
        <h3>
            <font color="red">$msg</font>
        </h3><hr/>
        <small>© $year Luoci</small>
    </center>
</body>
</html>
EOF;
    die($msg);
}

//信息弹框
function swwalert($msg, $url = false)
{
    if (!$url) $url = 'javascript:history.back(-1);';
    $msg = <<<EOF
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
    <title>系统提示</title>
</head>
<body>
    <script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
    <script src="/Assets/layer/layer.js"></script>
    <script >
        layer.open({
            content: '{$msg}',
            btn: '确定',
            yes:function(){
                window.location.href='{$url}';
            }
        });
    </script>
</body>
</html>
EOF;
    exit($msg);
}

//截取字符串
function cut_str($string, $sublen, $start =0, $code ='UTF-8'){
	if($code =='UTF-8'){
		$pa ="/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/";
		preg_match_all($pa, $string, $t_string);if(count($t_string[0])- $start > $sublen)return join('', array_slice($t_string[0], $start, $sublen))."...";
		return join('', array_slice($t_string[0], $start, $sublen));
	}else{  
		$start = $start*2;
		$sublen = $sublen*2;
		$strlen = strlen($string);
		$tmpstr ='';
        for ($i = 0; $i < $strlen; $i++) {
            if ($i >= $start && $i < $start + $sublen) {
                if (ord(substr($string, $i, 1)) > 129) {
                    $tmpstr .= substr($string, $i, 2);
                } else {
                    $tmpstr .= substr($string, $i, 1);
                }
            }
            if (ord(substr($string, $i, 1)) > 129) {
                $i++;
            }
        }
		if(strlen($tmpstr)<$strlen ) $tmpstr.="...";
		return $tmpstr;
	}
}

function curl_get($url)
{
$ch=curl_init($url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn; R815T Build/JOP40D) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/4.5 Mobile Safari/533.1');
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
$content=curl_exec($ch);
curl_close($ch);
return($content);
}

//带json_decode的Curl
function curl_jsonget($url,$cookie){
		$curl=curl_init();
		$header = array('Content-Type:'.'application/x-www-form-urlencoded');
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE); 
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE); 
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl,CURLOPT_HTTPHEADER,$headers);
		curl_setopt($curl,CURLOPT_COOKIE,$cookie);
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 1800);
		//curl_setopt($curl, CURLOPT_POST, 1);
        //curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        $output = curl_exec($curl);
        curl_close($curl);
		$output=json_decode($output,true);
        return $output;
		//print_r($output);
}

//创建文件并写入数据
function writefile($fname,$str){
	if($fp=fopen($fname,"w")){
		fputs($fp,$str);
		fclose($fp);
		return false;
	}else{
		return true;
	}
}

//获取用户IP
function real_ip(){
	$ip = $_SERVER['REMOTE_ADDR'];
	if (isset($_SERVER['HTTP_CLIENT_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CLIENT_IP'])) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR']) AND preg_match_all('#\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}#s', $_SERVER['HTTP_X_FORWARDED_FOR'], $matches)) {
		foreach ($matches[0] AS $xip) {
			if (!preg_match('#^(10|172\.16|192\.168)\.#', $xip)) {
				$ip = $xip;
				break;
			}
		}
	}
	return $ip;
}

//判断浏览器PC OR MOBILE
function isMobile() { 
  if (isset($_SERVER['HTTP_X_WAP_PROFILE'])) {
    return true;
  } 
  if (isset($_SERVER['HTTP_VIA'])) { 
    return stristr($_SERVER['HTTP_VIA'], "wap") ? true : false;
  } 
  if (isset($_SERVER['HTTP_USER_AGENT'])) {
    $clientkeywords = array('nokia','sony','ericsson','mot','samsung','htc','sgh','lg','sharp','sie-','philips','panasonic','alcatel','lenovo','iphone','ipod','blackberry','meizu','android','netfront','symbian','ucweb','windowsce','palm','operamini','operamobi','openwave','nexusone','cldc','midp','wap','mobile','MicroMessenger'); 
    if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT']))) {
      return true;
    } 
  } 
  if (isset ($_SERVER['HTTP_ACCEPT'])) { 
    if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html')))) {
      return true;
    } 
  } 
  return false;
}

//毫秒级时间戳
function timestamp(){
    $time = time().rand(100,999);
    return $time;
}

//用户注销登录
function userlogout()
{
    setcookie('user_token', null, 0, '/');
}

//管理员注销登录
function adminlogout()
{
    setcookie('admin_token', null, 0, '/');
}

//判断功能开关状态
function checkjob($num){
	if($num==1){
		return '<span class="text-warning">已使用</span>';
	}else{
		return '<span class="text-success">未使用</span>';
	}	
}

//公告按钮事件
function checkggoff($num){
	if($num==1){
		return 'checked=""';
	}else{
		return '';
	}
}

//判断用户等级
function checkisvip($num){
	if($num==0){
		$zt='普通用户';
	}else{
		$zt='VIP用户';
	}
	return $zt;
}

//判断用户身份等级
function checkuserlevel($power,$vipnum){
	if($power==9 and $vipnum==1){
		$level='平台站长 || VIP用户';
	}elseif($power==9 and $vipnum==0){
		$level='平台站长';
	}elseif($power==0 and $vipnum==1){
		$level='VIP用户';
	}elseif($power==0 and $vipnum==0){
		$level='普通用户';
	}
	return $level;
}

//获取QQ昵称
function get_qqnick($qq)
{
    $html = file_get_contents('http://r.qzone.qq.com/fcg-bin/cgi_get_portrait.fcg?uins='.$qq);
    $nic = explode(',',$html);
    $name = trim(mb_convert_encoding($nic[6], "UTF-8", "GBK"),'"');
    return $name;
}

//连接云端
function connectcloud()
{
	global $cloudapi;
	global $conf;
	$apicode = $conf['apicode'];
	$qq = $conf['web_qq'];
	$version = $conf['version'];
	$url = "$cloudapi/Api/Cloud/connect.php?qq=$qq&apicode=$apicode&version=$version";
	$result = curl_get($url);
	$result = json_decode($result, true);
    return $result;
}

//IP获取城市
function get_ip_city($ip)
{
    $url = 'http://whois.pconline.com.cn/ipJson.jsp?json=true&ip=';
    $city = curl_get($url . $ip);
	$city = mb_convert_encoding($city, "UTF-8", "GB2312");
    $city = json_decode($city, true);
    if ($city['city']) {
        $location = $city['pro'].$city['city'];
    } else {
        $location = $city['pro'];
    }
	if($location){
		return $location;
	}else{
		return false;
	}
}

function send_mail($to, $sub, $msg) {
	global $conf;
	include_once ROOT.'Cores/smtp.class.php';
	$From = $conf['mail_name'];
	$Host = $conf['mail_stmp'];
	$Port = $conf['mail_port'];
	$SMTPAuth = 1;
	$Username = $conf['mail_name'];
	$Password = $conf['mail_pwd'];
	$Nickname = $conf['sitename'];
	$SSL = false;
	$mail = new SMTP($Host , $Port , $SMTPAuth , $Username , $Password , $SSL);
	$mail->att = array();
	if($mail->send($to , $From , $sub , $msg, $Nickname)) {
		return true;
	} else {
		return $mail->log;
	}
}

function daddslashes($string, $force = 0, $strip = FALSE) {
	!defined('MAGIC_QUOTES_GPC') && define('MAGIC_QUOTES_GPC', get_magic_quotes_gpc());
	if(!MAGIC_QUOTES_GPC || $force) {
		if(is_array($string)) {
			foreach($string as $key => $val) {
				$string[$key] = daddslashes($val, $force, $strip);
			}
		} else {
			$string = addslashes($strip ? stripslashes($string) : $string);
		}
	}
	return $string;
}

function getHtmlCode($value, $html = false)
{
    $value = stripslashes($value);
    if ($html) {
        $value = htmlspecialchars($value);
    }
    return $value;
}

function strexists($string, $find) {
	return !(strpos($string, $find) === FALSE);
}

//base16加密
function base16_encode($string)
{
    $encode = '';
    $chars = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'];
    for ($i = 0; $i < strlen($string); $i++) {
        $encode .= $chars[(ord($string[$i]) & 0b11110000) >> 4] . $chars[ord($string[$i]) & 0b00001111];
    }
    return $encode;
}

//base16解码
function base16_decode($encode)
{
    $result = '';
    for ($i = 0; $i < strlen($encode) / 2; $i++) {
        $result .= chr(intval(substr($encode, $i * 2, 2), 16));
    }
    return $result;
}

function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0) {
	$ckey_length = 4;
	$key = md5($key ? $key : ENCRYPT_KEY);
	$keya = md5(substr($key, 0, 16));
	$keyb = md5(substr($key, 16, 16));
	$keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';
	$cryptkey = $keya.md5($keya.$keyc);
	$key_length = strlen($cryptkey);
	$string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;
	$string_length = strlen($string);
	$result = '';
	$box = range(0, 255);
	$rndkey = array();
	for($i = 0; $i <= 255; $i++) {
		$rndkey[$i] = ord($cryptkey[$i % $key_length]);
	}
	for($j = $i = 0; $i < 256; $i++) {
		$j = ($j + $box[$i] + $rndkey[$i]) % 256;
		$tmp = $box[$i];
		$box[$i] = $box[$j];
		$box[$j] = $tmp;
	}
	for($a = $j = $i = 0; $i < $string_length; $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;
		$tmp = $box[$a];
		$box[$a] = $box[$j];
		$box[$j] = $tmp;
		$result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
	}
	if($operation == 'DECODE') {
		if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
			return substr($result, 26);
		} else {
			return '';
		}
	} else {
		return $keyc.str_replace('=', '', base64_encode($result));
	}
}

//随机数
function random($length, $numeric = 0) {
	$seed = base_convert(md5(microtime().$_SERVER['DOCUMENT_ROOT']), 16, $numeric ? 10 : 35);
	$seed = $numeric ? (str_replace('0', '', $seed).'012340567890') : ($seed.'zZ'.strtoupper($seed));
	$hash = '';
	$max = strlen($seed) - 1;
	for($i = 0; $i < $length; $i++) {
		$hash .= $seed[mt_rand(0, $max)];
	}
	return $hash;
}

function showmsg($content = '未知的异常',$type = 4,$back = false)
{
switch($type)
{
case 1:
	$panel="success";
break;
case 2:
	$panel="info";
break;
case 3:
	$panel="warning";
break;
case 4:
	$panel="danger";
break;
}

echo '<div class="panel panel-'.$panel.'">
      <div class="panel-heading">
        <h3 class="panel-title">提示信息</h3>
        </div>
        <div class="panel-body">';
echo $content;

if ($back) {
	echo '<hr/><a href="'.$back.'"><< 返回授权列表</a>';
	echo '<br/><a href="javascript:history.back(-1)"><< 返回上一页</a>';
}
else
    echo '<hr/><a href="javascript:history.back(-1)"><< 返回上一页</a>';

echo '</div>
    </div>';
}

function checkIfActive($string) {
	$array=explode(',',$string);
	$php_self=substr($_SERVER['REQUEST_URI'],strrpos($_SERVER['REQUEST_URI'],'v=')+2);
	if (in_array($php_self,$array)){
		return 'active';
	}else
		return null;
}

//Config数据库保存
function saveSetting($k, $v){
	global $DB;
	$v = daddslashes($v);
	return $DB->query("REPLACE INTO saves_config SET v='$v',k='$k'");
}

//步数任务Function

//获取步数挂机任务
function getstepjob($jobname=null){
    global $DB;
	$sql = "select * from saves_stepjob where jobname='$jobname' and start='1'";
    $result=$DB->query($sql);
    $result=mysqli_fetch_all($result);
    return $result;
}


//网易云任务Function
	
//获取网易云挂机任务
function getwyyjob($jobname=null){
    global $DB;
	$sql = "select * from saves_wyyjob where jobname='$jobname' and start='1'";
    $result=$DB->query($sql);
    $result=mysqli_fetch_all($result);
    return $result;
}


//网易云歌曲打卡
function wyyscrobble($cookie,$sourceid,$times){
	global $wyyapi;
	$url = "$wyyapi/Api/Music/scrobble.php?sourceid=$sourceid&times=$times";
	$output = curl_jsonget($url,$cookie);
	return $output;
}

//网易云云贝访问商城
function yunbeivisitmall($cookie){
	global $wyyapi;
	$url = "$wyyapi/Api/Music/yunbeivisitmall.php";
	$output = curl_jsonget($url,$cookie);
	return $output;
}

//网易云VIP信息
function wyyvipinfo($cookie){
	global $wyyapi;
	$url = "$wyyapi/Api/Music/vipinfo.php";
	$output = curl_jsonget($url,$cookie);
	return $output;
}

?>