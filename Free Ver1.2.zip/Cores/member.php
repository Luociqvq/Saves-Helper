<?php
if(!defined('IN_CRONLITE'))exit();

$clientip = real_ip();
$city = get_ip_city($clientip);
if(isset($_COOKIE["user_token"]))
{
	$token=authcode(daddslashes($_COOKIE['user_token']), 'DECODE', SYS_KEY);
	list($user, $sid) = explode("\t", $token);
	if($userrow = $DB->get_row("select * from saves_user where user='$user' limit 1")){
		$session=md5($userrow['user'].$userrow['pass'].$password_hash);
		if($session==$sid) {
			$isuserlogin=1;
		}
	}
}
?>