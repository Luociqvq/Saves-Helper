<?php
/*
 * 步数运行文件
 * Author：Luoci
 * Date:2022/3/29
 */
 
header('Content-type: application/json');
$Model = 'blank';
include './Cores/common.php';
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;

//添加步数账户		
if($act == 'steplogin') {
	$tellphone = daddslashes($_POST['tellphone']);
	$password = daddslashes($_POST['password']);
	$pwd = base16_encode($password);
	$url = "$stepapi/Api/Step/login.php?tellphone=$tellphone&password=$password";
	$loginoutput = curl_jsonget($url,$cookie);
	$stepuserid = $loginoutput['stepuserid'];
	$stepapptoken = $loginoutput['stepapptoken'];
	$steplogintoken = $loginoutput['steplogintoken'];
    $stepnickname = $loginoutput['stepnickname'];
    $stepavatarUrl = $loginoutput['stepavatarUrl'];
	if(empty($tellphone) and empty($password)) {
		$result = array('status' =>0, 'message' =>'请输入要添加的电话号码或密码');
	}elseif($loginoutput['code'] == 400){
		$result = array('status' =>0, 'message'=>'账户密码错误');
	}elseif($loginoutput['code'] == 200){
		if($DB->get_row("select * from `saves_step` where stepuserid='".$stepuserid."' limit 1")){
			$result = array('status' =>0, 'message'=>'请勿重复绑定步数账户');
		}else{
			$DB->query("insert into `saves_step` (`uid`,`stepuser`,`steppwd`,`stepuserid`,`stepapptoken`,`steplogintoken`,`stepnickname`,`stepavatarUrl`,`addtime`) values ('".$userrow['uid']."','".$tellphone."','".$pwd."','".$stepuserid."','".$stepapptoken."','".$steplogintoken."','".$stepnickname."','".$stepavatarUrl."',Now())");
			$DB->query("insert into `saves_stepjob` (`jobname`,`uid`,`stepuserid`,`type`,`stepapptoken`,`steplogintoken`,`start`,`change`,`lasttime`,`adddate`) values ('stepinfoupdate','".$userrow['uid']."','".$stepuserid."','自动更新','".$stepapptoken."','".$steplogintoken."','1','0',Now(),Now())");
			$result = array('status' =>1, 'message'=>'步数绑定成功');
		}
	}else{
		 $result = array('status' =>0, 'message'=>'登陆失败，请重试');
	}

//添加步数任务
}elseif($act == 'addstepjob'){
    $jobname=daddslashes($_GET['jobname']);
	$stepuserid=daddslashes($_GET['stepuserid']);
	$type=daddslashes($_GET['type']);
	$start=daddslashes($_GET['start']);
	$row = $DB->get_row("select * from saves_step where stepuserid='$stepuserid' and uid='{$userrow['uid']}' limit 1");
	if(empty($jobname) || empty($type)) {
		$result = array('status' =>0, 'message' =>'请重新添加');
	}elseif($DB->get_row("select * from `saves_stepjob` where jobname='".$jobname."' and stepuserid='".$stepuserid."' limit 1")) {
		$DB->query("update `saves_stepjob` set `jobname`='{$jobname}', `type`='{$type}', `start`='{$start}', `lasttime`=Now() where stepuserid='".$stepuserid."' and jobname='".$jobname."'");
		$result = array('status' =>1, 'message' =>'更新任务成功');
	}else{
		$res=$DB->get_row("select * from saves_step where stepuserid='".$stepuserid."' limit 1");
		$DB->query("insert into `saves_stepjob` (`jobname`,`uid`,`stepuserid`,`type`,`stepapptoken`,`steplogintoken`,`start`,`lasttime`,`adddate`) values ('".$jobname."','".$userrow['uid']."','".$stepuserid."','".$type."','".$row['stepapptoken']."','".$row['steplogintoken']."','".$start."',Now(),Now())");
    	$result = array('status' =>1, 'message'=>'恭喜您，添加任务成功');
	}	

//删除步数账号	
}elseif($act == 'deletestep') {
	$stepuserid=daddslashes($_GET['stepuserid']);
	$row = $DB->get_row("select * from saves_step where stepuserid='$stepuserid' and uid='{$userrow['uid']}' limit 1");
	if($row['stepuserid']=='') {
			$result = array('status'=>0, 'message'=>'步数ID不得为空');
		}else{
			$DB->query("delete from `saves_step` where stepuserid = '$stepuserid' and uid='{$userrow['uid']}'");
			$DB->query("delete from `saves_stepjob` where stepuserid = '$stepuserid' and uid='{$userrow['uid']}'");
			if($DB->get_row("select * from `saves_step` where stepuserid='".$stepuserid."' limit 1")) {
				$result = array('status'=>0, 'message'=>'删除账号及挂机任务失败...');
			}else{
				$result = array('status'=>1, 'message'=>'删除账号及挂机任务成功...');
			}
		}

//步数任务设置
}elseif($act == 'stepjobset') {
	$stepuserid = daddslashes($_POST['stepuserid']);
	$startstep = daddslashes($_POST['startstep']);
	$endstep = daddslashes($_POST['endstep']);
	$row = $DB->get_row("select * from saves_step where stepuserid='$stepuserid' and uid='{$userrow['uid']}' limit 1");
	if($row['stepuserid']=='') {
			$result = array('status'=>0, 'message'=>'步数ID不得为空');
	}elseif($startstep>$endstep) {
		$result = array('status'=>0, 'message'=>'请输入正确的步数范围');
	}else{
		$res=$DB->get_row("select * from saves_step where stepuserid='".$stepuserid."' limit 1");
		$DB->query("update `saves_stepjob` set `startstep`='{$startstep}', `endstep`='{$endstep}' where stepuserid='".$stepuserid."' and uid='".$userrow['uid']."'");
    	$result = array('status' =>1, 'message'=>'恭喜您，任务设置成功');
	}	

}else{
	$result = array('status'=>0, 'message'=>'No Act!');
}
echo json_encode($result);