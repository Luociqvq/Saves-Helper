<?php
$Model = 'blank';

include '../Cores/common.php';

if (function_exists("set_time_limit"))
{
	@set_time_limit(0);
}
if (function_exists("ignore_user_abort"))
{
	@ignore_user_abort(true);
}


$payapi = 'https://code.x0i.cc/';

function showalert($msg,$status,$orderid=null){
	echo '<meta charset="utf-8"/><script>alert("'.$msg.'");window.location.href="../index.php?m=User&v=index";</script>';
}