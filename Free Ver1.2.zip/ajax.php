<?php
/*
 * 程序运行文件
 * Author：Luoci
 * Date:2022/1/12
 */
 
header('Content-type: application/json');
$Model = 'blank';
include './Cores/common.php';
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;

//用户注册
if ($act == 'userreg') {
	$user = daddslashes($_POST['username']);
	$pass = daddslashes($_POST['username']);
	$qq = daddslashes($_POST['userqq']);
		if(empty($user) and empty($pass) and empty($qq)) {
			$result = array('status' =>0, 'message' =>'请输入要注册的账号密码或QQ');
		}
		elseif($DB->get_row("select * from `saves_user` where user='".$user."' limit 1")) {
			$result = array('status' =>0, 'message' =>'该用户名已被使用，请使用其他用户名');
		}else{
		if($conf['regmoneyopen']==1){
			$DB->query("insert into `saves_user` (`user`,`pass`,`last`,`dlip`,`active`,`email`,`money`,`city`,`regtime`,`qq`) values ('".$user."','".$pass."',Now(),'".$clientip."',1,'".$qq."@qq.com','".$conf['regmoney']."','".$city."',Now(),'".$qq."')");	
		}else{
			$DB->query("insert into `saves_user` (`user`,`pass`,`last`,`dlip`,`active`,`email`,`city`,`regtime`,`qq`) values ('".$user."','".$pass."',Now(),'".$clientip."',1,'".$qq."@qq.com','".$city."',Now(),'".$qq."')");
		}
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		setcookie("user_token", $token, time() + 604800);
        $result = array('status' =>1, 'message'=>'恭喜您，注册成功');
		}

//用户登录
}elseif($act == 'userlogin') {
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$row = $DB->get_row("select * from saves_user where user='$user' limit 1");
	if($row['user']=='' or $pass != $row['pass']) {
		$result = array('status'=>0, 'message'=>'用户名或密码错误');
	}else{
		//$DB->query("insert into `saves_log` (`uid`,`type`,`qq`,`time`,`ip`,`city`,`data`) values ('".$row['uid']."',1,'".$row['user']."','".$row[qq]."','".$date."','".$clientip."','".$city."','IP:".$clientip."||||登录平台')");
		$DB->query("update `saves_user` set `dlip`='{$clientip}', `city`='{$city}' whree uid='{$row['uid']}'");
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		setcookie("user_token", $token, time() + 604800);
		$result = array('status'=>1, 'message'=>'登录成功');
	}

//用户修改个人信息
}elseif($act == 'editmyinfo') {
	$qq = daddslashes($_POST['qq']);
	$pass = !empty($_POST['pass']) ? daddslashes($_POST['pass']) : $userrow['pass'];
	$sql="update `saves_user` set `qq`='".$qq."', `pass`='".$pass."' where uid='".$userrow['uid']."'";
	if($DB->query($sql)) {
		$result = array('status'=>1, 'message'=>'修改个人信息成功...');
	}else{
		$result = array('status'=>0, 'message'=>'修改个人信息失败...');
	}

//管理员注销登录
}elseif($act == 'adminlogout') {
	adminlogout();
    $result = array('status' =>1, 'message'=>'退出登录成功');

//用户注销登录
}elseif($act == 'userlogout') {
	userlogout();
    $result = array('status' =>1, 'message'=>'退出登录成功');

//添加用户
}elseif($act == 'adduser') {
	$user = daddslashes($_POST['user']);
	$pass = daddslashes($_POST['pass']);
	$qq = daddslashes($_POST['qq']);
	$money = daddslashes($_POST['money']);
	if(empty($user) and empty($pass) and empty($qq)) {
		$result = array('status' =>0, 'message' =>'请输入要添加的账号或密码或QQ');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
		$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}elseif($DB->get_row("select * from `saves_user` where user='".$user."' limit 1")) {
		$result = array('status' =>0, 'message' =>'该用户名已被使用，请使用其他用户名');
	}else{
		$DB->query("insert into `saves_user` (`user`,`pass`,`email`,`regtime`,`active`,`qq`) values ('".$user."','".$pass."',Now(),1,'".$qq."')");
		//$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||添加账号:".$user."')");
  	  $result = array('status' =>1, 'message'=>'恭喜您，添加用户成功');
	}	
	
//后台管理主页统计数据
}elseif($act == 'adminamount') {
	$amount['users']=$DB->count("SELECT count(*) from saves_user");
	$amount['wyys']=$DB->count("SELECT count(*) from saves_wyy");
	$amount['url']=$_SERVER['HTTP_HOST'];
	$amount['vips']=$DB->count("SELECT count(*) from saves_user WHERE vip='1'");
	$amount['img']='<img alt="image" class="b b-3x b-white" src="//q4.qlogo.cn/headimg_dl?dst_uin='.$userrow['qq'].'&spec=100">';
	$amount['qqname']=get_qqnick($userrow['qq']);
	$amount['normaluser']=$DB->count("SELECT count(*) from saves_user WHERE active='1'");
	$amount['normaljob']=$DB->count("SELECT count(*) from saves_wyy WHERE cookiezt='0'");
	$amount['invalidjob']=$DB->count("SELECT count(*) from saves_wyy WHERE cookiezt='1'");
	$result = $amount;

//更改网站设置
}elseif($act == 'webset') {
	$web_title = daddslashes($_POST['web_title']);
	$web_qq = daddslashes($_POST['web_qq']);
	$web_keywords = daddslashes($_POST['web_keywords']);
	$web_description = daddslashes($_POST['web_description']);
	$regmoneyopen = daddslashes($_POST['regmoneyopen']);
	$regmoney = daddslashes($_POST['regmoney']);
	$payapi = daddslashes($_POST['payapi']);
	$paypid = daddslashes($_POST['paypid']);
	$paykey = daddslashes($_POST['paykey']);
	if(empty($web_title) and empty($web_qq) and empty($web_keywords) and empty($web_description) and empty($regmoneyopen) and empty($regmoney) ) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
			$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}else{
		saveSetting('web_title', $web_title);
		saveSetting('web_qq', $web_qq);
		saveSetting('web_keywords', $web_keywords);
		saveSetting('web_description', $web_description);
		saveSetting('regmoneyopen', $regmoneyopen);
		saveSetting('regmoney', $regmoney);
		saveSetting('payapi', $payapi);
		saveSetting('paypid', $paypid);
		saveSetting('paykey', $paykey);
	//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
    $result = array('status' =>1, 'message'=>'恭喜您，网站信息更新成功');
	}
	
	
//更新API设置
}elseif($act == 'apiset') {
	$wyyapiurl = daddslashes($_POST['wyyapiurl']);
	$stepapiurl = daddslashes($_POST['stepapiurl']);
	$biliapiurl = daddslashes($_POST['biliapiurl']);
	$iqyapiurl = daddslashes($_POST['iqyapiurl']);
	$apicode = daddslashes($_POST['apicode']);
	if(empty($wyyapiurl) and empty($stepapiurl) and empty($biliapiurl) and empty($iqyapiurl) and empty($apicode)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
			$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}else{
	saveSetting('wyyapiurl', $wyyapiurl);
	saveSetting('stepapiurl', $stepapiurl);
	saveSetting('biliapiurl', $biliapiurl);
	saveSetting('iqyapiurl', $iqyapiurl);
	saveSetting('apicode', $apicode);
	//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
    $result = array('status' =>1, 'message'=>'恭喜您，更新API成功');
	}

//发布新公告
}elseif($act == 'newgonggao') {
	$active = daddslashes($_POST['active']);
	$title = daddslashes($_POST['title']);
	$content = daddslashes($_POST['content']);
	if(empty($active) and empty($title) and empty($content)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
			$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}else{
		$sql="insert into `saves_gonggao` (`publisher`,`title`,`content`,`type`,`active`,`addtime`) values ('".$userrow['user']."','".$title."','".$content."','1','".$active."',NOW())";
		$DB->query($sql);
	//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
    $result = array('status' =>1, 'message'=>'恭喜您，发布新公告成功');
	}

//编辑公告
}elseif($act == 'editgonggao') {
	$id = daddslashes($_POST['id']);
	$active = daddslashes($_POST['active']);
	$title = daddslashes($_POST['title']);
	$content = daddslashes($_POST['content']);
	if(empty($id) and empty($active) and empty($title) and empty($content)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
			$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}else{
		$sql="update `saves_gonggao` set `publisher`='".$userrow['user']."', `title`='".$title."', `content`='".$content."', `active`='".$active."',`addtime`='".$date."' where id='".$id."'";
		$DB->query($sql);
	//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
    $result = array('status' =>1, 'message'=>'恭喜您，编辑公告成功');
	}
		
//删除公告
}elseif($act == 'deletegonggao') {
	$id = daddslashes($_GET['id']);
	if(empty($id)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
			$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}else{
		$sql="delete from `saves_gonggao` where id = '$id'";
		$DB->query($sql);
		//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
    	$result = array('status' =>1, 'message'=>'恭喜您，删除公告成功');
	}

//更改用户等级身份
}elseif($act == 'edituserpower') {
	$uid = daddslashes($_POST['uid']);
	$vip = daddslashes($_POST['vip']);
	$power = daddslashes($_POST['power']);
	if(empty($uid) and empty($vip) and empty($power)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
			$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}elseif($uid==$userrow['uid']){
			$result = array('status' =>0,'message' =>'请勿操作自己账号');
	}elseif($vip==1 and $power==9){
		$sql="update `saves_user` set `vip`='".$vip."', `power`='".$power."' where uid='".$uid."'";
		$DB->query($sql);
		//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
  		$result = array('status' =>1, 'message'=>'恭喜您，更改用户身份成功');
	}elseif($vip==1 and $power==2){
		$sql="update `saves_user` set `vip`='".$vip."', `power`='0' where uid='".$uid."'";
		$DB->query($sql);
		//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
  		$result = array('status' =>1, 'message'=>'恭喜您，更改用户身份成功');
	}elseif($vip==3 and $power==9){
		$sql="update `saves_user` set `vip`='0', `power`='".$power."' where uid='".$uid."'";
		$DB->query($sql);
		//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
  		$result = array('status' =>1, 'message'=>'恭喜您，更改用户身份成功');
	}elseif($vip==3 and $power==2){
		$sql="update `saves_user` set `vip`='0', `power`='0' where uid='".$uid."'";
		$DB->query($sql);
		//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
  	 	$result = array('status' =>1, 'message'=>'恭喜您，更改用户身份成功');
	}else{
		$result = array('status' =>0, 'message'=>'更改失败');
	}

//删除用户	
}elseif($act == 'userdelete') {
	$uid = daddslashes($_GET['uid']);
	$user = daddslashes($_GET['user']);
	$power = daddslashes($_GET['power']);
	if(!$isuserlogin==1 and !$userrow['power']==9) {
		$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}elseif(empty($uid) and empty($user) and empty($power)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif($power==9) {
		$result = array('status' =>0, 'message' =>'请勿操作平台站长账号');
	}elseif($uid==$userrow['uid']){
		$result = array('status' =>0,'message' =>'请勿操作自己账号');
	}else{
	$sql="delete from `saves_user` where uid = '$uid' and user='$user'";
	$DB->query($sql);
	$sql="delete from `saves_wyy` where uid = '$uid'";
	$DB->query($sql);
	$sql="delete from `saves_wyyjob` where uid = '$uid'";
	$DB->query($sql);
	//日志数据库$DB->query("insert into `auth_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$udata['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||删除用户||||ID:".$id."')");
    $result = array('status' =>1, 'message'=>'恭喜您，用户及其账号与任务删除成功');
	}

//更改用户登陆状态
}elseif($act == 'useractivedo') {
	$uid = daddslashes($_GET['uid']);
	$user = daddslashes($_GET['user']);
	$activedonum = daddslashes($_GET['activedonum']);
	$row = $DB->get_row("select * from saves_user where user='".$user."' and uid='".$uid."' limit 1");
	if(!$isuserlogin==1 and !$userrow['power']==9) {
		$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}elseif($row['power']==9){
		$result = array('status' =>0,'message' =>'你无权限操作平台站长的账号');
	}elseif($uid==$userrow['uid']){
		$result = array('status' =>0,'message' =>'请勿操作自己账号');
	}elseif(empty($uid) and empty($user) and empty($power)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}else{
	$sql="update `saves_user` set `active`='{$activedonum}' where uid='".$uid."' and user='".$user."'";
	$DB->query($sql);
	//日志数据库$DB->query("insert into `auth_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$udata['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||删除用户||||ID:".$id."')");
    $result = array('status' =>1, 'message'=>'恭喜您，更改用户登陆状态');
	}
	
//添加VIP等级
}elseif($act == 'addviplevel') {
	$type = daddslashes($_POST['type']);
	$value = daddslashes($_POST['value']);
	$price = daddslashes($_POST['price']);
	if(empty($type) and empty($value) and empty($price)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
		$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}elseif($DB->get_row("select * from `saves_vip` where value='".$value."' limit 1")) {
		$result = array('status'=>0, 'message'=>'请勿重复添加VIP');
	}else{
		$sql="insert into `saves_vip` (`type`,`value`,`price`) values ('".$type."','".$value."','".$price."')";
		$DB->query($sql);
		//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
    	$result = array('status' =>1, 'message'=>'恭喜您，添加VIP等级成功');
	}

//编辑VIP等级
}elseif($act == 'editviplevel') {
	$id = daddslashes($_POST['id']);
	$type = daddslashes($_POST['type']);
	$value = daddslashes($_POST['value']);
	$price = daddslashes($_POST['price']);
	if(empty($id) and empty($type) and empty($value) and empty($price)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
			$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}else{
		$sql="update `saves_vip` set `type`='".$type."', `value`='".$value."', `price`='".$price."' where id='".$id."'";
		$DB->query($sql);
		//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
    	$result = array('status' =>1, 'message'=>'恭喜您，编辑VIP等级成功');
	}
	
//删除VIP等级
}elseif($act == 'deleteviplevel') {
	$id = daddslashes($_GET['id']);
	if(empty($id)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
			$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}else{
		$sql="delete from `saves_vip` where id = '$id'";
		$DB->query($sql);
		//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
    	$result = array('status' =>1, 'message'=>'恭喜您，删除VIP等级成功');
	}

//编辑用户信息
}elseif($act == 'edituser') {
	$uid = daddslashes($_POST['uid']);
	$user = daddslashes($_POST['user']);
	$pass = daddslashes($_POST['pass']);
	$money = daddslashes($_POST['money']);
	$qq = daddslashes($_POST['qq']);
	if(empty($uid) and empty($user) and empty($pass) and empty($money) and empty($qq)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
			$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}else{
		$sql="update `saves_user` set `user`='".$user."', `pass`='".$pass."', `money`='".$money."', `qq`='".$qq."' where uid='".$uid."'";
		$DB->query($sql);
		//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
    	$result = array('status' =>1, 'message'=>'恭喜您，更改用户信息成功');
	}

//删除网易云账号
}elseif($act == 'wyydelete') {
	$wyyid = daddslashes($_GET['wyyid']);
	$wyyuserid = daddslashes($_GET['wyyuserid']);
	$power = daddslashes($_GET['power']);
	if(!$isuserlogin==1 and !$userrow['power']==9) {
		$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}elseif(empty($wyyid) and empty($wyyuserid) and empty($power)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}else{
	$sql="delete from `saves_wyy` where wyyid = '$wyyid' and wyyuserid='$wyyuserid'";
	$DB->query($sql);
	$sql="delete from `saves_wyyjob` where wyyuserid = '$wyyuserid'";
	$DB->query($sql);
	//日志数据库$DB->query("insert into `auth_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$udata['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||删除用户||||ID:".$id."')");
    $result = array('status' =>1, 'message'=>'恭喜您，删除该网易云账号及其挂机任务成功');
	}

//充值余额
}elseif($act == 'recharge') {
	$money = trim(strip_tags(daddslashes($_POST['money'])));
	if(!$isuserlogin==1) {
		$result = array('status'=>0, 'message'=>'您还未登录，请先登录');
	}elseif(empty($money)) {
		$result = array('status'=>0, 'message'=>'请输入您要充值的金额');
	}elseif(!is_numeric($money) and $money<0) {
		$result = array('status'=>0, 'message'=>'请输入正确的充值金额');
	}else{
	$trade_no=date("YmdHis").mt_rand(111,999);
	$name = $conf['web_title'].'余额充值-'.$money.'元';
	if($DB->query("insert into `saves_pay` (`trade_no`,`name`,`money`,`ip`,`uid`,`addtime`,`status`) values ('".$trade_no."', '".$name."', '".$money."', '".$clientip."', '".$userrow['uid']."', Now(), 0)")) {
		$result = array('status'=>1, 'message'=>'订单提交成功', 'trade_no'=>$trade_no, 'money'=>$money);
	}else{
		$result = array('status'=>0, 'message'=>'订单提交失败');
	}
}

//开通VIP
}elseif($act == 'openvip') {
	$type = daddslashes($_GET['type']);
	$vip = $DB->get_row("select * from saves_vip where type='".$type."' limit 1");
	if(!$isuserlogin==1) {
		$result = array('status'=>0, 'message'=>'您还未登录，请先登录');
	}elseif(empty($type)) {
		$result = array('status'=>0, 'message'=>'请勿非法操作');
	}else{
			if($userrow['money']<$vip['price']) {
				$result = array('status'=>2, 'message'=>'你的余额不足请充值');
			}else{
				if($userrow['vip']==0){
					$vipdate=date("Y-m-d", strtotime("+".$vip['type']." months"));
				}elseif($userrow['vip']==1){
					$vipdate=date("Y-m-d", strtotime("+".$vip['type']." months", strtotime($userrow['vipdate'])));
				}
				$sql="update `saves_user` set `vip`='1', `vipdate`='".$vipdate."' where uid='".$userrow['uid']."'";
				$DB->query($sql);
				$sql="update `saves_user` set `money`=money-'".$vip['price']."' where uid='".$userrow['uid']."'";
				$DB->query($sql);
				//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
  	 			$result = array('status' =>1, 'message'=>'恭喜您，开通VIP'.$vip['value'].'成功');
			}
	}

//更新功能是否需要VIP设置
}elseif($act == 'functionset') {
	$wyyset = daddslashes($_POST['wyyset']);
	$stepset = daddslashes($_POST['stepset']);
	$biliset = daddslashes($_POST['biliset']);
	$iqyset = daddslashes($_POST['iqyset']);
	if(empty($wyyset) and empty($stepset) and empty($biliset) and empty($iqyset)) {
		$result = array('status' =>0, 'message' =>'请确保每项不能为空');
	}elseif(!$isuserlogin==1 and !$userrow['power']==9) {
			$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}else{
	saveSetting('wyyset', $wyyset);
	saveSetting('stepset', $stepset);
	saveSetting('biliset', $biliset);
	saveSetting('iqyset', $iqyset);
	//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
    $result = array('status' =>1, 'message'=>'恭喜您，更新功能设置成功');
	}

//后台在线更新
}elseif($act == 'update') {
	$new = connectcloud();
	if(!$isuserlogin==1 and !$userrow['power']==9) {
			$result = array('status'=>0, 'message'=>'请用平台站长使用本功能');
	}elseif($new['updatecode']==2) {
		$result = array('status'=>0, 'message'=>'现在不需要更新');
	}elseif($new['updatecode']==1) {
		$newfile=$new['updatefile'];//程序更新包
		$ZipFile="../../Update.zip";//下载到的临时文件
		copy($newfile,$ZipFile) or die("无法下载更新包文件！");
		$zip = new ZipArchive;
			if($zip->open('../../Update.zip') && $zip->extractTo('../')){
				$sql=file_get_contents('../../Install/update.sql');//数据库更新包
				$sql = explode(';', $sql);
					$t=0;$e=0;$error='';
						for($i=0;$i<count($sql);$i++){
							if(trim($sql[$i])=='')continue;
							if($DB->query($sql[$i])){
								++$t;
							}else{
								++$e;
								$error.=$DB->error().'<br/>';
							}
						}			
					$e=$e-1;
				$sqlmsg='数据库更新成功。SQL成功'.$t.'句/失败'.$e.'句';
				$result = array('status'=>1, 'message'=>'获取更新成功');
			}else{
				$result = array('status' =>0, 'message'=>'程序解压失败');
			}
	}else{
		//日志文件$DB->query("insert into `saves_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$admins['uid']."',2,'".$date."','".$city."','IP:".$clientip."||||更新网站信息')");
    	$result = array('status' =>0, 'message'=>'在线更新服务器出问题了哦');
	}
	
}else{
	$result = array('status'=>0, 'message'=>'No Act!');
}
echo json_encode($result);