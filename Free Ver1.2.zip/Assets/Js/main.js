saves = {
    ajax: function (url, data, success, fail, dataType = 'json') {
        jQuery.ajax({
            url: url,
            data: data,
            type: (data === null || data === undefined) ? 'get' : 'post',
            cache: false,
            dataType: dataType,
            success: function (data) {
            	if (typeof (success) === 'function') {
                    success(data)
                }
            },
            error: function (data) {
			layer.msg('正在加载...', {icon: 16,time: 500}, function(){
                if (typeof (fail) === 'function') {
                    fail(data)
                } else {
					layer.msg('网络链接错误', {icon: 2,time: 1000});
                }
            });
                
            }
        })
    },
    postData: function (url, parameter, callback, callerror, ajaxType, ajaxTime) {
        ajaxType = ajaxType || "POST";
        ajaxTime = ajaxTime || 60000;
        $.ajax({
            type: ajaxType,
            url: url,
            async: true,
            dataType: 'html',
            timeout: ajaxTime,
            data: parameter,
            success: function (data) {
                if (callback == null) {
                    $("#ajaxshow").html(data);
                    return false;
                } else {
                    callback(data);
                }
            },
            error: function (error) {
                layer.close();
                if (callerror == null) {
                    layer.msg('网络链接错误', {icon: 2,time: 1000});
                } else {
                    callerror(error);
                }
            }
        });
    },
    loading: function(msg, mod) {
		msg = msg || '';
		mod = mod ? true : false;
		if (msg) {
			return layer.msg(msg, {
				icon: 16,
				shadeClose: mod,
				shade: 0.01,
				time: 0,
				skin: 'layui-layer-molv',
			});
		} else {
			return layer.load(0, {
				shadeClose: mod,
				shade: 0.01
			});
		}
	},
    msg: function (msg, time = 2) {
        layer.open({
            content: msg
            , skin: 'msg'
            , time: time
        });
    },
    close: function(index) {
		if (typeof(index) === 'number') {
			layer.close(index);
		} else {
			layer.closeAll();
		}
	},
    amount: function(url,msg) {
		var url = url;
		var msg = msg;
		saves.loading('数据加载中...', false);
        $.ajax({
        	url: url,
        	type: 'post',
        	dataType: 'json',
        	success: function(data) {
        	   Object.keys(data).forEach(function(key){
        		   $('#'+key).html(data[key]);
        	   });
			   saves.close();
			   if(msg!=null){
				   toastr.success(msg);
			   }
        	}
        });
	},
    chongzai: function () {
        $("[data-toggle='tooltip']").tooltip();
        $("[data-toggle='popover']").popover({html: true});
        (function (window, document, $, undefined) {
            $(function () {
                $('[data-scrollable]').each(function () {
                    var element = $(this),
                        defaultHeight = 250;
                    element.slimScroll({
                        height: (element.data('height') || defaultHeight)
                    });
                });
            });
        })(window, document, window.jQuery);
    },
    mode: function (url, bt, se) {
        se ? '' : $("#modal").click();
        var bt = bt || '信息文本';
        var url = url;
        get_url(url, bt);
    },
    gethtml: function (url, paramd, seid, lod, cz) {
        seid = seid || 'bodys';
        saves.ajax(url, null, function (d) {
            $("#" + seid).html(d);
            cz ? saves.chongzai() : '';
            return false
        }, '', '', 'html');
    }
};
	/*** 模态窗口调用 ***/
function get_url(url, bt) {
	$("#biaoti").html(bt);
	$("#showInfo").html("<p style='text-align: center;'><img src='/Assets/View/img/load.gif' height=25></p>");
	saves.postData(
		url, '', function (d) {
			$("#showInfo").html(d);
			saves.chongzai();
			return false
		}, function (d) {
			$("#showInfo").html("<p style='text-align: center;margin:20px auto;'><b>加载失败，请重试</b></p>")
			return false
		}, 'GET'
	);
}
function get_ajax_modal(data, bt) {
	$("#modal").click();
	$("#biaoti").html(bt);
	$("#showInfo").html("<p style='text-align: center;'><img src='/Assets/View/img/load.gif' height=25></p>");
	$("#showInfo").html(data);
	saves.chongzai();
	return false;
}