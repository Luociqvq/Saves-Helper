//添加网易云任务
function wyyjob_add(jobname,wyyuserid,type,start) {
	ajax.get("../../wyyajax.php?act=addwyyjob&jobname="+jobname+"&wyyuserid="+wyyuserid+"&type="+type+"&start="+start, "json", 
		function(data) {
			if (data.status == '1') {
				layer.msg(data.message, {time: 700}, function(){
					window.location.href = './index.php?m=User&v=wyytask&wyyuserid='+wyyuserid+'';
					});
			} else if (data.status == '0') {
				layer.msg(data.message);
			}
		});
	}


//添加步数任务
function stepjob_add(jobname, stepuserid, type, start) {
	ajax.get("../../stepajax.php?act=addstepjob&jobname=" + jobname + "&stepuserid=" + stepuserid + "&type=" + type + "&start=" + start, "json",
	function (data) {
		if (data.status == '1') {
			layer.msg(data.message, {
				time: 700
			}, function () {
				window.location.href = './index.php?m=User&v=steptask&stepuserid=' + stepuserid + '';
			});
		} else if (data.status == '0') {
			layer.msg(data.message);
		} 
	});
}

//删除网易云账号(用户中心)
function deletewyy(wyyuserid) {
	layer.confirm('您确定要删除吗？', {
		btn: ['确认', '取消']
	}, function(index) {
		layer.close(index);
		setTimeout(function() {
			ajax.get("../../wyyajax.php?act=deletewyy&wyyuserid="+wyyuserid, "json", 
			function(data) {
				if (data.status == '1') {
					layer.msg(data.message, {time: 700}, function(){
						window.location.href = './index.php?m=User&v=wyylist';
						});
				} else if (data.status == '0') {
					layer.msg(data.message);
				}
			});
		}, 500);
	});
}

//删除步数账号(用户中心)
function deletestep(stepuserid) {
	layer.confirm('您确定要删除吗？', {
		btn: ['确认', '取消']
	}, function (index) {
		layer.close(index);
		setTimeout(function () {
			ajax.get("../../stepajax.php?act=deletestep&stepuserid=" + stepuserid, "json",
				function (data) {
					if (data.status == '1') {
						layer.msg(data.message, {
							time: 700
						}, function () {
							window.location.href = './index.php?m=User&v=steplist';
						});
					} else if (data.status == '0') {
						layer.msg(data.message);
					}
				});
		}, 500);
	});
}

//删除全部网易云任务
function deletewyyjob(wyyuserid) {
	layer.confirm('您确定要删除吗？', {
		btn: ['确认', '取消']
	}, function(index) {
		layer.close(index);
		setTimeout(function() {
			ajax.get("../../wyyajax.php?act=deletewyyjob&wyyuserid="+wyyuserid, "json", 
			function(data) {
				if (data.status == '1') {
					layer.msg(data.message, {time: 700}, function(){
						window.location.href = './index.php?m=User&v=wyytask&wyyuserid="+wyyuserid';
						});
				} else if (data.status == '0') {
					layer.msg(data.message);
				}
			});
		}, 500);
	});
}

//用户注销登录
function userlogout() {
	ajax.get("../../ajax.php?act=userlogout", "json", 
		function(data) {
			if (data.status == '1') {
				layer.msg(data.message, {time: 700}, function(){
						window.location.href = "./index.php?m=User&v=login";
						});
			} else if (data.status == '0') {
				layer.msg(data.message);
			}
		});
	}
	
//删除用户
function userdelete(uid,user,power)  {
	layer.confirm('您确定要删除吗？', {
		btn: ['确认', '取消']
	}, function(index) {
		layer.close(index);
		setTimeout(function() {
			ajax.get("../../ajax.php?act=userdelete&uid="+uid+"&user="+user+"&power="+power, "json", 
			function(data) {
				if (data.status == '1') {
					layer.msg(data.message, {time: 700}, function(){
						window.location.href = "./index.php?m=Admin&v=userlist";
						});
				} else if (data.status == '0') {
					layer.msg(data.message);
				}
			});
		}, 500);
	});
}

//更改用户登陆状态
function useractivedo(uid,user,activedonum)  {
	ajax.get("../../ajax.php?act=useractivedo&uid="+uid+"&user="+user+"&activedonum="+activedonum, "json", 
		function(data) {
			if (data.status == '1') {
				layer.msg(data.message, {time: 700}, function(){
					window.location.href = "./index.php?m=Admin&v=userlist";
					});
			} else if (data.status == '0') {
				layer.msg(data.message);
			}
		});
	}

//删除网易云账号（管理员）
function wyydelete(wyyid,wyyuserid,power)  {
	layer.confirm('您确定要删除吗？', {
		btn: ['确认', '取消']
	}, function(index) {
		layer.close(index);
		setTimeout(function() {
			ajax.get("../../ajax.php?act=wyydelete&wyyid="+wyyid+"&wyyuserid="+wyyuserid+"&power="+power, "json", 
			function(data) {
				if (data.status == '1') {
					layer.msg(data.message, {time: 700}, function(){
						window.location.href = "./index.php?m=Admin&v=wyylist";
						});
				} else if (data.status == '0') {
					layer.msg(data.message);
				}
			});
		}, 500);
	});
}

//删除VIP等级
function deleteviplevel(id) {
	layer.confirm('您确定要删除吗？', {
		btn: ['确认', '取消']
	}, function (index) {
		layer.close(index);
		setTimeout(function () {
			ajax.get("../../ajax.php?act=deleteviplevel&id=" + id, "json",
				function (data) {
					if (data.status == '1') {
						layer.msg(data.message, {
							time: 700
						}, function () {
							window.location.href = './index.php?m=User&v=viplist';
						});
					} else if (data.status == '0') {
						layer.msg(data.message);
					}
				});
		}, 500);
	});
}

//UserLogin//Reg
function UserLogin() {
	user = $("input[name='user']").val();
	pass = $("input[name='pass']").val();
	layer.msg('正在登录···');
	$.ajax({
		url: "../../ajax.php?act=userlogin",
		type: 'POST',
		dataType: 'json',
		data: {
			user: user,
			pass: pass
		},
		success: function (data) {
			layer.closeAll();
			if (data.status == 1) {
				layer.msg(data.message, { time: 700 }, function () {
					window.location.href = "./index.php?m=User&v=index";
				});
			} else if(data.status == 0) {
				layer.msg(data.message);
			}
		},
	});
}

//User//Reg
function UserReg() {
	user = $("input[name='user']").val();
	pass = $("input[name='pass']").val();
	qq = $("input[name='qq']").val();
	layer.msg('正在注册···');
	$.ajax({
		url: "../../ajax.php?act=userreg",
		type: 'POST',
		dataType: 'json',
		data: {
			user: user,
			pass: pass,
			qq: qq
		},
		success: function (data) {
			layer.closeAll();
			if (data.status == 1) {
				layer.msg(data.message, { time: 700 }, function () {
					window.location.href = "./index.php?m=User&v=index";
				});
			} else {
				layer.msg(data.message);
			}
		},
	});
}

//修改个人信息
function editmyinfo() {
	qq = $("input[name='qq']").val();
	pass = $("input[name='pass']").val();
	if(qq==''){layer.msg('请确保每项不能为空');return false;}
	layer.msg('正在修改信息···');
		$.ajax({
			url: "../../ajax.php?act=editmyinfo",
			type: 'POST',
			dataType: 'json',
			data: {
				qq: qq,pass: pass
			},
			success: function (data) {
				layer.closeAll();
				if (data.status == 1) {
					layer.msg(data.message, {time: 700}, function(){
						window.location.href = "./index.php?m=User&v=account";
						});
				} else {
					layer.msg(data.message);
				}
			},
		});
	}

//发布新公告
function newgonggao() {
	active = $("select[name='active']").val();
	title = $("input[name='title']").val();
	content = $("textarea[name='content']").val();
	layer.msg('正在发布新公告···');
		$.ajax({
			url: "../../ajax.php?act=newgonggao",
			type: 'POST',
			dataType: 'json',
			data: {
				active: active,title: title,content:content
			},
			success: function (data) {
				layer.closeAll();
				if (data.status == 1) {
					layer.msg(data.message, {time: 700}, function(){
						window.location.href = "./index.php?m=Admin&v=gglist";
						});
				} else {
					layer.msg(data.message);
				}
			},
		});
	}

//编辑公告
function editgonggao() {
	id = $("button[name='id']").val();
	active = $("select[name='active']").val();
	title = $("input[name='title']").val();
	content = $("textarea[name='content']").val();
	layer.msg('正在编辑公告···');
		$.ajax({
			url: "../../ajax.php?act=editgonggao",
			type: 'POST',
			dataType: 'json',
			data: {
				id: id,active: active,title: title,content:content
			},
			success: function (data) {
				layer.closeAll();
				if (data.status == 1) {
					layer.msg(data.message, {time: 700}, function(){
						window.location.href = "./index.php?m=Admin&v=gglist";
						});
				} else {
					layer.msg(data.message);
				}
			},
		});
	}

//删除公告
function deletegonggao(id)  {
	layer.confirm('您确定要删除吗？', {
		btn: ['确认', '取消']
	}, function(index) {
		layer.close(index);
		setTimeout(function() {
			ajax.get("../../ajax.php?act=deletegonggao&id="+id, "json", 
			function(data) {
				if (data.status == '1') {
					layer.msg(data.message, {time: 700}, function(){
						window.location.href = "./index.php?m=Admin&v=gglist";
					});
				} else if (data.status == '0') {
					layer.msg(data.message);
				}
			});
		}, 500);
	});
}

//更改用户身份
function edituserpower() {
	uid = $("button[name='uid']").val();
	vip = $("select[name='vip']").val();
	power = $("select[name='power']").val();
	layer.msg('正在更改···');
		$.ajax({
			url: "../../ajax.php?act=edituserpower",
			type: 'POST',
			dataType: 'json',
			data: {
				uid: uid,vip: vip,power: power
			},
			success: function (data) {
				layer.closeAll();
				if (data.status == 1) {
					layer.msg(data.message, {time: 700}, function(){
						window.location.href = "./index.php?m=Admin&v=userlist";
						});
				} else {
					layer.msg(data.message);
				}
			},
		});
	}
	
//编辑用户信息
function edituser() {
	user = $("input[name='user']").val();
	pass = $("input[name='pass']").val();
	qq = $("input[name='qq']").val();
	money = $("input[name='money']").val();
	layer.msg('正在更改···');
	$.ajax({
		url: "../../ajax.php?act=edituser",
		type: 'POST',
		dataType: 'json',
		data: {
			user: user,
			pass: pass,
			qq: qq,
			money: money
		},
		success: function (data) {
			layer.closeAll();
			if (data.status == 1) {
				layer.msg(data.message, {
					time: 700
				}, function () {
					window.location.href = "./index.php?m=Admin&v=userlist";
				});
			} else {
				layer.msg(data.message);
			}
		},
	});
}

//更改网站设置
function webset() {
	web_title = $("textarea[name='web_title']").val();
	web_qq = $("textarea[name='web_qq']").val();
	web_description = $("textarea[name='web_description']").val();
	web_keywords = $("textarea[name='web_keywords']").val();
	regmoneyopen = $("select[name='regmoneyopen']").val();
	regmoney = $("input[name='regmoney']").val();
	payapi = $("input[name='payapi']").val();
	paypid = $("input[name='paypid']").val();
	paykey = $("input[name='paykey']").val();
	layer.msg('正在更改网站设置···');
	$.ajax({
		url: "../../ajax.php?act=webset",
		type: 'POST',
		dataType: 'json',
		data: {
			web_title: web_title,
			web_qq: web_qq,
			web_description: web_description,
			web_keywords: web_keywords,
			regmoneyopen: regmoneyopen,
			regmoney: regmoney,
			payapi: payapi,
			paypid: paypid,
			paykey: paykey
		},
		success: function (data) {
			layer.closeAll();
			if (data.status == 1) {
				layer.msg(data.message, {
					time: 700
				}, function () {
					window.location.href = "./index.php?m=Admin&v=webset";
				});
			} else {
				layer.msg(data.message);
			}
		},
	});
}

//更改API设置
function apiset() {
	wyyapiurl = $("input[name='wyyapiurl']").val();
	stepapiurl = $("input[name='stepapiurl']").val();
	biliapiurl = $("input[name='biliapiurl']").val();
	iqyapiurl = $("input[name='iqyapiurl']").val();
	apicode = $("input[name='apicode']").val();
	layer.msg('正在更改网站设置···');
	$.ajax({
		url: "../../ajax.php?act=apiset",
		type: 'POST',
		dataType: 'json',
		data: {
			wyyapiurl: wyyapiurl,
			stepapiurl: stepapiurl,
			biliapiurl: biliapiurl,
			iqyapiurl: iqyapiurl,
			apicode: apicode
		},
		success: function (data) {
			layer.closeAll();
			if (data.status == 1) {
				layer.msg(data.message, {
					time: 700
				}, function () {
					window.location.href = "./index.php?m=Admin&v=apiset";
				});
			} else {
				layer.msg(data.message);
			}
		},
	});
}

//添加网易云账户
function addwyy() {
	tellphone = $("input[name='tellphone']").val();
	password = $("input[name='password']").val();
		layer.msg('正在添加账号···');
			$.ajax({
				url: "../../wyyajax.php?act=wyylogin",
				type: 'POST',
				dataType: 'json',
				data: {
                    tellphone: tellphone,password: password
                },
				success: function (data) {
					if (data.status == 1) {
						layer.msg(data.message, {time: 900}, function(){
							window.location.href = "./index.php?m=User&v=wyylist";
							});
					} else {
						layer.msg(data.message);
					}
				},
			});
		}

//添加步数账户
function addstep() {
	tellphone = $("input[name='tellphone']").val();
	password = $("input[name='password']").val();
	layer.msg('正在添加账号···');
	$.ajax({
		url: "../../stepajax.php?act=steplogin",
		type: 'POST',
		dataType: 'json',
		data: {
			tellphone: tellphone,
			password: password
		},
		success: function (data) {
			if (data.status == 1) {
				layer.msg(data.message, {
					time: 900
				}, function () {
					window.location.href = "./index.php?m=User&v=steplist";
				});
			} else {
				layer.msg(data.message);
			}
		},
	});
}

//添加用户
function adduser() {
	user = $("input[name='user']").val();
	pass = $("input[name='pass']").val();
	qq = $("input[name='qq']").val();
	money = $("input[name='money']").val();
	layer.msg('正在添加···');
	$.ajax({
		url: "../../ajax.php?act=adduser",
		type: 'POST',
		dataType: 'json',
		data: {
			user: user,
			pass: pass,
			qq: qq,
			money: money
		},
		success: function (data) {
			layer.closeAll();
			if (data.status == 1) {
				layer.msg(data.message, {
					time: 700
				}, function () {
					window.location.href = "./index.php?m=Admin&v=userlist";
				});
			} else {
				layer.msg(data.message);
			}
		},
	});
}

//开通VIP
function openvip(type) {
	ajax.get("../../ajax.php?act=openvip&type=" + type, "json",
		function (data) {
			if (data.status == '1') {
				layer.msg(data.message, {
					time: 700
				}, function () {
					window.location.href = './index.php?m=User&v=openvip';
				});
			} else if (data.status == '0') {
				layer.msg(data.message);
			} else if (data.status == '2') {
				layer.open({
					content: '<div class=\"text-center\"><span>余额不足，请先充值</span></div>',
					btn: ['充 值', '取 消'],
					shadeClose: false,
					yes: function (index) {
						layer.close(index);
						saves.mode('./index.php?m=User&v=recharge', '充值余额');
					},
					no: function (index) {
						layer.close(index);
					}
				});
			}
		});
}

//添加VIP等级
function addviplevel() {
	type = $("input[name='type']").val();
	value = $("input[name='value']").val();
	price = $("input[name='price']").val();
	layer.msg('正在编辑···');
	$.ajax({
		url: "../../ajax.php?act=addviplevel",
		type: 'POST',
		dataType: 'json',
		data: {
			type: type,
			value: value,
			price: price
		},
		success: function (data) {
			layer.closeAll();
			if (data.status == 1) {
				layer.msg(data.message, {
					time: 700
				}, function () {
					window.location.href = "./index.php?m=Admin&v=viplist";
				});
			} else {
				layer.msg(data.message);
			}
		},
	});
}

//编辑VIP等级
function editviplevel() {
	id = $("button[name='id']").val();
	type = $("input[name='type']").val();
	value = $("input[name='value']").val();
	price = $("input[name='price']").val();
	layer.msg('正在编辑···');
	$.ajax({
		url: "../../ajax.php?act=editviplevel",
		type: 'POST',
		dataType: 'json',
		data: {
			id: id,
			type: type,
			value: value,
			price: price
		},
		success: function (data) {
			layer.closeAll();
			if (data.status == 1) {
				layer.msg(data.message, {
					time: 700
				}, function () {
					window.location.href = "./index.php?m=Admin&v=viplist";
				});
			} else {
				layer.msg(data.message);
			}
		},
	});
}

//更改功能是否需要VIP
function functionset() {
	wyyset = $("select[name='wyyset']").val();
	biliset = $("select[name='biliset']").val();
	stepset = $("select[name='stepset']").val();
	iqyset = $("select[name='iqyset']").val();
	layer.msg('正在编辑···');
	$.ajax({
		url: "../../ajax.php?act=functionset",
		type: 'POST',
		dataType: 'json',
		data: {
			wyyset: wyyset,
			biliset: biliset,
			stepset: stepset,
			iqyset: iqyset
		},
		success: function (data) {
			layer.closeAll();
			if (data.status == 1) {
				layer.msg(data.message, {
					time: 700
				}, function () {
					window.location.href = "./index.php?m=Admin&v=functionset";
				});
			} else {
				layer.msg(data.message);
			}
		},
	});
}

//步数任务设置
function stepjobset() {
	stepuserid = $("button[name='stepuserid']").val();
	startstep = $("input[name='startstep']").val();
	endstep = $("input[name='endstep']").val();
	layer.msg('正在编辑···');
	$.ajax({
		url: "../../stepajax.php?act=stepjobset",
		type: 'POST',
		dataType: 'json',
		data: {
			stepuserid: stepuserid,
			startstep: startstep,
			endstep: endstep
		},
		success: function (data) {
			layer.closeAll();
			if (data.status == 1) {
				layer.msg(data.message, {
					time: 700
				}, function () {
					window.location.href = "./index.php?m=User&v=steptask&stepuserid=" + stepuserid;
				});
			} else {
				layer.msg(data.message);
			}
		},
	});
	}