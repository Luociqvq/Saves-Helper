$(document).ready(function(){
	layer.closeAll();
});
