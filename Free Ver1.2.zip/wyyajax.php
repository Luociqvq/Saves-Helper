<?php
/*
 * 网易云运行文件
 * Author：Luoci
 * Date:2022/1/12
 */
 
header('Content-type: application/json');
$Model = 'blank';
include './Cores/common.php';
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;

//添加网易云任务		
if($act == 'addwyyjob') {
	$jobname=daddslashes($_GET['jobname']);
	$wyyuserid=daddslashes($_GET['wyyuserid']);
	$type=daddslashes($_GET['type']);
	$start=daddslashes($_GET['start']);
	if(empty($jobname) || empty($type)) {
		$result = array('status' =>0, 'message' =>'请重新添加');
	}elseif($DB->get_row("select * from `saves_wyyjob` where jobname='".$jobname."' and wyyuserid='".$wyyuserid."' limit 1")) {
		$DB->query("update `saves_wyyjob` set `jobname`='{$jobname}', `type`='{$type}', `start`='{$start}', `lasttime`=Now() where wyyuserid='".$wyyuserid."' and jobname='".$jobname."'");
		$result = array('status' =>1, 'message' =>'更新任务成功');
	}else{
		$res=$DB->get_row("select * from saves_wyy where wyyuserid='".$wyyuserid."' limit 1");
		$DB->query("insert into `saves_wyyjob` (`jobname`,`uid`,`wyyuserid`,`type`,`start`,`MUSIC_U`,`__csrf`,`lasttime`,`adddate`) values ('".$jobname."','".$userrow['uid']."','".$wyyuserid."','".$type."','".$start."','".$res['MUSIC_U']."','".$res['__csrf']."',Now(),Now())");
    	$result = array('status' =>1, 'message'=>'恭喜您，添加任务成功');
	}	

//网易云账号登录
}elseif($act == 'wyylogin') {
	$tellphone = daddslashes($_POST['tellphone']);
	$password = daddslashes($_POST['password']);
	$pwd = base16_encode($password);
	$url = "$wyyapi/Api/Music/login.php?uin=$tellphone&pwd=$password";
	$loginoutput = curl_jsonget($url,$cookie);
	$wyyuserid = $loginoutput['wyyuserid'];
	$wyyavatarUrl = $loginoutput['wyyavatarUrl'];
	$wyynickname = $loginoutput['wyynickname'];
	$wyysignature = $loginoutput['wyysignature'];
	$MUSIC_U = $loginoutput['MUSIC_U'];
	$__csrf = $loginoutput['__csrf'];
	//$cookie = $loginoutput['cookie'];
	$levelurl = "$wyyapi/Api/Music/level.php";
	$cookie = "__csrf=".$__csrf.";MUSIC_U=".$MUSIC_U."";
	$leveloutput = curl_jsonget($levelurl,$cookie);	
	$wyylevel = $leveloutput['data']['level'];
	$wyyleveldays =$leveloutput['data']['nextLoginCount'] - $leveloutput['data']['nowLoginCount']; 
	$wyylevelsongs = $leveloutput['data']['nextPlayCount'] - $leveloutput['data']['nowPlayCount'];
	//print_r($levelurl);
	if(empty($tellphone) and empty($password)) {
			$result = array('status' =>0, 'message' =>'请输入要添加的电话号码或密码');
	}elseif($loginoutput['code'] == 502){
		$result = array('status' =>0, 'message'=>'账号密码错误');
	}elseif($loginoutput['code'] == 400){
		$result = array('status' =>0, 'message'=>'网易云中暂无此账号');
	}elseif($loginoutput['code'] == 250){
		$result = array('status' =>0, 'message'=>'请稍等片刻再添加网易云');
	}elseif($loginoutput['code'] == 200){
		if($DB->get_row("select * from `saves_wyy` where wyyuserid='".$wyyuserid."' limit 1")){
			$result = array('status' =>0, 'message'=>'请勿重复绑定网易云');
		}else{
			$DB->query("insert into `saves_wyy` (`uid`,`tellphone`,`password`,`wyyuserid`,`MUSIC_U`,`__csrf`,`wyylevel`,`wyyleveldays`,`wyylevelsongs`,`wyynickname`,`wyysignature`,`wyyavatarUrl`,`addtime`) values ('".$userrow['uid']."','".$tellphone."','".$pwd."','".$wyyuserid."','".$MUSIC_U."','".$__csrf."','".$wyylevel."','".$wyyleveldays."','".$wyylevelsongs."','".$wyynickname."','".$wyysignature."','".$wyyavatarUrl."',Now())");
			$DB->query("insert into `saves_wyyjob` (`jobname`,`uid`,`wyyuserid`,`type`,`start`,`change`,`MUSIC_U`,`__csrf`,`lasttime`,`adddate`) values ('wyyinfoupdate','".$userrow['uid']."','".$wyyuserid."','自动更新','1','0','".$MUSIC_U."','".$__csrf."',Now(),Now())");
			$result = array('status' =>1, 'message'=>'网易云绑定成功');
		}
	}else{
		 $result = array('status' =>0, 'message'=>'登陆失败，请重试');
	}

//删除网易云账号	
}elseif($act == 'deletewyy') {
	$wyyuserid=daddslashes($_GET['wyyuserid']);
	$row = $DB->get_row("select * from saves_wyy where wyyuserid='$wyyuserid' and uid='{$userrow['uid']}' limit 1");
	if($row['wyyuserid']=='') {
			$result = array('status'=>0, 'message'=>'网易云ID不得为空');
		}else{
			$DB->query("delete from `saves_wyy` where wyyuserid = '$wyyuserid' and uid='{$userrow['uid']}'");
			$DB->query("delete from `saves_wyyjob` where wyyuserid = '$wyyuserid' and uid='{$userrow['uid']}'");
			if($DB->get_row("select * from `saves_wyy` where wyyuserid='".$wyyuserid."' limit 1")) {
				$result = array('status'=>0, 'message'=>'删除账号及挂机任务失败...');
			}else{
				$result = array('status'=>1, 'message'=>'删除账号及挂机任务成功...');
			}
		}
}else{
	$result = array('status'=>0, 'message'=>'No Act!');
}
echo json_encode($result);