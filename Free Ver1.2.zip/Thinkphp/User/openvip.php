<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='开通VIP';
include TEMPLATE_ROOT.'User/head.php';
?>
            <div class="wrapper">
                <div class="col-lg-8 col-md-12 col-lg-offset-2 text-center">
					<div class="panel panel-info">
						<div class="panel-heading bg-primary info" >
                           <span class="panel-heading-title">开通VIP</span>
			
						</div>
						<div class="panel-body">
							<table class="table table-hover table-striped">
							<thead>
							<tr>
								<th class="text-center">开通时间</th>
								<th class="text-center">价格</th>
								<th class="text-center">操作</th>
							</tr>
							</thead>
							<tbody>
								<?php
									$rs=$DB->query("select * from saves_vip");
										while($res = $DB->fetch($rs))
											{
											echo'<tr>
												<td class="text-center">
													<div class="h5 text-uppercase"><strong>'.$res['value'].'</strong></div>
												</td>
												<td class="text-center"><h5><font color="#51c6ea">'.$res['price'].' </font> 元</h5></td>
												<td class="text-center"><a class="btn bg-info btn-outline btn-rounded" onclick="openvip(\''.$res['type'].'\')"><font color="white">立即开通<font></a></td>
												</tr>';
											}
									?>
							</tbody>
							</table>
							<hr>
							<div class="text-center">
								<small style="color:#999;">系统24小时自动处理，自动开通，无需等待。</small>
							</div>
						</div>
					</div>
				</div>
            </div>
                	 <div class="col-lg-12 col-md-12" style="overflow:hidden;"></div>
                </div>
            </div>
        </div>
	</section>
</div>
<?php include 'footer.php'; ?>
