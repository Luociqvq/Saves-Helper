<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='用户中心';
include TEMPLATE_ROOT.'User/head.php';
$users=$DB->count("SELECT count(*) from saves_user WHERE 1");
$wyys=$DB->count("SELECT count(*) from saves_wyyjob WHERE 1");
$isadd=$DB->get_row("select * from `saves_wyy` where uid='".$userrow['uid']."' limit 1");
$mywyys=$DB->count("SELECT count(*) from saves_wyy WHERE uid='".$userrow['uid']."'");
$mytasks=$DB->count("SELECT count(*) from saves_wyyjob WHERE uid='".$userrow['uid']."' and start='1' ");
?>
					<div class="wrapper">                  
                        <div class="col-lg-4 col-md-12">
                            <div class="panel b-a" draggable="true">
                                <div class="panel-heading bg-info dk no-border wrapper-lg"></div>
                                <div class="text-center m-b clearfix">
                                    <div class="thumb-lg avatar m-t-n-xl">
                                        <img alt="image" class="b b-3x b-white"src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['qq']?>&spec=100">
                                    </div>
                                    <div class="h4 font-thin m-t-sm"><?=$userrow['user']?></div>
                                    <span class="text-muted text-xs block">UID:<?=$userrow['uid']?> &nbsp; 用户身份：<?php echo checkuserlevel($userrow['power'],$userrow['vip']); ?></span>
                                </div>
                                <ul class="list-group no-radius alt">
								<?php if($userrow['vip']==1){?>
									<a href="recharge.php" class="list-group-item" >
										<span class="badge bg-info"><?=$userrow['vipdate']?></span>
										<i class="fa fa-jpy fa-fw text-muted"></i> 
										VIP到期时间 ：
									</a>
								<?php }else{ ?>
								<?php }?>
									<li class="list-group-item">
										<span class="badge bg-info"><?=$userrow['qq']?> | <?php echo get_qqnick($userrow['qq']); ?></span>
										<i class="fa fa-asterisk fa-fw text-muted"></i> 
										您的绑定QQ
									</li>
									<a href="./index.php?m=User&v=wyylist" class="list-group-item" >
										<span class="badge bg-info"><?=$mywyys?></span>
										<i class="fa fa-music fa-fw text-muted"></i> 
										已绑定网易云账户 ：
									</a>
                                </ul>
                                <div class="btn-group btn-group-justified">
                                    <a class="btn btn-primary" href="javascript:;" onclick="saves.mode('./index.php?m=User&v=addwyy','添加网易云挂机');">添加网易云挂机</a>
                                    <a href="./index.php?m=User&v=wyylist" class="btn btn-info" >网易云账号管理</a>
                                    <a href="javascript:;" onclick="layer.msg('正在更新中...')" class="btn btn-success" >API调用</a>
                                </div>
                            </div>
                        </div>
                         
                        <div class="col-lg-4 col-md-12"> 
                                <div class="panel panel-info">
                                <div class="panel-heading font-bold">平台公告</div>
                                <div class="list-group no-radius alt" id="gonggao"></div> 
                            </div> 
                        </div>
						
					<div class="col-lg-4 col-md-12">
						<div class="panel panel-info">
							<div class="panel-heading font-bold">本站数据统计</div>
							<div class="panel-body text-center">
								<div class="col-sm-6">
									<div class="block panel padder-v bg-primary item">
										<span class="text-white font-thin h1 block"><?=$users?></span>
										<span class="text-muted text-xs">注册会员数</span>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="block panel padder-v bg-info item">
										<span class="text-white font-thin h1 block"><?=$wyys?></span>
										<span class="text-muted text-xs">网易云挂机</span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-12 col-md-12" style="overflow:hidden;"></div>
                </div>
            </div>
        </div>
	</section>
</div>
<?include("footer.php");?>