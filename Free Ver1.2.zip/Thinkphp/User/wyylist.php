<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='网易云账号管理';
include TEMPLATE_ROOT.'User/head.php';
$myaccount=$DB->count("SELECT count(*) from saves_wyy where uid='".$userrow['uid']."'");

?>
				<div class="wrapper">
					<div class="col-sm-12">
						<div class="panel panel-info">
							<div class="panel-heading bg-primary info font-bold">
								网易云账户列表
							</div>
							<div class="row wrapper">
								<div class="col-sm-12">
									<a href="javascript:;" onclick="saves.mode('./index.php?m=User&v=addwyy','添加网易云挂机');" class="btn btn-sm btn-dark m-l-xs" data-pjax>
									<i class="fa fa-plus"></i> 添加网易云</a>
									<?php if (isMobile()){?>
									<div class="row wrapper">
										<?php
											$rs=$DB->query("select * from saves_wyy where uid='".$userrow['uid']."' order by wyyid desc");
												$mytasks=$DB->count("SELECT count(*) from saves_wyyjob where uid='".$userrow['uid']."'");
													while($res = $DB->fetch($rs))
														{
															if($res['cookiezt']==0){
																$active='<font class="text-success m0">正常运行';
															}elseif($res['cookiezt']==1){
																$active='<font class="text-danger m0">账户失效';
															}
															echo'<div class="list-group-item">
																	<a class="pull-left thumb-sm avatar m-r" href="./index.php?m=User&v=wyytask&wyyuserid='.$res['wyyuserid'].'" data-pjax=""><img src="'.$res['wyyavatarUrl'].'"><i class="on b-white bottom"></i></a>
																<div class="btn-group dropdown pull-right m-t-xs">
																	<button type="button" class="btn btn-info" data-toggle="dropdown">设置 <span class="caret"></span></button>
																	<ul class="dropdown-menu">
																		<li><a href="javascript:;" onclick="saves.mode(\'./index.php?m=User&v=addwyy\',\'添加网易云挂机\');">更新</a></li>
																		<li><a href="javascript:;" onclick="deletewyy(\''.$res['wyyuserid'].'\')">删除</a></li>
																		<li><a href="./index.php?m=User&v=wyytask&wyyuserid='.$res['wyyuserid'].'">设置</a></li>
																	</ul>
																</div>
																<strong class="text-primary"><i class="fa fa-circle text-info"></i>'.$res['wyynickname'].'</strong> [<span>'.$active.'</span>]
																<p class="m-t-xs">
																	<small class="text-muted clear text-ellipsis"><i class="fa fa-clock-o"></i> '.$res['addtime'].'</small>
																</p>';
														}
													?>
									</div>
									<?php }else{?>
									<div class="row wrapper">
										<div class="table-responsive">
											<table class="table table-striped b-t b-light">
												<thead>
													<tr>
														<th>头像</th>
														<th>网易云ID</th>
														<th>网易云账户名</th>
														<th>账户状态</th>
														<th class="text-center">添加时间</th>
														<th class="text-right">操作</th>
													</tr>
												</thead>
												<tbody>
													<?php
														$rs=$DB->query("select * from saves_wyy where uid='".$userrow['uid']."' order by wyyid desc");
														$mytasks=$DB->count("SELECT count(*) from saves_wyyjob where uid='".$userrow['uid']."'");
														while($res = $DB->fetch($rs))
														{
															if($res['cookiezt']==0){
																$active='<font class="text-success m0">正常运行';
															}elseif($res['cookiezt']==1){
																$active='<font class="text-danger m0">账户失效';
															}
														echo'<tr>
															<td><img alt="image" class="img-full b b-3x b-white" src="'.$res['wyyavatarUrl'].'" style="width:40px"></td>
															<td>'.$res['wyyuserid'].'</td>
															<td>'.$res['wyynickname'].'</td>
															<td>'.$active.'</td>
															<td class="text-center">'.$res['addtime'].'</td>
															<td class="text-right"><a href="./index.php?m=User&v=wyytask&wyyuserid='.$res['wyyuserid'].'" class="btn btn-sm btn-info">编辑详情</a></td>
															</tr>';
														}
													?>
												</tbody>
											</table>
										</div>
									</div>
									<?php }?>
								</div>
							</div>

						</div>
					</div>
				</div>
				                <div class="col-lg-12 col-md-12" style="overflow:hidden;"></div>
                </div>
            </div>
        </div>
	</section>
</div>
<?php include 'footer.php'; ?>
