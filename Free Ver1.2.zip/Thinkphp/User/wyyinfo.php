<?php
$wyyuserid = $_GET['wyyuserid'];
$wyy=$DB->get_row("select * from saves_wyy where wyyuserid='".$wyyuserid."' limit 1");
if($wyy==''){
	exit("<script language='javascript'>layer.msg('请先绑定网易云账户....', {icon:2}, function(){window.location.href='./index.php?m=User&v=wyylist'});</script>");
}
?>
<div class="panel-body">
	<center>
		<li class="list-group-item"><img src="<?=$wyy['wyyavatarUrl']?>" alt="Avatar" width="60" height="60" style="border:1px solid #FFF;-moz-box-shadow:0 0 3px #AAA;-webkit-box-shadow:0 0 3px #AAA;border-radius:50%;box-shadow:0 0 3px #AAA;padding:3px;margin-right:3px;margin-left:6px">&nbsp;&nbsp;</li>
	</center>
	<li class="list-group-item">网易云ID：<font color="green"><?=$wyy['wyyuserid']?></font> &nbsp;</li>
	<li class="list-group-item">网易云用户名：<font color="green"><?=$wyy['wyynickname']?></font> &nbsp;</li>
	<li class="list-group-item">网易云个性签名：<font color="green"><?=$wyy['wyysignature']?></font> &nbsp;</li>
	<li class="list-group-item">网易云等级：<font color="green"><?=$wyy['wyylevel']?></font> &nbsp;</li>
	<li class="list-group-item">还需登录天数：<font color="green"><?=$wyy['wyyleveldays']?></font> &nbsp;</li>
	<li class="list-group-item">还需听歌：<font color="green"><?=$wyy['wyylevelsongs']?></font> &nbsp;</li>
</div>