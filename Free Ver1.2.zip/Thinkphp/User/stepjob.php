<?php
$stepuserid = $_GET['stepuserid'];
$step=$DB->get_row("select * from saves_step where stepuserid='".$stepuserid."' limit 1");
if($step==''){
	swwalert('请勿随意访问文件?');
}
if($conf['stepset']==1 and $userrow['vip']==0)
	swwalert('你不是VIP暂时还不能添加步数任务哦');
?>
	<div id="stepjob">
		<button type="button" class="btn btn-default btn-block" href="#" onclick="stepjob_add('dailystep','<?=$step['stepuserid']?>','每日刷步数','1')"> 添加每日刷步数功能</button>
	</div>
