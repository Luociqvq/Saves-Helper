<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='网易云任务管理';
include TEMPLATE_ROOT.'User/head.php';

$wyyuserid = $_GET['wyyuserid'];
$wyy=$DB->get_row("select * from saves_wyy where wyyuserid='".$wyyuserid."' limit 1");
if($wyy==''){
	exit("<script language='javascript'>layer.msg('请先绑定网易云账户....', {icon:2}, function(){window.location.href='./index.php?m=User&v=wyylist'});</script>");
}
?>
	
			<div class="wrapper">
				<div class="col-lg-8 col-md-12 col-lg-offset-2" role="main">
					<div class="panel b-a">
						<div class="panel-heading bg-info dk no-border wrapper-lg">
						</div>
						<div class="text-center m-b clearfix">
							<div class="thumb-lg avatar m-t-n-xl">
								<img alt="image" class="b b-3x b-white" src="<?=$wyy['wyyavatarUrl']?>">
							</div>
							<div class="h4 font-thin m-t-sm" id="wyynickname"><?=$wyy['wyynickname']?></div>
						</div>
						<div class="hbox text-center b-t b-light">
							<div class="col padder-v text-muted">
								<div class="panel-body text-center bg-gray-darker">
									<div class="row row-table">
										<span>
											<?php if($wyy['cookiezt'] == 0){ ?>
											<h4 class="text-info m0">账户状态：正常在线中</h4>
											<?php }elseif($wyy['cookiezt'] == 1){ ?>
											<h4 class="text-danger m0">账户状态：状态异常</h4>
											<?php } ?>
										</span>
									<div class="mt-sm">状态若显示失效请及时更新防止功能不运行</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div style="width:100%;overflow:hidden;">
					</div>
					<div class="panel panel-info">
						<div class="row wrapper">
							<div class="col-sm-12">
							    <div class="btn-group dropdown m-l-xs">
									<button type="button" class="btn btn-info" data-toggle="dropdown" data-toggle="dropdown"><i class="fa fa-plus"></i> 添加/更改功能 </span></button>
									<ul class="dropdown-menu">
										<li><a onclick="saves.mode('./index.php?m=User&v=wyyjob&wyyuserid=<?=$wyy['wyyuserid']?>','添加网易云任务');">添加网易云任务</a></li>
									</ul>
								</div>
								<div class="btn-group dropdown m-l-xs">
									<button type="button" class="btn btn-info" data-toggle="dropdown" data-toggle="dropdown"> 更多操作 <span class="caret"></span></button>
									<ul class="dropdown-menu">
										<li><a onclick="saves.mode('./index.php?m=User&v=addwyy','添加网易云挂机');">更新密码</a></li>
										<li><a onclick="saves.mode('./index.php?m=User&v=wyyinfo&wyyuserid=<?=$wyy['wyyuserid']?>','详细信息');">详细信息</a></li>
										<li><a onclick="deletewyy('<?=$wyy['wyyuserid']?>')">删除账号</a></li>
									</ul>
								</div>
							</div>
						</div>
						<?php if (isMobile()){?>
							<?php
								$start=0;
									$rs=$DB->query("select * from saves_wyyjob where wyyuserid='{$wyy['wyyuserid']}' and start=1 order by jobid asc");
										while($res = $DB->fetch($rs))
											{
												if($res['cookiezt']==0){
													$active='<span class="text-success">在线运行中</span>';
												}elseif($res['cookiezt']==1){
													$active='<span class="text-danger">账户已失效</span>';
												}
												if($res['change']=='0'){
													echo '<div class="list-group-item">
														 	<div class="pull-right">
															 <label class="i-switch i-switch-lg bg-info m-t-xs text-left"><input type="radio" checked="" onclick="layer.msg(\'禁止更改此功能\');"><i></i></label>
												  			</div>
													  	 	<strong class="text-primary"><i class="fa fa-circle text-info"></i> '.$res['type'].'</strong> ['.$active.']
																<p class="m-t-xs">
																	<small class="text-muted clear text-ellipsis"><i class="fa fa-clock-o"></i> '.$res['lasttime'].' 已运行 <b><span class="text-info">'.$res['times'].'</span></b> 次</small>
																</p>
												  		 </div>';
												}else{
													echo '<div class="list-group-item">
											 		  		<div class="pull-right">
															   <label class="i-switch i-switch-lg bg-info m-t-xs text-left"><input type="radio" checked="" onclick="wyyjob_add(\''.$res['jobname'].'\',\''.$res['wyyuserid'].'\',\''.$res['type'].'\',\''.$start.'\')"><i></i></label>
											  				</div>
											 				<strong class="text-primary"><i class="fa fa-circle text-info"></i> '.$res['type'].'</strong> ['.$active.']
											   				<p class="m-t-xs">
																<small class="text-muted clear text-ellipsis"><i class="fa fa-clock-o"></i> '.$res['lasttime'].' 已运行 <b><span class="text-info">'.$res['times'].'</span></b> 次</small>
											  				</p>
														   </div>';
												}
											}
							?>
						<?php }else{?>
						<div class="list-group no-radius alt">
							<div class="table-responsive">
								<table class="table table-striped b-t b-light">
								<thead>
								<tr>
									<th>功能名</th>
									<th>执行时间</th>
									<th>执行次数</th>
									<th>状态</th>
									<th class="text-right" style="padding-right:25px;">操作</th>
								</tr>
								</thead>
								<tbody>
									<?php
										$start=0;
										$rs=$DB->query("select * from saves_wyyjob where wyyuserid='{$wyy['wyyuserid']}' and start=1 order by jobid asc");
											while($res = $DB->fetch($rs))
												{
													if($res['cookiezt']==0){
														$active='在线运行中';
													}elseif($res['cookiezt']==1){
														$active='账户已失效';
													}
													if($res['change']=='0'){
														echo '<tr>
														<td>'.$res['type'].'</td>
														<td> <i class="fa fa-clock-o pr-sm"> '.$res['lasttime'].' </b></td>
														<td>已执行：<span class="text-info">'.$res['times'].'</span> 次</td>
														<td><span class="text-info">'.$active.'</span> </td>
														<td class="text-right"><label class="i-switch i-switch-lg bg-info m-t-xs text-left"><input type="radio" checked="" onclick="layer.msg(\'禁止更改此功能\');"><i></i></label></td>
                                                    </tr>';
													}else{
														echo '<tr>
														<td>'.$res['type'].'</td>
														<td> <i class="fa fa-clock-o pr-sm"> '.$res['lasttime'].' </b></td>
														<td>已执行：<span class="text-info">'.$res['times'].'</span> 次</td>
														<td><span class="text-info">'.$active.'</span> </td>
														<td class="text-right"><label class="i-switch i-switch-lg bg-info m-t-xs text-left"><input type="radio" checked="" onclick="wyyjob_add(\''.$res['jobname'].'\',\''.$res['wyyuserid'].'\',\''.$res['type'].'\',\''.$start.'\')"><i></i></label></td>
                                                    </tr>';
													}
												}
										?>
								</tbody>
								</table>
							</div>
						</div>
						<?php }?>
						<div style="width:100%;overflow:hidden;">
						</div>
					</div>
					<div class="clearfix">
					</div>
				</div>
			</div>
								<div class="col-lg-12 col-md-12" style="overflow:hidden;"></div>
                </div>
            </div>
        </div>
	</section>
</div>
<?php include 'footer.php'; ?>