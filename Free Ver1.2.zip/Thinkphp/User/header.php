<?php
if(!$isuserlogin==1)exit("<script language='javascript'>window.location.href='./index.php?m=User&v=login';</script>");
?>
<!doctype html>
<html lang="en">
    <head>
		<meta charset="utf-8">
		<title><?=$conf['web_title']?>|<?=$indextitle?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="<?=$conf['web_keywords']?>"/>
		<meta name="description" content="<?=$conf['web_description']?>"/>
		<meta content="Luoci" name="author">
		<link rel="icon" href="./favicon.ico" type="image/png">
		<!-- CSS JS文件加载 -->
		<link rel="stylesheet" href="/Assets/View/css/bootstrap.css" type="text/css"/>
		<link rel="stylesheet" href="/Assets/View/css/animate.css" type="text/css"/>
		<link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
		<link rel="stylesheet" href="https://cdn.staticfile.org/simple-line-icons/2.4.1/css/simple-line-icons.css" type="text/css"/>
		<link rel="stylesheet" href="/Assets/View/css/font.css" type="text/css"/>
		<link rel="stylesheet" href="/Assets/View/css/app.css" type="text/css"/>
		<link rel="stylesheet" href="/Assets/View/Style/toastr/toastr.css" type="text/css"/>
		<script src="/Assets/View/js/jquery.min.js"></script>
		<script src="/Assets/View/js/bootstrap.min.js"></script>
		<script src="/Assets/View/js/ui-load.js"></script>
		<script src="/Assets/View/js/ui-jp.config.js"></script>
		<script src="/Assets/View/js/ui-jp.js"></script>
		<script src="/Assets/View/js/ui-nav.js"></script>
		<script src="/Assets/View/js/ui-toggle.js"></script>
		<script src="/Assets/Layer/layer.js"></script>
		<script src="/Assets/Js/core.js"></script>
		<script src="/Assets/Js/Saves.js"></script>
		<script src="/Assets/Js/main.js"></script>
		<!-- CSS JS文件结束 -->
		</head>
		
		<body ontouchstart="">
			<div class="app app-header-fixed pjaxmain">
				<header id="header" class="app-header navbar" role="menu">
					<div class="navbar-header bg-info">
						<button class="pull-right visible-xs dk" ui-toggle="off-screen" target=".app-aside" ui-scroll="app">
						<i class="fa fa-dedent fa-fw"></i></button>
						<button class="pull-right visible-xs" ui-toggle="show" target=".navbar-collapse">
						<i class="fa fa-cog"></i></button>
						<a href="/" class="navbar-brand text-lt text-center">
						<span class="hidden-folded m-l-xs">&nbsp;<?=$conf['web_title']?></span></a>
					</div>
			<div class="collapse pos-rlt navbar-collapse box-shadow bg-info">
					<div class="nav navbar-nav hidden-xs">
						<a href="#" class="btn no-shadow navbar-btn" ui-toggle="app-aside-folded" target=".app">
						<i class="fa fa-dedent fa-fw text"></i>
						<i class="fa fa-indent fa-fw text-active"></i></a>
						<a href="./index.php?m=User&v=account" class="btn no-shadow navbar-btn" data-pjax>
						<i class="fa fa-user-circle fa-fw"></i></a>
					</div>
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
						<a href="javascript:;" data-toggle="dropdown" class="dropdown-toggle clear" data-toggle="dropdown">
						<span class="thumb-sm avatar pull-right m-t-n-sm m-b-n-sm m-l-sm">
						<img alt="image" class="img-full" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['qq']?>&spec=40" style="width:70px;">
						<i class="on md b-white bottom"></i></span>
						<span class="hidden-sm hidden-md"><?=$userrow['user']?></span>
						<b class="caret"></b></a>
						<ul class="dropdown-menu animated fadeInRight w">
						<li class="wrapper b-b bg-light m-t-n-xs">
						<div>
							<p class="text-center"><?=$userrow['user']?>	</p>
						</div>
						<progressbar value="60" class="progress-xs m-b-none bg-white"></progressbar></li>
						<li><a href="./index.php?m=User&v=account" data-pjax><i class="fa fa-user-o"></i> &nbsp;&nbsp;账户资料</a></li>
						<li class="divider"></li>
						<li><a onclick="userlogout()"><i class="fa fa-sign-out"></i> &nbsp;&nbsp;退出登陆</a></li>
						</ul>
				</li>
				</ul>
        </div>
    </header>