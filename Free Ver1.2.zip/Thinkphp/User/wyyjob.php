<?php
$wyyuserid = $_GET['wyyuserid'];
$wyy=$DB->get_row("select * from saves_wyy where wyyuserid='".$wyyuserid."' limit 1");
if($wyy==''){
	swwalert('请勿随意访问文件?');
}
if($conf['wyyset']==1 and $userrow['vip']==0)
	swwalert('你不是VIP暂时还不能添加网易云任务哦');
?>
	<div id="wyyjob">
		<button type="button" class="btn btn-default btn-block" href="#" onclick="wyyjob_add('wyysongs','<?=$wyy['wyyuserid']?>','每日听歌300首','1')"> 添加每日听歌300首功能</button>
		<button type="button" class="btn btn-default btn-block" href="#" onclick="wyyjob_add('wyysign','<?=$wyy['wyyuserid']?>','每日自动签到','1')"> 添加每日自动签到(领云贝)功能</button> 
		<button type="button" class="btn btn-default btn-block" href="#" onclick="wyyjob_add('yunbeitask','<?=$wyy['wyyuserid']?>','完成云贝任务','1')"> 添加完成云贝任务功能</button> 
		<button type="button" class="btn btn-default btn-block" href="#" onclick="wyyjob_add('musician','<?=$wyy['wyyuserid']?>','完成音乐人任务','1')"> 添加完成音乐人任务功能</button>
		<button type="button" class="btn btn-default btn-block" href="#" onclick="wyyjob_add('evaluate','<?=$wyy['wyyuserid']?>','合伙人评分','1')"> 添加合伙人评分功能</button>

	</div>