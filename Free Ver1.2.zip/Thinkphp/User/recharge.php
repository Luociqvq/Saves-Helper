					<div class="panel-body">
						<center><b>我当前的余额：<span style="font-size:16px; color:#FF6133;"><?=$userrow['money']?></span> 元</b></center>
					<div class="line line-dashed b-b line-md"></div>
						<div class="input-group">
							<span class="input-group-addon">充值金额</span>
							<div class="col-lg-12">
								<input type="text" name="money" id="money" class="form-control" required/>
							</div>
						</div>
                        <hr class="hidden-print">
						<div id="recharge">
							<div id="pay_frame" class="form-group text-center" style="display:none;">
								<div class="input-group">
									<span class="input-group-addon">订单号</span>
									<div class="col-lg-12">
										<input class="form-control" name="orderid" id="orderid" value="" disabled>
									</div>
								</div>
							<hr class="hidden-print">
								<div class="input-group">
									<span class="input-group-addon">共需支付</span>
									<div class="col-lg-12">
										<input class="form-control" name="needs" id="needs" value="" disabled>
									</div>
								</div>
								<div class="alert alert-success">订单保存成功，请点击以下链接支付！</div>
									<button type="submit" class="btn btn-default" id="buy_alipay"><img src="../../Assets/View/icon/alipay.ico" class="logo"> 支付宝</button>&nbsp;
									<button type="submit" class="btn btn-default" id="buy_qqpay"><img src="../../Assets/View/icon/qqpay.ico" class="logo"> QQ钱包</button>&nbsp;
									<button type="submit" class="btn btn-default" id="buy_wxpay"><img src="../../Assets/View/icon/wechat.ico" class="logo"> 微信支付</button>&nbsp;
									<button type="submit" class="btn btn-default" id="buy_tenpay"><img src="../../Assets/View/icon/tenpay.ico" class="logo"> 财付通</button>&nbsp;
								</div>
								<div class="list-group">
									<input type="submit" id="submit_buy" class="btn btn-info btn-block submit" value="立即购买">
								</div>
							</div>
						</div>
					</div>
                        <script>
			$("#submit_buy").click(function(){
			var money=$("#money").val();
			if(money==''){layer.msg('请输入要充值的金额');return false;}
			if(isNaN(money) || money<0){layer.msg('请输入正确的充值金额');return false;}
			$('#pay_frame').hide();
			$('#submit_buy').val('Loading');
			$.ajax({
				type : "POST",
				url : "../../ajax.php?act=recharge",
				data : {money:money},
				dataType : 'json',
				success : function(data) {
				if(data.status == 1){
					$('#alert_frame').hide();
					$('#submit_buy').hide();
					$('#orderid').val(data.trade_no);
					$('#needs').val("￥"+data.money);
					$("#pay_frame").slideDown();
				}else{
					layer.msg(data.message);
				}
				$('#submit_buy').val('立即充值');
				} 
			});
			});
			$("#buy_alipay").click(function(){
			var orderid=$("#orderid").val();
			window.location.href='/Other/submit.php?type=alipay&orderid='+orderid;
			});
			$("#buy_qqpay").click(function(){
			var orderid=$("#orderid").val();
			window.location.href='/Other/submit.php?type=qqpay&orderid='+orderid;
			});
			$("#buy_wxpay").click(function(){
			var orderid=$("#orderid").val();
			window.location.href='/Other/submit.php?type=wxpay&orderid='+orderid;
			});
			$("#buy_tenpay").click(function(){
			var orderid=$("#orderid").val();
			window.location.href='/Other/submit.php?type=tenpay&orderid='+orderid;
			});
		</script>