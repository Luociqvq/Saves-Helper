<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='个人资料';
include TEMPLATE_ROOT.'User/head.php';
$isadd=$DB->get_row("select * from `saves_wyy` where uid='".$userrow['uid']."' limit 1");
$mywyys=$DB->count("SELECT count(*) from saves_wyy WHERE uid='".$userrow['uid']."'");
$mytasks=$DB->count("SELECT count(*) from saves_wyyjob WHERE uid='".$userrow['uid']."' and start='1' ");
$strtotime=strtotime($userrow['regtime']);//获取开始统计的日期的时间戳
$now=time();//当前的时间戳
$regdays=ceil(($now-$strtotime)/86400);//取相差值然后除于24小时(86400秒)
?>
    <div class="wrapper">
        <div class="col-lg-6 col-md-12 col-lg-offset-3">
            <div class="panel b-a">
            <div class="panel-heading bg-info dk no-border wrapper-lg"></div>
            <div class="text-center m-b clearfix">
            <div class="thumb-lg avatar m-t-n-xl">
				<img alt="image" class="b b-3x b-white" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['qq']?>&spec=100">
            </div>
            <div class="h4 font-thin m-t-sm"><?=$userrow['user']?></div>
            <span class="text-muted text-xs block"><?php echo get_qqnick($userrow['qq']); ?>&nbsp;UID:<?=$userrow['uid']?></span>
            </div>
			<div class="panel-body padder-v">
				<div class="form-horizontal">
				<div class="line line-dashed b-b line-md m-b">
					</div>
					<div class="col-sm-2 col-xs-4 control-label">
						帐号UID：
					</div>
					<div class="col-sm-10 col-xs-8">
						<p class="form-control-static" id="biao1"> <?=$userrow['uid']?></p>
					</div>
					<div class="line line-dashed b-b line-md m-b">
					</div>
					<div class="col-sm-2 col-xs-4 control-label">
						绑定Q Q：
					</div>
					<div class="col-sm-10 col-xs-8">
						<p class="form-control-static"><?=$userrow['qq']?> | <?php echo get_qqnick($userrow['qq']); ?></p>
					</div>
					<div class="line line-dashed b-b line-md m-b">
					</div>
					<div class="col-sm-2 col-xs-4 control-label">
						VIP 信息：
					</div>
					<div class="col-sm-10 col-xs-8">
						<p class="form-control-static">
							<?php if($userrow['vip']==1){ echo $userrow['vipdate']; }else{ echo '暂未开通VIP'; }?> 
							<a href="javascript:;" class="fa fa-exclamation-circle" style="font-size:14px;" onclick="layer.msg('VIP可享受各种特权服务！')" data-toggle="tooltip" data-placement="top" data-html="true" title="积分可以通过签到或者充值余额获取哦"></a>
							<a href="./index.php?m=User&v=openvip" class="text-ab pull-right m-r-xs" data-pjax="">开通VIP</a>
						</p>
					</div>
					<div class="line line-dashed b-b line-md m-b">
					</div>
					<div class="col-sm-2 col-xs-4 control-label">
						注册时间：
					</div>
					<div class="col-sm-10 col-xs-8">
						<p class="form-control-static"><?=$userrow['regtime']?></p>
					</div>
					<div class="line line-dashed b-b line-md m-b">
					</div>
					<div class="col-sm-2 col-xs-4 control-label">
						账户余额：
					</div>
					<div class="col-sm-10 col-xs-8">
						<p class="form-control-static"><?=$userrow['money']?></p>
					</div>
					<div class="line line-dashed b-b line-md m-b">
					</div>
					<div class="col-sm-2 col-xs-4 control-label">
						快捷登陆：
					</div>
					<div class="col-sm-10 col-xs-8">
						<p class="form-control-static">
							<?php if($userrow['QQ_token'] == ''){ ?>
							未绑定<a href="javascript:;" onclick="layer.msg('正在更新中...')" class="text-ab pull-right m-r-xs" data-pjax="">绑定</a>
							<?php }else{ ?>
							已绑定 [<?=$userrow['QQ_token']?> ]<a href="javascript:;" onclick="layer.msg('正在更新中...')" class="text-ab pull-right m-r-xs" data-pjax="">解绑</a>
							<?php }?>
						</p>
					</div>
					<div class="line line-dashed b-b line-md m-b">
					</div>
				</div>
				<hr>
				<div class="text-center">
					<a href="javascript:;" onclick="saves.mode('./index.php?m=User&v=editmyinfo','修改个人信息');" class="text-ab">修改个人信息</a>
				</div>
        </div>
            </div>
        </div>
    </div>
	<div class="col-lg-12 col-md-12" style="overflow:hidden;"></div>
                </div>
            </div>
        </div>
	</section>
</div>
<?php
include("footer.php");
?>