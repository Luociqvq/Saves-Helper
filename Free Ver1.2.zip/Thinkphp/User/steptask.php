<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='步数任务管理';
include TEMPLATE_ROOT.'User/head.php';

$stepuserid = $_GET['stepuserid'];
$step=$DB->get_row("select * from saves_step where stepuserid='".$stepuserid."' limit 1");
if($step==''){
	exit("<script language='javascript'>layer.msg('请先绑定步数账户....', {icon:2}, function(){window.location.href='./index.php?m=User&v=steplist'});</script>");
}
?>
	
			<div class="wrapper">
				<div class="col-lg-8 col-md-12 col-lg-offset-2" role="main">
					<div class="panel b-a">
						<div class="panel-heading bg-info dk no-border wrapper-lg">
						</div>
						<div class="text-center m-b clearfix">
							<div class="thumb-lg avatar m-t-n-xl">
								<img alt="image" class="b b-3x b-white" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['qq']?>&spec=100">
							</div>
							<div class="h4 font-thin m-t-sm"><?=$step['stepuserid']?></div>
						</div>
						<div class="hbox text-center b-t b-light">
							<div class="col padder-v text-muted">
								<div class="panel-body text-center bg-gray-darker">
									<div class="row row-table">
										<span>
										<?php if($step['cookiezt'] == 0){ ?>
											<h4 class="text-info m0">账户状态：正常在线中</h4>
										<?php }elseif($step['cookiezt'] == 1){ ?>
											<h4 class="text-danger m0">账户状态：状态异常</h4>
										<?php } ?>
										</span>
									<div class="mt-sm">状态若显示失效请及时更新防止功能不运行</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div style="width:100%;overflow:hidden;">
					</div>
					<div class="panel panel-info">
						<div class="row wrapper">
							<div class="col-sm-12">
							    <div class="btn-group dropdown m-l-xs">
									<button type="button" class="btn btn-info" data-toggle="dropdown" data-toggle="dropdown"><i class="fa fa-plus"></i> 添加/更改功能 </span></button>
									<ul class="dropdown-menu">
										<li><a onclick="saves.mode('./index.php?m=User&v=stepjob&stepuserid=<?=$step['stepuserid']?>','添加步数任务');">添加步数任务</a></li>
									</ul>
								</div>
								<div class="btn-group dropdown m-l-xs">
									<button type="button" class="btn btn-info" data-toggle="dropdown" data-toggle="dropdown"> 操作 <span class="caret"></span></button>
									<ul class="dropdown-menu">
										<li><a onclick="saves.mode('./index.php?m=User&v=addstep','添加步数挂机');">更新密码</a></li>
										<li><a onclick="deletestep('<?=$step['stepuserid']?>')">删除账号</a></li>
										<li><a onclick="saves.mode('./index.php?m=User&v=stepjobset&stepuserid=<?=$step['stepuserid']?>','配置步数');">配置任务</a></li>
									</ul>
								</div>
							</div>
						</div>
						<?php if (isMobile()){?>
							<?php
								$start=0;
								$rs=$DB->query("select * from saves_stepjob where stepuserid='{$step['stepuserid']}' and start=1 order by jobid asc");
								while($res = $DB->fetch($rs))
									{
										if($res['cookiezt']==0){
											$active='<span class="text-success">在线运行中</span>';
										}elseif($res['cookiezt']==1){
											$active='<span class="text-danger">账户已失效</span>';
										}
											if($res['change']=='0'){
												echo '<div class="list-group-item">
													 	<div class="pull-right">
														 	<label class="i-switch i-switch-lg bg-info m-t-xs text-left"><input type="radio" checked="" onclick="layer.msg(\'禁止更改此功能\');"><i></i></label>
												 		</div>
												  	 	<strong class="text-primary"><i class="fa fa-circle text-info"></i> '.$res['type'].'</strong> ['.$active.']
														<p class="m-t-xs">
															<small class="text-muted clear text-ellipsis"><i class="fa fa-clock-o"></i> '.$res['lasttime'].' 已运行 <b><span class="text-info">'.$res['times'].'</span></b> 次</small>
														</p>
												  	</div>';
											}else{
												echo '<div class="list-group-item">
											 		 	<div class="pull-right">
															<label class="i-switch i-switch-lg bg-info m-t-xs text-left"><input type="radio" checked="" onclick="stepjob_add(\''.$res['jobname'].'\',\''.$res['stepuserid'].'\',\''.$res['type'].'\',\''.$start.'\')"><i></i></label>
														</div>
														
											 			<strong class="text-primary"><i class="fa fa-circle text-info"></i> '.$res['type'].'</strong> ['.$active.']
											   			<p class="m-t-xs">
															<small class="text-muted clear text-ellipsis"><i class="fa fa-clock-o"></i> '.$res['lasttime'].' 已运行 <b><span class="text-info">'.$res['times'].'</span></b> 次</small>
											  			</p>
													</div>';
											}
										}
							?>
						<?php }else{?>
						<div class="list-group no-radius alt">
							<div class="table-responsive">
								<table class="table table-striped b-t b-light">
								<thead>
								<tr>
									<th>功能名</th>
									<th>执行时间</th>
									<th>执行次数</th>
									<th>状态</th>
									<th class="text-right" style="padding-right:25px;">操作</th>
								</tr>
								</thead>
								<tbody>
									<?php
										$start=0;
										$rs=$DB->query("select * from saves_stepjob where stepuserid='{$step['stepuserid']}' and start=1 order by jobid asc");
											while($res = $DB->fetch($rs))
												{
													if($res['cookiezt']==0){
														$active='在线运行中';
													}elseif($res['cookiezt']==1){
														$active='账户已失效';
													}
													if($res['change']=='0'){
														echo '<tr>
														<td>'.$res['type'].'</td>
														<td> <i class="fa fa-clock-o pr-sm"> '.$res['lasttime'].' </b></td>
														<td>已执行：<span class="text-info">'.$res['times'].'</span> 次</td>
														<td><span class="text-info">'.$active.'</span> </td>
														<td class="text-right"><label class="i-switch i-switch-lg bg-info m-t-xs text-left"><input type="radio" checked="" onclick="layer.msg(\'禁止更改此功能\');"><i></i></label></td>
                                                    </tr>';
													}else{
														echo '<tr>
														<td>'.$res['type'].'</td>
														<td> <i class="fa fa-clock-o pr-sm"> '.$res['lasttime'].' </b></td>
														<td>已执行：<span class="text-info">'.$res['times'].'</span> 次</td>
														<td><span class="text-info">'.$active.'</span> </td>
														<td class="text-right"><label class="i-switch i-switch-lg bg-info m-t-xs text-left"><input type="radio" checked="" onclick="stepjob_add(\''.$res['jobname'].'\',\''.$res['stepuserid'].'\',\''.$res['type'].'\',\''.$start.'\')"><i></i></label>
														<br>
														<a onclick="saves.mode(\'./index.php?m=User&v=stepjobset&stepuserid='.$res['stepuserid'].'\',\'配置步数信息\');" class="btn btn-sm btn-info">设置</a></td>
                                                    </tr>';
													}
												}
										?>
								</tbody>
								</table>
							</div>
						</div>
						<?php }?>
						<div style="width:100%;overflow:hidden;">
						</div>
					</div>
					<div class="clearfix">
					</div>
				</div>
			</div>
								<div class="col-lg-12 col-md-12" style="overflow:hidden;"></div>
                </div>
            </div>
        </div>
	</section>
</div>
<?php include 'footer.php'; ?>