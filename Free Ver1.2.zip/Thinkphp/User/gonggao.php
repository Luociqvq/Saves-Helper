<?php
/*
 * 用户中心公告文件
 * Author：Luoci
 * Date:2022/1/12
 */
 
if(!defined('IN_CRONLITE'))exit();
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;

if($_GET['act'] == 'gonggao'){
	$ggs=$DB->count("SELECT count(*) from saves_gonggao WHERE 1");
	if($ggs == 0){
		exit("<p style='text-align: center; padding:10px;'>网站暂无公告</p>");
	}
	$rs=$DB->query("SELECT * FROM saves_gonggao WHERE 1 order by id desc ");
	while($row = $DB->fetch($rs)){
?>
<a class="list-group-item" href="javascript:;" onclick="saves.mode('./index.php?m=User&v=gonggao&act=seegonggao&id=<?=$row['id']?>','公告详情');">
<i class="fa fa-comment fa-fw"></i>
<span><?=$row['title']?></span>
<span class="badge"><?=$row['addtime']?></span></a>
<?php
	}
}elseif($_GET['act'] == 'seegonggao'){
	$id=daddslashes($_GET['id']);
	$row=$DB->get_row("SELECT * FROM saves_gonggao WHERE id='$id'");
	$newlook = $row['look']+1;
	$DB->query("update saves_gonggao set look='{$newlook}' WHERE id='$id'");
	?>
		<div class="wrapper">
		<h4 class="m-t-none text-center m-b-md"><?=$row['title']?></h4>
			<div class="text-muted text-center"><i class="fa fa-user text-muted"></i><?=$row['publisher']?>
				<i class="fa fa-clock-o text-muted m-l-sm"></i><?=$row['addtime']?>
				<i class="fa fa-eye text-muted m-l-sm"></i><?=$row['look']?>
			</div>
		<div class="line line-lg b-b b-light"></div><?=$row['content']?>
	</div>	
	<?php
}else{
	swwalert('What are you doing?');
}
?>