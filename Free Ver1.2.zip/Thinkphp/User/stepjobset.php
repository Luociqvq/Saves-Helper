<?php
$stepuserid = $_GET['stepuserid'];
$step=$DB->get_row("select * from saves_stepjob where stepuserid='".$stepuserid."' limit 1");
if($step==''){
	swwalert('请勿随意访问文件?');
}
?>
                        <div class="panel-body">
							<div class="list-group-item col-lg-6">
								<div class="input-group">
									<span class="input-group-addon">起始步数</span>
									<input type="number" name="startstep" class="form-control" value="<?=$step['startstep']?>" autocomplete="off" oninput="if(value<1)value=1" required/>
								</div>
							</div>
							<div class="list-group-item col-lg-6">
								<div class="input-group">
									<span class="input-group-addon">结束步数</span>
									<input type="number" name="endstep" class="form-control" value="<?=$step['endstep']?>" autocomplete="off" oninput="if(value>98000)value=98000" required/>
								</div>
							</div>
                            <div class="line line-dashed b-b line-md m-b"></div>
								<button type="button" name="stepuserid" value="<?=$step['stepuserid']?>"  onclick="stepjobset()" class="btn btn-info btn-block">设置</button>
								
                            <p class="text-danger">温馨提示：若未设置将系统随机生成，步数结果需要大于或等于开始步数不能高于98000，最低步数必须比当前步数大，记得在小米运动里面绑定微信或支付宝</p>
                        </div>

