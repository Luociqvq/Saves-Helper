                        <div class="panel-body">
							<div class="list-group-item">
								<div class="input-group">
									<span class="input-group-addon">QQ</span>
									<input type="text" name="qq" placeholder="Such As 596844474" class="form-control" autocomplete="off" value="<?=$userrow['qq']?>" required/>
								</div>
							</div>
							<div class="list-group-item">
								<div class="input-group">
									<span class="input-group-addon">密码(不修改则留空)</span>
									<input type="password" name="pass" class="form-control" autocomplete="off" placeholder="Such As 123456" required>
								</div>
							</div>
							<div class="list-group-item">
								<input onclick="editmyinfo()" type="submit" value="修改" class="btn btn-info btn-block"/>
							</div>
						</div>