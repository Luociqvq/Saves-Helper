<?php
if(!defined('IN_CRONLITE'))exit();
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title><?=$conf['web_title']?>|用户中心登陆</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="<?=$conf['web_description']?>" />
        <meta name="keywords" content="<?=$conf['web_keywords']?>"/>
        <meta name="Author" content="Luoci"/>
        <!-- App favicon -->
        <link rel="shortcut icon" href="/Assets/Images/favicon.ico">
        
        <!-- App css -->
        <link href="/Assets/Login/Css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="/Assets/Login/Css/app-modern.min.css" rel="stylesheet" type="text/css" id="light-style" />
        <link href="/Assets/Login/Css/app-modern-dark.min.css" rel="stylesheet" type="text/css" id="dark-style" />

    </head>

    <body class="loading authentication-bg" data-layout-config='{"darkMode":false}'>
        <div class="account-pages pt-2 pt-sm-5 pb-4 pb-sm-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xxl-4 col-lg-5">
                        <div class="card">

                            <div class="card-body p-4">
                                <div class="text-center w-75 m-auto">
                                    <h4 class="text-dark-50 text-center mt-0 fw-bold">用户登录</h4>
                                </div>
                                    <div class="mb-3">
                                        <label class="form-label">用户名</label>
                                        <input type="text" id="user" class="form-control" name="user" value="<?php echo @$_POST['user'];?>" placeholder="输入用户名" required="required"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">用户密码</label>
                                        <div class="input-group input-group-merge">
                                            <input type="password" name="pass" class="form-control" placeholder="输入用户密码" required="required"/>
                                            <div class="input-group-text" data-password="false">
                                                <span class="password-eye"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-6 mb-0 text-center from-group">
                                        <input id="UserLogin" type="button" value="登陆" class="UserLogin btn-info form-control"/>
                                    </div>
                            </div> <!-- end card-body -->
                        </div>
                        <!-- end card -->

                        <div class="row mt-3">
                            <div class="col-12 text-center">
                                <p class="text-muted">没有账户? <a href="./index.php?m=User&v=reg" class="text-muted ms-1"><b>立即注册</b></a></p>
                            </div> <!-- end col -->
                        </div>
                        <!-- end row -->

                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end page -->

        <footer class="footer footer-alt">
             2021 © <?=$conf['web_title']?>
        </footer>

        <!-- bundle -->
        <script src="/Assets/Login/Js/vendor.min.js"></script>
        <script src="/Assets/Login/Js/app.min.js"></script>
		<script src="/Assets/Layer/layer.js"></script>
		<script src="/Assets/Layer/dialog.js"></script>
		<script src="/Assets/Js/Saves.js"></script>
		<?php
			if($isuserlogin==1){
			exit("<script language='javascript'>layer.msg('您已登录....', {icon:1}, function(){window.location.href='./index.php?m=User&v=index'});</script>");
			}
		?>
		<script>
				$('#UserLogin').click(function () {
					layer.msg('正在登录···', {icon: 16,shade: 0.01,time: 15000});
					$.ajax({
						url: './ajax.php?act=userlogin',
						type: 'POST',
						dataType: 'json',
						data: {
							user: $("input[name='user']").val(),
							pass: $("input[name='pass']").val(),
						},
						success: function (data) {
							if (data.status == '1') {
								layer.msg(data.message, {time: 1500}, function(){
									window.location.href = "./index.php?m=User&v=index";
								});
							} else if (data.status == '0') {
								layer.msg(data.message, {time: 1500},);
							}
						}
					});
				});
		$(document).keyup(function(event){
			if(event.keyCode ==13){
				$('#UserLogin').click();
			}
		});
		</script>     
    </body>
</html>