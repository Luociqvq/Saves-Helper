                        <div class="panel-body">
							<div class="list-group-item">
								<div class="input-group">
									<span class="input-group-addon">电话</span>
									<input type="text" name="tellphone" placeholder="Such As 1888888888" class="form-control" autocomplete="off" required/>
								</div>
							</div>
							<div class="list-group-item">
								<div class="input-group">
									<span class="input-group-addon">密码</span>
									<input type="password" name="password" class="form-control" autocomplete="off" placeholder="Such As 123456" required>
								</div>
							</div>
							<div class="list-group-item">
								<input onclick="addstep()" type="submit" value="登录" class="btn btn-info btn-block"/>
							</div>
						</div>