<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <title><?=$conf['web_title']?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="keywords" content="<?=$conf['web_keywords']?>"/>
		<meta name="description" content="<?=$conf['web_description']?>"/>
        <meta content="Luoci" name="author" />
		<!-- App favicon -->
		<link rel="shortcut icon" href="/Assets/Images/favicon.ico">
		<!-- third party css -->
		<link href="/Assets/Login/Css/vendor/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css">
		<!-- third party css end -->
		<!-- App css -->
		<link href="/Assets/Login/Css/icons.min.css" rel="stylesheet" type="text/css">
		<link href="/Assets/Login/Css/app-modern.min.css" rel="stylesheet" type="text/css" id="light-style">
		<link href="/Assets/Login/Css/app-modern-dark.min.css" rel="stylesheet" type="text/css" id="dark-style">

    </head>

    <body class="loading" data-layout-config='{"darkMode":false}'>

        <!-- NAVBAR START -->
        <nav class="navbar navbar-expand-lg py-lg-3 navbar-dark">
            <div class="container">

                <!-- logo -->
                <a href="index.php" class="navbar-brand me-lg-5">
                    <span>Saves-云功能中心</span>
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                    aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="mdi mdi-menu"></i>
                </button>

                <!-- menus -->
                <div class="collapse navbar-collapse" id="navbarNavDropdown">

                    <!-- left menu -->
                    <ul class="navbar-nav me-auto align-items-center">
                        <li class="nav-item mx-lg-1">
                            <a class="nav-link active" href="#Home">主页</a>
                        </li>
                        <li class="nav-item mx-lg-1">
                            <a class="nav-link" href="#function">功能特性</a>
                        </li>
                        <li class="nav-item mx-lg-1">
                            <a class="nav-link" href="#price">代挂价格</a>
                        </li>
                        <li class="nav-item mx-lg-1">
                            <a class="nav-link" href="">FAQs</a>
                        </li>
                    </ul>

                    <!-- right menu -->
                    <ul class="navbar-nav ms-auto align-items-center">
                        <li class="nav-item me-0">
                            <a href="/index.php?m=User&v=login" class="nav-link d-lg-none">立即登录</a>
                            <a href="/index.php?m=User&v=login" class="btn btn-sm btn-light rounded-pill d-none d-lg-inline-flex"> 立即登录 </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>
        <!-- NAVBAR END -->

        <!-- START HERO -->
        <section id="Home" class="hero-section">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-5">
                        <div class="mt-md-4">
						
                            <div class="headline">
                                <span class="badge bg-danger rounded-pill">New</span>
                                <span class="text-white-50 ms-2">全自动网易代挂/B站代挂/同步步数 &nbsp;</span>
                            </div>
                            <h2 class="text-white fw-normal mb-4 mt-3 hero-title">
                                Saves-云功能中心|全自动化系统
                            </h2>

                            <p class="mb-6 font-20 text-white-50">安全稳定不封号，轻松实现挂机</p>
							<?php if($isuserlogin==1){?>
                            <a href="/index.php?m=User&v=index" class="btn btn-success">用户中心 <i class="mdi mdi-arrow-right ms-1"></i></a>
							<?php }else{ ?>
							<a href="/index.php?m=User&v=login" class="btn btn-success">立即登录 <i class="mdi mdi-arrow-right ms-1"></i></a>
							<a href="/index.php?m=User&v=reg" class="btn btn-info">立即注册 </a>
							<?php }?>
                        </div>
                    </div>
                    <div class="col-md-5 offset-md-2">
                        <div class="text-md-end mt-3 mt-md-0">
                            <img src="/Assets/Login/Images/startup.svg" alt="" class="img-fluid" />
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END HERO -->

        <!-- START SERVICES -->
        <section id="function" class="py-5">
            <div class="container">
                <div class="row py-4">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <h3>Saves <span class="text-primary">-全自动云功能中心</span></h3>
                            <p class="text-muted mt-2">致力于为用户提供最稳定的自动化服务</p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="text-center p-3">
                            <div class="avatar-sm m-auto">
                                <span class="avatar-title bg-primary-lighten rounded-circle">
                                    <i class="uil uil-desktop text-primary font-24"></i>
                                </span>
                            </div>
                            <h4 class="mt-3">运行稳定</h4>
                            <p class="text-muted mt-2 mb-0">海量代挂节点，拒绝延迟，提供优质的使用体验</p>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="text-center p-3">
                            <div class="avatar-sm m-auto">
                                <span class="avatar-title bg-primary-lighten rounded-circle">
                                    <i class="mdi mdi-tablet-cellphone text-primary font-24"></i>
                                </span>
                            </div>
                            <h4 class="mt-3">便携设置</h4>
                            <p class="text-muted mt-2 mb-0">我们的代挂云端服务适用于 iOS、Android、Windows
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="text-center p-3">
                            <div class="avatar-sm m-auto">
                                <span class="avatar-title bg-primary-lighten rounded-circle">
                                    <i class="mdi mdi-fire text-primary font-24"></i>
                                </span>
                            </div>
                            <h4 class="mt-3">节省成本</h4>
                            <p class="text-muted mt-2 mb-0">相比自己手动提交可节省大量费用，无需手动提交
                            </p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="text-center p-3">
                            <div class="avatar-sm m-auto">
                                <span class="avatar-title bg-primary-lighten rounded-circle">
                                    <i class="mdi mdi-check-bold text-primary font-24"></i>
                                </span>
                            </div>
                            <h4 class="mt-3">累计防封</h4>
                            <p class="text-muted mt-2 mb-0">模拟真人，独立代理IP执行任务
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="text-center p-3">
                            <div class="avatar-sm m-auto">
                                <span class="avatar-title bg-primary-lighten rounded-circle">
                                    <i class="mdi mdi-cloud-upload text-primary font-24"></i>
                                </span>
                            </div>
                            <h4 class="mt-3">长期更新</h4>
                            <p class="text-muted mt-2 mb-0">同步更新所有项目最新接口，稳定不封号
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="text-center p-3">
                            <div class="avatar-sm m-auto">
                                <span class="avatar-title bg-primary-lighten rounded-circle">
                                    <i class="uil uil-grids text-primary font-24"></i>
                                </span>
                            </div>
                            <h4 class="mt-3">多号管理</h4>
                            <p class="text-muted mt-2 mb-0">列表状态一目了然，号再多也能轻松管理
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <!-- END SERVICES -->

        <!-- START PRICING -->
        <section id="price" class="py-5 bg-light-lighten border-top border-bottom border-light">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <h1 class="mt-0"><i class="mdi mdi-tag-multiple"></i></h1>
                            <h3>购买 Vip <span class="text-primary">价格</span></h3>
                        </div>
                    </div>
                </div>

                <div class="row mt-5 pt-3">
                    <div class="col-md-4">
                        <div class="card card-pricing">
                            <div class="card-body text-center">
                                <p class="card-pricing-plan-name fw-bold text-uppercase">包月VIP </p>
                                <h2 class="card-pricing-price">$3 <span>/ 月</span></h2>
                                <ul class="card-pricing-features">
                                    <li>支持网易云代挂</li>
                                    <li>支持B站代挂</li>
                                    <li>支持每天运动刷步数</li>
									<li>支持网站新功能同步</li>
                                </ul>
                                <button class="btn btn-primary mt-4 mb-2 rounded-pill">选择此项</button>
                            </div>
                        </div>
                        <!-- end Pricing_card -->
                    </div>
                    <!-- end col -->

                    <div class="col-md-4">
                        <div class="card card-pricing card-pricing-recommended">
                            <div class="card-body text-center">
                                <div class="card-pricing-plan-tag">站长推荐</div>
                                <p class="card-pricing-plan-name fw-bold text-uppercase">包季VIP</p>
                                <h2 class="card-pricing-price">$6 <span>/ 季</span></h2>
                                <ul class="card-pricing-features">
                                    <li>支持网易云代挂</li>
                                    <li>支持B站代挂</li>
                                    <li>支持每天运动刷步数</li>
									<li>支持网站新功能同步</li>
                                </ul>
                                <button class="btn btn-primary mt-4 mb-2 rounded-pill">选择此项</button>
                            </div>
                        </div>
                        <!-- end Pricing_card -->
                    </div>
                    <!-- end col -->

                    <div class="col-md-4">
                        <div class="card card-pricing">
                            <div class="card-body text-center">
                                <p class="card-pricing-plan-name fw-bold text-uppercase">包年VIP</p>
                                <h2 class="card-pricing-price">$9 <span>/ 年</span></h2>
                                <ul class="card-pricing-features">
                                    <li>支持网易云代挂</li>
                                    <li>支持B站代挂</li>
                                    <li>支持每天运动刷步数</li>
									<li>支持网站新功能同步</li>
                                </ul>
                                <button class="btn btn-primary mt-4 mb-2 rounded-pill">选择此项</button>
                            </div>
                        </div>
                        <!-- end Pricing_card -->
                    </div>
                    <!-- end col -->

                </div>

            </div>
        </section>
        <!-- END PRICING -->

        <!-- START FOOTER -->
        <footer class="bg-dark py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
						<h3 class="text-capitalize">Saves-云功能中心</h3>
                        <p class="text-muted mt-4"> <p>致力于为用户提供最稳定的自动化服务</p>
                    </div>

                    <div class="col-lg-3 mt-3 mt-lg-0">
                        <h5 class="text-light">联系站长</h5>

                        <ul class="list-unstyled ps-0 mb-0 mt-3">
                            <li class="mt-2"><a href="mqqwpa://im/chat?chat_type=wpa&uin=596844474" class="text-muted">联系QQ：596844474</a></li>
                            <li class="mt-2"><a href="http://www.6alk.cn/" class="text-muted">站长博客：http://auth.6alk.cn/</a></li>
                            <li class="mt-2"><a href="javascript: void(0);" class="text-muted">联系邮箱：596844474@qq.com</a></li>
                            <li class="mt-2"><a href="javascript: void(0);" class="text-muted">Saves-Cloud</a></li>
                        </ul>
                    </div>

                    <div class="col-lg-3 mt-3 mt-lg-0">
                        <h5 class="text-light">使用方式</h5>

                        <ul class="list-unstyled ps-0 mb-0 mt-3">
                            <li class="mt-2"><a href="http://help.6alk.cn/" class="text-muted">帮助中心</a></li>
                            <li class="mt-2"><a href="http://www.6alk.cn/" class="text-muted">我们项目</a></li>
                            <li class="mt-2"><a href="http://auth.6alk.cn/" class="text-muted">授权中心</a></li>
                        </ul>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="mt-5">
                            <p class="text-muted mt-4 text-center mb-0">© 2022 Saves-Cloud by Luoci  &nbsp; <a href="//beian.miit.gov.cn/" title="Saves-Cloud" target="_blank"><u>备案号-8</u></a></p> 
							
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- bundle -->
        <script src="/Assets/Login/Js/vendor.min.js"></script>
        <script src="/Assets/Login/Js/app.min.js"></script>
    </body>

</html>