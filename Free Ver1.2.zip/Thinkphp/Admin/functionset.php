<?php
$indextitle='功能设置';
include TEMPLATE_ROOT.'Admin/head.php';
?>
				<div class="wrapper">
					<div class="col-lg-8 col-md-12 col-lg-offset-2" role="main">
						<div class="panel panel-info">
							<div class="panel-heading font-bold">
				            功能是否需要VIP运行
							</div>
							<div class="panel-body padder-v">
									<div class="input-group">
                                        <span class="input-group-addon">网易云功能是否需要VIP：</span>
                                        <select name="wyyset" class="form-control m-b" value="<?=$conf['wyyset']?>">
                                        <?php if($conf['wyyset']==1){?>
                                            <option value="1">需要</option>
                                            <option value="2">不需要</option>
										<? }else{ ?>
											<option value="2">不需要</option>
											<option value="1">需要</option>
										<? } ?>
                                        </select>
                                    </div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="input-group">
                                        <span class="input-group-addon">Bili功能是否需要VIP：</span>
                                        <select name="biliset" class="form-control m-b" value="<?=$conf['biliset']?>">
                                        <?php if($conf['biliset']==1){?>
                                            <option value="1">需要</option>
                                            <option value="2">不需要</option>
										<? }else{ ?>
											<option value="2">不需要</option>
											<option value="1">需要</option>
										<? } ?>
                                        </select>
                                    </div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="input-group">
                                        <span class="input-group-addon">步数功能是否需要VIP：</span>
                                        <select name="stepset" class="form-control m-b" value="<?=$conf['stepset']?>">
										<?php if($conf['stepset']==1){?>
                                            <option value="1">需要</option>
                                            <option value="2">不需要</option>
										<? }else{ ?>
											<option value="2">不需要</option>
											<option value="1">需要</option>
										<? } ?>
                                        </select>
                                    </div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="input-group">
                                        <span class="input-group-addon">爱奇艺功能是否需要VIP：</span>
                                        <select name="iqyset" class="form-control m-b" value="<?=$conf['iqyset']?>">
										<?php if($conf['iqyset']==1){?>
                                            <option value="1">需要</option>
                                            <option value="2">不需要</option>
										<? }else{ ?>
											<option value="2">不需要</option>
											<option value="1">需要</option>
										<? } ?>
                                        </select>
                                    </div>
                                    <div class="line line-dashed b-b line-md">
									</div>
									<input class="btn btn-info btn-block btn-outline btn-rounded font-bold" onclick="functionset()" type="submit">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
</div>
<?php include 'footer.php'; ?>