<?php
            $uid=daddslashes($_GET['uid']);
        	$row=$DB->get_row("SELECT * FROM saves_user WHERE uid='$uid'");
            if($row == ''){
                swwalert('请勿恶意提交数据访问页面');
            }
    ?>
        <div class="input-group">
            <span class="input-group-addon">用户账户</span>
            <input type="text" class="form-control" name="user" value="<?=$row['user']?>">
        </div>
        <div class="line line-dashed b-b line-md"></div>
        <div class="input-group">
            <span class="input-group-addon">用户密码</span>
            <input type="text" class="form-control" name="pass" value="<?=$row['pass']?>">
        </div>
        <div class="line line-dashed b-b line-md"></div>
        <div class="input-group">
            <span class="input-group-addon">用户QQ</span>
            <input type="text" class="form-control" name="qq" value="<?=$row['qq']?>">
        </div>
        <div class="line line-dashed b-b line-md"></div>
        <div class="input-group">
            <span class="input-group-addon">用户余额</span>
            <input type="text" class="form-control" name="money" value="<?=$row['money']?>">
        </div>
        <div class="line line-dashed b-b line-md"></div>
            <button class="btn btn-info btn-block btn-outline btn-rounded font-bold" type="button" name="uid" value="<?=$row['uid']?>" onclick="edituser()">确定</button>