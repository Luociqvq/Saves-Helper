    <div class="input-group">
        <span class="input-group-addon">用户名</span>
            <input type="text" class="form-control" placeholder="请输入用户名" name="user">
    </div>
    <div class="line line-dashed b-b line-md"></div>
    <div class="input-group">
        <span class="input-group-addon">用户密码</span>
            <input type="text" class="form-control" placeholder="请输入密码" name="pass">
    </div>
    <div class="line line-dashed b-b line-md"></div>
    <div class="input-group">
        <span class="input-group-addon">绑定QQ</span>
            <input type="text" class="form-control" placeholder="请输入QQ" name="qq">
    </div>
    <div class="line line-dashed b-b line-md"></div>
    <div class="input-group">
        <span class="input-group-addon">用户余额</span>
            <input type="text" class="form-control" name="money">
    </div>
    <div class="line line-dashed b-b line-md"></div>
        <input onclick="adduser()" type="submit" value="保存" class="btn btn-info btn-block"/>