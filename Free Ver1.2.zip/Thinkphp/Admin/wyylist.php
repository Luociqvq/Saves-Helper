<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='网易云账号管理';
include TEMPLATE_ROOT.'Admin/head.php';
if(isset($_GET['kw'])) {
	if($_GET['type']==1)
		$sql=($_GET['method']==1)?" `id` LIKE '%{$_GET['kw']}%'":" `id`='{$_GET['kw']}'";
	elseif($_GET['type']==2)
		$sql=($_GET['method']==1)?" pass like '%{$_GET['kw']}%'":" pass='{$_GET['kw']}'";
	elseif($_GET['type']==3)
		$sql=($_GET['method']==1)?" `regip` LIKE '%{$_GET['kw']}%'":" `regip`='{$_GET['kw']}'";
	elseif($_GET['type']==4)
		$sql=($_GET['method']==1)?" `city` LIKE '%{$_GET['kw']}%'":" `city`='{$_GET['kw']}'";
	$gls=$DB->count("select count(*) from saves_user where{$sql}");
	$con='包含 '.$_GET['kw'].' 的共有 <b>'.$gls.'</b> 个账号';
}else{
	$gls=$DB->count("select count(*) from saves_user where 1");
	$sql=" 1";
	$con='授权平台共有 <b>'.$gls.'</b> 个账号';
}

$pagesize=10;
if (!isset($_GET['page'])) {
	$page = 1;
	$pageu = $page - 1;
} else {
	$page = $_GET['page'];
	$pageu = ($page - 1) * $pagesize;
}
?>
				<div class="wrapper">
					<div class="col-sm-12">
						<div class="panel panel-info">
							<div class="panel-heading bg-primary info font-bold">
								网易云账号列表
							</div>
							<div class="row wrapper">
								<div class="col-sm-12">
									<div class="btn-group dropdown m-l-xs" style="float:left;">
										<button type="button" class="btn btn-info" data-toggle="dropdown" data-toggle="dropdown"><span id="buttoncon">全部列表</span><span class="caret"></span></button>
										<ul class="dropdown-menu" data-conid>
											<li><a href="./index.php?m=Admin&v=userlist">全部列表</a></li>
											<li><a href="./index.php?m=Admin&v=userlist&active=1">状态正常</a></li>
											<li><a href="./index.php?m=Admin&v=userlist&active=0">状态异常</a></li>
										</ul>
									</div>
									<a class="btn btn-sm btn-dark m-l-xs" id="wyys"><0</a>
									<?php if (isMobile()){?>
										<form role="form" onsubmit="return false;" class="m-t-md visible-xs">
										<div class="input-group m-b-sm">
											<input type="text" name='search' class="form-control" placeholder="账号" value="" style="height:31px;" maxlength="40">
											<span class="input-group-btn"><button class="btn btn-success btn-md" id="search">搜索</button></span>
										</div>
									</form>
									<?php }else{?>
									<div class="form-inline ng-pristine ng-valid hidden-xs" style="float:right;">
										<form role="form" onsubmit="return false;">
											<div class="form-group">
												<input type="text" name='search' class="form-control" placeholder="账号" value="" style="height:31px;" maxlength="40" >
											</div>
											<span class="ng-scope"><button class="btn btn-success" id="search">搜索</button></span>
										</form>
									</div>
									<?php }?>
								</div>
							</div>
							<div class="row wrapper">
							<?php if (isMobile()){?>
								<div>
								<?php
									$rs=$DB->query("select * from saves_wyy where{$sql} order by wyyid desc limit $pageu,$pagesize");
										while($res = $DB->fetch($rs))
										{
											if($res['cookiezt']==0){
												$active='<font class="text-info m0">账号正常';
											}elseif($res['cookiezt']==1){
												$active='<font class="text-danger" m0">账号失效';
											}
											echo '<div class="list-group-item">
												<a class="pull-left thumb-sm avatar m-r" href="./index.php?m=Admin&v=wyyinfo&wyyuserid='.$res['wyyuserid'].'" data-pjax="">
													<img src="'.$res['wyyavatarUrl'].'"><i class="on b-white bottom"></i>
												</a>
											<div class="btn-group dropdown pull-right m-t-xs">
												<button type="button" class="btn btn-info" data-toggle="dropdown">设置 <span class="caret"></span></button>
												<ul class="dropdown-menu">
													<li><a href="javascript:;" onclick="saves.mode(\'./index.php?m=Admin&v=wyyinfo&wyyuserid='.$res['wyyuserid'].'\',\'查看网易云信息\');"">查看</a></li>
													<li><a href="javascript:;" onclick="wyydelete(\''.$res['wyyid'].'\',\''.$res['wyyuserid'].'\',\''.$userrow['power'].'\')">删除</a></li>
												</ul>
											</div>
											<strong class="text-primary"><i class="fa fa-circle text-info"></i>'.$res['wyynickname'].'</strong> [<span>'.$active.'</span>]
											<p class="m-t-xs">
												<small class="text-muted clear text-ellipsis"><i class="fa fa-clock-o"></i> '.$res['addtime'].'</small>
											</p>';
										}
									?>
								</div>
								<?php }else{?>
								<div class="table-responsive">
									<table class="table table-striped b-t b-light">
									<thead>
									<tr>
										<th style="width:40px;" class="hidden-sm hidden-xs">
											<label class="i-checks m-b-none"><input type="checkbox"><i></i></label>
										</th>
										<th width="72px">头像</th>
										<th>UID/名称</th>
										<th>电话</th>
										<th>添加时间</th>
										<th>账号状态</th>
										<th class="text-right">操作</th>
									</tr>
									</thead>
									<tbody>
									<?php
										$rs=$DB->query("select * from saves_wyy where{$sql} order by wyyid desc limit $pageu,$pagesize");
											while($res = $DB->fetch($rs))
											{
												if($res['cookiezt']==0){
													$active='<font class="text-info m0">账号正常';
												}elseif($res['cookiezt']==1){
													$active='<font class="text-danger" m0">账号失效';
												}
												echo '<tr>
												<td class="hidden-sm hidden-xs">
													<label class="i-checks m-b-none"><input type="checkbox"><i></i></label>
												</td>
												<td>
													<img alt="image" class="img-full b b-3x b-white" src="'.$res['wyyavatarUrl'].'">
												</td>
												<td>
													[<span class="text-info">'.$res['wyyuserid'].'</span> ] '.$res['wyynickname'].';
												</td>
												<td class="text-success">
													'.$res['tellphone'].' 
												</td>
												<td>
													'.$res['addtime'].' 
												</td>
												<td>
													'.$active.'
												</td>
												<td class="text-right">
													<div class="btn-group dropdown">
														<a href="javascript:;" data-toggle="dropdown" class="dropdown-toggle clear btn btn-default" aria-expanded="false">操作 <span class="caret"></span></a>
														<ul class="dropdown-menu animated fadeInUp" style="left:auto;right:0;">
															<li><a href="javascript:;" onclick="saves.mode(\'./index.php?m=User&v=wyyinfo&wyyuserid='.$res['wyyuserid'].'\',\'查看网易云信息\');"">查看账户信息</a></li>
															<li><a href="javascript:;" onclick="wyydelete(\''.$res['wyyid'].'\',\''.$res['wyyuserid'].'\',\''.$userrow['power'].'\')">删除该账户</a></li>
														</ul>
													</div>
												</td>
											</tr>';
											}
									?>
									</tbody>
									</table>
								</div>
								<?php } ?>
								<div class="panel-footer">
<?php
echo'<nav class="text-center"><ul class="pagination justify-content-center">';
$s = ceil($myaccount / $pagesize);
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$s;
if ($page>1)
{
echo '<li><a href="/Public/Auth/authlist.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="/Public/Auth/authlist.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="/Public/Auth/authlist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$s;$i++)
echo '<li><a href="/Public/Auth/authlist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$s)
{
echo '<li><a href="/Public/Auth/authlist.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="/Public/Auth/authlist.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
</div>
<?php include 'footer.php'; ?>
<script type="text/javascript">
saves.amount('./ajax.php?act=adminamount','加载完成');
</script>