<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='VIP设置';
include TEMPLATE_ROOT.'Admin/head.php';
?>
                <div class="wrapper" draggable="true">
					<div class="col-lg-6 col-md-12 col-lg-offset-3" role="main">
						<div class="panel panel-info">
							<div class="panel-heading font-bold">
			                 价格设置
                             <a href="javascript:;" onclick="saves.mode('./index.php?m=Admin&v=vipset&act=addvip','添加用户');" class="btn btn-sm btn-dark m-l-xs"> 添加VIP</a>
							</div>
						<?php if (isMobile()){?>
						 	<div class="list-group-item delgn762470">
						 		<div class="pull-left thumb-sm m-r">
						 			<a href="javascript:;" onclick="cly.modal('?do=editprice&tid={$order.tid}','{$order.name}价格')"><img alt="image" class="img-full" src="{$order.png}" style="width:40px;"></a>
						 		</div>
						 		<div class="pull-right">
						 			<a class="btn btn-info btn-outline" href="javascript:;" onclick="cly.modal('?do=editprice&tid={$order.tid}','{$order.name}价格')">编辑</a>
						 		</div>
						 		<a href="javascript:;" onclick="cly.modal('?do=editprice&tid={$order.tid}','{$order.name}价格')"><strong class="text-primary"><i class="fa fa-circle text-info"></i> {$order.name}</strong></a>
						 		<p class="m-t-xs">
						 			<b><a href="javascript:;" onclick="cly.modal('?do=editprice&tid={$order.tid}','{$order.name}价格')"><span class="text-success">{if condition="empty($power[$order.tid])"}未设置{else/}{$power[$order.tid]}￥{/if}</span></a> </b>
						 		</p>
						 	</div>
						<?php }else{?>
							<div class="table-responsive">
								<table class="table table-striped b-t b-light">
								<thead>
								<tr>
									<th class="text-center">名称</th>
									<th class="text-center">价格</th>
									<th class="text-center">操作</th>
								</tr>
								</thead>
								<tbody>
                                    <?php
										$rs=$DB->query("select * from saves_vip");
											while($res = $DB->fetch($rs))
											{
												echo '<tr>
								                	    <td class="text-center">'.$res['value'].'</td>
									                    <td class="text-center">'.$res['price'].'元</td>
									                    <td class="text-center"><a class="btn btn-info btn-outline" href="javascript:;" onclick="saves.mode(\'./index.php?m=Admin&v=vipset&act=editvip&id='.$res['id'].'\',\'编辑VIP\')">修改</a> <a class="btn btn-info btn-outline" href="javascript:;" onclick="deleteviplevel(\''.$res['id'].'\')">删除</a></td>
								                  </tr>';
											}
									?>
								</tbody>
								</table>
							</div>
							<?php } ?>
						</div>
					</div>
				</div>
        </div>
		</div>
	</div>
	</section>
</div>
<?php include 'footer.php'; ?>