<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='公告管理';
include TEMPLATE_ROOT.'Admin/head.php';

if(isset($_GET['kw'])) {
	if($_GET['type']==1)
		$sql=($_GET['method']==1)?" `id` LIKE '%{$_GET['kw']}%'":" `id`='{$_GET['kw']}'";
	elseif($_GET['type']==2)
		$sql=($_GET['method']==1)?" pass like '%{$_GET['kw']}%'":" pass='{$_GET['kw']}'";
	elseif($_GET['type']==3)
		$sql=($_GET['method']==1)?" `regip` LIKE '%{$_GET['kw']}%'":" `regip`='{$_GET['kw']}'";
	elseif($_GET['type']==4)
		$sql=($_GET['method']==1)?" `city` LIKE '%{$_GET['kw']}%'":" `city`='{$_GET['kw']}'";
	$gls=$DB->count("select count(*) from saves_user where{$sql}");
	$con='包含 '.$_GET['kw'].' 的共有 <b>'.$gls.'</b> 个账号';
}else{
	$gls=$DB->count("select count(*) from saves_user where 1");
	$sql=" 1";
	$con='授权平台共有 <b>'.$gls.'</b> 个账号';
}

$pagesize=10;
if (!isset($_GET['page'])) {
	$page = 1;
	$pageu = $page - 1;
} else {
	$page = $_GET['page'];
	$pageu = ($page - 1) * $pagesize;
}
?>
				<div class="wrapper">
					<div class="col-sm-12">
						<div class="panel panel-info">
							<div class="panel-heading bg-primary info font-bold">
								公告列表
							</div>
							<div class="row wrapper">
								<div class="col-sm-12">
									<div class="btn-group dropdown m-l-xs" style="float:left;">
										<button type="button" class="btn btn-info" data-toggle="dropdown" data-toggle="dropdown"><span id="buttoncon">全部列表</span><span class="caret"></span></button>
										<ul class="dropdown-menu" data-conid>
											<li><a href="{:url(gonggao)}">全部列表</a></li>
											<li><a href="?do=user">用户中心</a></li>
											<li><a href="?do=daili">代理中心</a></li>
										</ul>
									</div>
									<a href="javascript:" onclick="saves.mode('./index.php?m=Admin&v=gonggao&act=newgonggao','发布新公告')"; class="btn btn-sm btn-dark m-l-xs"><i class="fa fa-plus"></i> 发布新公告</a>
								</div>
							</div>
							<div class="row wrapper">
							<?php if (isMobile()){?>
								<?php
									$rs=$DB->query("select * from saves_gonggao where{$sql} order by id desc limit $pageu,$pagesize");
										while($res = $DB->fetch($rs))
										{
											$active=checkggoff($res['active']);
											$title=htmlspecialchars(cut_str($res['title'],8));
											$content=htmlspecialchars(cut_str($res['content'],10));
											echo '<div class="list-group-item">
											<div class="btn-group dropdown pull-right m-t-xs">
												<button type="button" class="btn btn-info" data-toggle="dropdown" aria-expanded="false">
                                            	操作
												<span class="caret"></span></button>
												<ul class="dropdown-menu">
													<li><a href="javascript:;" onclick="saves.mode(\'./index.php?m=User&v=gonggao&act=seegonggao&id='.$res['id'].'\',\'公告详情\');">查看</a></li>
													<li><a href="javascript:;" onclick="saves.mode(\'./index.php?m=Admin&v=gonggao&act=editgonggao&id='.$res['id'].'\',\'编辑公告\')">编辑</a></li>
													<li><a href="javascript:;" onclick="deletegonggao(\''.$res['id'].'\')">删除</a></li>
												</ul>
											</div>
											<strong class="text-info"><i class="fa fa-circle text-info"></i><span onclick="saves.mode(\'./index.php?m=User&v=gonggao&act=seegonggao&id='.$res['id'].'\',\'公告详情\');">
											<span data-toggle="tooltip">
											'.$title.'
											</span></span></strong>
											<p class="m-t-xs">
												<i class="fa fa-navicon"></i> [ '.$res['id'].' ] 用户中心
											</p>
											<p class="m-t-xs">
												<span class="text-info"><i class="fa fa-user"></i> [ '.$res['publisher'].' ] </span>
											</p>
											<p class="m-t-xs">
												<small class="text-muted clear text-ellipsis"><i class="fa fa-clock-o"></i> '.$res['addtime'].'</small>
											</p>
										</div>';
											}
										?>
								 <?php }else{ ?>
								<div class="table-responsive">
									<table class="table table-striped b-t b-light">
									<thead>
									<tr>
										<th style="width:40px;" class="hidden-sm hidden-xs">
											<label class="i-checks m-b-none"><input type="checkbox"><i></i></label>
										</th>
										<th>ID/位置</th>
										<th>标题/内容</th>
										<th>发布时间</th>
										<th>发布人</th>
										<th>点击次数</th>
										<th>状态</th>
										<th class="text-right">操作</th>
									</tr>
									</thead>
									<tbody>
										<?php
											$rs=$DB->query("select * from saves_gonggao where{$sql} order by id desc limit $pageu,$pagesize");
												while($res = $DB->fetch($rs))
												{
													$active=checkggoff($res['active']);
													$title=htmlspecialchars(cut_str($res['title'],8));
													$content=htmlspecialchars(cut_str($res['content'],10));
													echo '<tr>
													<td class="hidden-sm hidden-xs"><label class="i-checks m-b-none"><input type="checkbox"><i></i></label></td>
													<td>[ <span class="text-info">'.$res['id'].'</span> ] 用户中心 </td>
													<td>[ <span>'.$title.'</span> ]
														</br>
														[ <span>'.$content.'</span> ]
													</td>
													<td class="text-dark">'.$res['addtime'].'</td>
													<td><span class="text-primary">'.$res['publisher'].'</span>	</td>
													<td>'.$res['look'].' 次</td>
													<td>
														<label class="i-switch i-switch-md bg-info m-t-xs"><input type="checkbox" '.$active.'><i></i></label>
													</td>
													<td class="text-right">
														<div class="btn-group dropdown">
															<a href="javascript:;" data-toggle="dropdown" class="dropdown-toggle clear btn btn-default" aria-expanded="false">操作 <span class="caret"></span></a>
															<ul class="dropdown-menu animated fadeInUp" style="left:auto;right:0;">
																<li><a href="javascript:;" href="javascript:" onclick="saves.mode(\'./index.php?m=Admin&v=gonggao&act=editgonggao&id='.$res['id'].'\',\'编辑公告\')">编辑公告</a></li>
																<li><a href="javascript:;" onclick="saves.mode(\'./index.php?m=User&v=gonggao&act=seegonggao&id='.$res['id'].'\',\'公告详情\');">查看公告</a></li>
																<li><a href="javascript:;" onclick="deletegonggao(\''.$res['id'].'\')">删除公告</a></li>
															</ul>
														</div>
													</td>
												</tr>';
											}
										?>
									</tbody>
									</table>
								</div>
								<?php } ?>
								<div class="panel-footer">
<?php
echo'<nav class="text-center"><ul class="pagination justify-content-center">';
$s = ceil($myaccount / $pagesize);
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$s;
if ($page>1)
{
echo '<li><a href="/Public/Auth/authlist.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="/Public/Auth/authlist.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="/Public/Auth/authlist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$s;$i++)
echo '<li><a href="/Public/Auth/authlist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$s)
{
echo '<li><a href="/Public/Auth/authlist.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="/Public/Auth/authlist.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
</div>
<script type="text/javascript">
$().ready(function() {
	$("[id=off]").click(function() {
		var id = $(this).attr("name");
		layer.load(1);
		setTimeout(function() {
			$.ajax({
				url: '/index/admin/gginfo/id/'+id,
				type: 'post',
				dataType: 'json',
				data: {
					zt: id
				},
				success: function(data) {
					layer.closeAll('loading');
					layer.msg(data.msg);
				}
			});
		}, 500);
	})
});
$().ready(function() {
	$("[id=delete]").click(function() {
		var id = $(this).attr("name");
		layer.confirm('您确定要删除吗？', {
		    icon: 3,
			btn: ['确认', '取消']
		}, function(index) {
			layer.close(index);
			layer.load(1);
	        setTimeout(function() {
	        	$.ajax({
	        		url: '/index/admin/gginfo/id/'+id,
	        		type: 'post',
	        		dataType: 'json',
	        		data: {
	        			deleteid: id
	        		},
	        		success: function(data) {
	        			layer.closeAll('loading');
	        			if (data.code == 1) {
	        				$('#mode' + id).html('');
	        				layer.msg(data.msg);
	        			} else {
	        				layer.msg(data.msg);
	        			}
	        		}
	        	});
	        }, 500);
		});
	})
});
</script>
<?php include 'footer.php'; ?>