<?php
$indextitle='API配置';
include TEMPLATE_ROOT.'Admin/head.php';
?>
				<div class="wrapper">
					<div class="col-lg-8 col-md-12 col-lg-offset-2" role="main">
						<div class="panel panel-info">
							<div class="panel-heading font-bold">
				            API配置
							</div>
							<div class="panel-body padder-v">
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">网易云API地址：</label>
										<div class="col-sm-10">
											<input class="form-control" name="wyyapiurl" value="<?=$conf['wyyapiurl']?>"></input>
										</div>
									</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">BiliAPI地址：</label>
										<div class="col-sm-10">
											<input class="form-control" name="biliapiurl" value="<?=$conf['biliapiurl']?>"></input>
										</div>
									</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">步数API地址：</label>
										<div class="col-sm-10">
											<input class="form-control" name="stepapiurl" value="<?=$conf['stepapiurl']?>"></input>
										</div>
									</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">爱奇艺API地址：</label>
										<div class="col-sm-10">
											<input class="form-control" name="iqyapiurl" value="<?=$conf['iqyapiurl']?>"></input>
										</div>
									</div>
                                    <div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">ApiCode：</label>
										<div class="col-sm-10">
											<input class="form-control" name="apicode" value="<?=$conf['apicode']?>"></input>
										</div>
									</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<input class="btn btn-info btn-block btn-outline btn-rounded font-bold" onclick="apiset()" type="submit">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
</div>
<?php include 'footer.php'; ?>