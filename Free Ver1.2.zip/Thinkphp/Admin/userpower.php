<?php
$uid = $_GET['uid'];
$user=$DB->get_row("select * from saves_user where uid='".$uid."' limit 1");
if($user==''){
	exit("<script language='javascript'>layer.msg('请先选择要更改的用户....', {icon:2}, function(){window.location.href='./index.php?m=Admin&v=userlist'});</script>");
}
?>
<b name="uid" value="<?=$user['uid']?>">当前操作帐号UID：<?=$user['uid']?>&nbsp;&nbsp;[<span class="text-success"> <?php echo get_qqnick($user['qq']) ?> </span>]</b>
<div class="line line-dashed b-b line-md"></div>
<b>当前帐号身份标识：[<span class="text-info"><?php echo checkuserlevel($res['power'],$res['vip'])?><span></b>]
<div class="line line-dashed b-b line-md"></div>
    取消对方等级时会清空他生成的全部卡密和权限，如非必要，请勿轻易更改用户等级
<div class="line line-dashed b-b line-md"></div>
    <p style="margin-bottom:6px;font-size:12px;">请选择用户等级：</p>
<div class="input-group">
    <span class="input-group-addon">等级</span>
    <select name="vip" class="form-control">
    <?php if ($user['vip']==1){?>
        <option value="3" selected="selected">取消该用户VIP</option>
        <option value="1">将该用户设置成VIP</option>
    <?php }else{ ?>
        <option value="1" selected="selected">将该用户设置成VIP</option>
        <option value="3">取消该用户VIP</option>
    <?php } ?>
    </select>
    <select name="power" class="form-control">
    <?php if ($user['power']==0){?>
        <option value="9" selected="selected">设置该用户为平台站长</option>
        <option value="2">取消该用户为平台站长</option>
    <?php }else{ ?>
        <option value="2" selected="selected">取消该用户平台站长等级</option>
        <option value="9">设置该用户平台站长等级</option>
    <?php } ?>
    </select>
    
</div>
<div class="line line-dashed b-b line-md"></div>
    <button class="btn btn-info btn-block m-b-xs m-t-xs" type="button" name="uid" value="<?=$user['uid']?>" onclick="edituserpower()">确定</button>
<div class="line line-dashed b-b line-md"></div>
    <span style="font-size:10px; color:#999;">注：用户等级调整操作系统会发送一条邮箱消息通知用户</span>