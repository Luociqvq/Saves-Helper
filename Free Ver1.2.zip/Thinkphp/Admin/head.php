<?php
include TEMPLATE_ROOT.'Admin/header.php';
?>
<div id="aside" class="app-aside hidden-xs bg-white b-r">
		<div class="aside-wrap">
			<div class="navi-wrap">
				<div class="clearfix text-center">
					<div class="dropdown wrapper">
						<a href="javascript:;" data-toggle="dropdown" class="dropdown-toggle hidden-folded"><span class="thumb-lg w-auto-folded avatar">
                        <img alt="image" class="img-full b b-3x b-white" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['qq']?>&spec=100" style="width:70px;border:1px solid #B5B5B5;padding:3px;"></span></a>
                        <a href="javascript:;" data-toggle="dropdown" class="dropdown-toggle hidden-folded">
                        <span class="clear"><span class="block m-t-sm">
                        <strong class="font-bold text-lt"><?=$userrow['user']?></strong>
                        <b class="caret"></b></span>
                        <span class="text-muted text-xs block"> UID:<?=$userrow['uid']?></span></span></a>
						<ul class="dropdown-menu animated fadeInRight w hidden-folded">
							<li class="wrapper b-b bg-info m-t-n-xs"><span class="arrow top hidden-folded arrow-info"></span>
							<div>
								<p class="text-center">
									<?=$userrow['user']?>
								</p>
							</div>
							<progressbar value="60" type="white" class="progress-xs m-b-none dker"></progressbar></li>
							<li><a href="./index.php?m=User&v=account" data-pjax><i class="fa fa-user-o"></i> &nbsp;&nbsp;账户资料</a></li>
							<li class="divider"></li>
							<li><a onclick="userlogout()"><i class="fa fa-sign-out"></i> &nbsp;&nbsp;退出登陆</a></li>
						</ul>
					</div>
					<div class="line dk hidden-folded">
					</div>
				</div>
				<nav ui-nav class="navi">
				<ul class="nav">
					<li class="hidden-folded padder text-muted text-xs"><span>导航</span></li>
					<li class=""><a href="javascript:;" class="auto">
						<span class="pull-right text-muted">
						<i class="fa fa-fw fa-angle-right text"></i>
						<i class="fa fa-fw fa-angle-down text-active"></i></span>
						<i class="fa fa-th"></i><span class="font-bold">后台中心</span></a>
						<ul class="nav nav-sub dk" style="display: none;">
						<li><a href="./index.php?m=Admin&v=index" data-pjax=""><span>后台中心</span></a></li>
						<?php if($userrow['power']==9){?>
						<li><a href="./index.php?m=User&v=index" data-pjax=""><span>用户中心</span></a></li>
						<?php }else{ ?>
						<?php }?>
						</ul>
                    </li>
					<li class="hidden-folded padder text-muted text-xs"><span>管理中心</span></li>
					<li class=""><a href="javascript:;" class="auto">
						<span class="pull-right text-muted">
						<i class="fa fa-fw fa-angle-right text"></i>
						<i class="fa fa-fw fa-angle-down text-active"></i></span>
						<i class="fa fa-cog"></i><span class="font-bold">系统信息</span></a>
						<ul class="nav nav-sub dk" style="display: none;">
							<li><a href="./index.php?m=Admin&v=webset"><span>网站设置</span></a></li>
							<li><a href="./index.php?m=Admin&v=apiset"><span>云端设置</span></a></li>
							<li><a href="./index.php?m=Admin&v=viplist"><span>VIP设置</span></a></li>
							<li><a href="./index.php?m=Admin&v=functionset"><span>功能设置</span></a></li>
							<li><a href="./index.php?m=Admin&v=cron"><span>监控设置</span></a></li>
						</ul>
                    </li>
					<li class=""><a href="javascript:;" class="auto">
						<span class="pull-right text-muted">
						<i class="fa fa-fw fa-angle-right text"></i>
						<i class="fa fa-fw fa-angle-down text-active"></i></span>
						<i class="fa fa-navicon"></i><span class="font-bold">数据管理</span></a>
						<ul class="nav nav-sub dk" style="display: none;">
						<li><a href="./index.php?m=Admin&v=userlist"><span>用户账号管理</span></a></li>
						<li><a href="./index.php?m=Admin&v=wyylist"><span>网易云账号管理</span></a></li>
						<li><a href="./index.php?m=Admin&v=gglist"><span>公告管理</span></a></li>
						</ul>
                    </li>
					<li>
						<a href="./index.php?m=Admin&v=update">
						<i class="fa fa-cloud-download"></i>
						<span class="font-bold">在线更新</span></a>
                    </li>
					<li>
						<a onclick="userlogout()">
						<i class="fa fa-sign-out"></i>
						<span class="font-bold">退出登录</span></a>
                    </li>
				  </ul>
				</nav>
			</div>
		</div>
	</div>
    <!-- 导航部分结束 -->
	<div id="content" class="">
	<div class="app-content">
 <section id="ajaxshow"></section>
  <section id="container">
	<div class="app-content-body animated fadeInUp">
		<div class="hbox hbox-auto-xs hbox-auto-sm">
			<div class="col">
				<div class="bg-light lter b-b wrapper-sm ng-scope">
					<ul class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="/">Saves-Cloud</a></li>
						<li><?=$indextitle?></li>
					</ul>
				</div>
