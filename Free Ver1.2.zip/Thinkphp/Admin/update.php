<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='系统在线更新';
include TEMPLATE_ROOT.'Admin/head.php';
$new = connectcloud();
?>
                <div class="wrapper">
					<div class="col-lg-8 col-md-12 col-lg-offset-2">
						<div class="panel panel-info">
							<div class="panel-heading bg-primary info font-bold text-center">
								系统在线更新
							</div>
                            <?php if($new['updatecode']==2){?>
                            <div class="row wrapper">
                                <div class="block-options-item">
                                    <div class="alert alert-success py-2 mb-0 small text-center">
                                        <i class="fa fa-check-circle opacity-50 me-1"></i> 你已经是最新版本  目前 Ver : <?=$conf['version']?>
                                    </div>
                                 </div>
							</div>
                            <?php }elseif($new['updatecode']==1){ ?>
                                <?php if (!class_exists('ZipArchive') || ini_get('acl.app_id') || defined('SAE_ACCESSKEY') || defined('BAE_ENV_APPID')) { ?>
                                    <div class="row wrapper">
                                        <div class="block-options-item">
                                            <div class="alert alert-success py-2 mb-0 small text-center">
                                                <i class="fa fa-check-circle opacity-50 me-1"></i> 您的空间不支持自动更新，请手动下载更新包并覆盖到程序根目录！
                                            </div>
                                            <a href="<?=$new['updatefile']?>" class="btn btn-primary btn-block">点击下载</a>
                                        </div>
							        </div>
                                <?php }else{ ?>
                                <div class="row wrapper">
                                    <div class="block-options-item">
                                        <div class="alert alert-success py-2 mb-0 small text-center">
                                                <i class="fa fa-cloud opacity-50 me-1"></i> <?=$new['updatemsg']?>
                                        </div>
                                        <a href="../../ajax.php?act=update" class="btn btn-info btn-block">立即更新到最新版本</a>
                                    </div>
                                    <hr/>
                                    <blockquote>
				                        <p><?=$new['updatelog']?></p>
			                        </blockquote>
							    </div>
                                <?php } ?>
                            <?php }else{ ?>
                            <div class="row wrapper">
                                <div class="block-options-item">
                                    <div class="alert alert-info py-2 mb-0 small text-center">
                                        <i class="fa fa-check-circle opacity-50 me-1"></i> 啊哦, API失联了, 请稍等后查看更新
                                    </div>
                                 </div>
							</div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
		    </div>
	     </div>
   </div>
 </section>
</div>
<?php include 'footer.php'; ?>