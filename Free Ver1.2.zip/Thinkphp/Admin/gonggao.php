<?php
if(!defined('IN_CRONLITE'))exit();
if(!$userrow['power']==9){
	exit("<script language='javascript'>layer.msg('你无权限操作....', {icon:2}, function(){window.location.href='./index.php?m=User&v=index'});</script>");
}
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;
?>
    <!-- 发布新公告 -->
    <?php  if($_GET['act'] == 'newgonggao'){ ?>
    <div class="input-group">
        <span class="input-group-addon">公告状态</span>
            <select name="active" class="form-control m-b">
                <option value="1">正常</option>
                <option value="0">关闭</option>
            </select>
    </div>
    <div class="line line-dashed b-b line-md"></div>
    <div class="input-group">
        <span class="input-group-addon">公告标题</span>
            <input type="text" class="form-control" placeholder="请输入公告标题" name="title" value="">
    </div>
    <div class="line line-dashed b-b line-md"></div>
        <div class="input-group">
            <span class="input-group-addon">公告内容</span>
            <textarea class="form-control" name="content" rows="10"></textarea>
        </div>
    <div class="line line-dashed b-b line-md"></div>
        <input onclick="newgonggao()" type="submit" value="保存" class="btn btn-info btn-block"/>
    <?php 
        }elseif($_GET['act'] == 'editgonggao'){
            $id=daddslashes($_GET['id']);
        	$row=$DB->get_row("SELECT * FROM saves_gonggao WHERE id='$id'");
            if($row == ''){
                swwalert('请勿恶意提交数据访问页面');
            }
            if($row['active']==1){
                $active='<option value="1">正常</option> <option value="0">关闭</option>';
            }elseif($row['active']==0){
                $active='<option value="0">关闭</option> <option value="1">正常</option>';
            }
    ?>
        <div class="input-group">
            <span class="input-group-addon">公告状态</span>
            <select name="active" class="form-control m-b">
                <?=$active?>
            </select>
        </div>
        <div class="line line-dashed b-b line-md"></div>
        <div class="input-group">
            <span class="input-group-addon">公告标题</span>
            <input type="text" class="form-control" placeholder="请输入公告标题" name="title" value="<?=$row['title']?>">
        </div><div class="line line-dashed b-b line-md"></div>
        <div class="input-group">
            <span class="input-group-addon">公告内容</span>
            <textarea class="form-control" name="content" rows="10"><?=$row['content']?></textarea>
        </div>
        <div class="line line-dashed b-b line-md"></div>
            <button class="btn btn-info btn-block btn-outline btn-rounded font-bold" type="button" name="id" value="<?=$row['id']?>" onclick="editgonggao()">确定</button>
    <?php 
        }elseif($_GET['act'] == 'cloudgonggao'){
            $id=daddslashes($_GET['id']);
        	$row=$DB->get_row("SELECT * FROM saves_gonggao WHERE id='$id'");
            if($row == ''){
                swwalert('请勿恶意提交数据访问页面');
            }
            if($row['active']==1){
                $active='<option value="1">正常</option> <option value="0">关闭</option>';
            }elseif($row['active']==0){
                $active='<option value="0">关闭</option> <option value="1">正常</option>';
            }
    ?>
    <?php }else{ swwalert('What are you doing?'); } ?>