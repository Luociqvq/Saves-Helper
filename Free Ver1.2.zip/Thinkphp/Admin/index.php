<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='管理后台';
include TEMPLATE_ROOT.'Admin/head.php';
$users=$DB->count("SELECT count(*) from saves_user WHERE 1");
$wyys=$DB->count("SELECT count(*) from saves_user WHERE wyyjob='1'");
?>
               		<div class="wrapper">
						<div class="col-lg-6">
							<div class="panel b-a">
								<div class="panel-heading bg-info dk no-border wrapper-lg">
								</div>
								<div class="text-center m-b clearfix">
									<div class="thumb-lg avatar m-t-n-xl">
                                        <span id="img">加载中...</span>
									</div>
									<div class="h4 font-thin m-t-sm">
										<span id="qqname">加载中...</span>
									</div>
									<span class="text-muted text-xs block"><?php echo checkuserlevel($userrow['power'],$userrow['vip']); ?> | <?=$userrow['user']?> | UID: <?=$userrow['uid']?></span>
								</div>
								<div class="hbox text-center b-t b-light">
							        <div class="col padder-v text-muted">
							               <div class="h2 font-bold">
							        	   <span id="url">加载中...</span>
							        	   </div>
							               <span>本站访问域名</span> 
							        </div> 
								</div>
								</br>
							</div>
						</div>
						<div class="col-lg-6">
						<div class="panel panel-info">
							<div class="panel-heading font-bold">系统公告</div>
							<div class="list-group no-radius alt" id="cloudgonggao"></div> 
						</div>
					    </div>
						<div class="col-lg-12">
							<div class="panel">
								<div class="bg-white" style="overflow:hidden;">
									<div class="col-md-6">
										<div class="ibox float-e-margins">
											<h5 style="font-weight:700; padding-left:10px;">网站信息总计</h5>
											<table class="table table-stripped small m-t-md">
											<tbody>
											<tr>
												<td class="no-borders">
													<i class="fa fa-circle text-info"></i>
												</td>
												<td class="no-borders">
													总用户量：<span id="users">加载中...</span> 位
												</td>
											</tr>
											<tr>
												<td>
													<i class="fa fa-circle text-info"></i>
												</td>
												<td>
													总网易云数：<span id="wyys">加载中...</span> 个
												</td>
											</tr>
											<tr>
												<td>
													<i class="fa fa-circle text-info"></i>
												</td>
												<td>
													总VIP数：<span id="vips">加载中...</span> 个
												</td>
											</tr>
											</tbody>
											</table>
										</div>
									</div>
									<div class="col-md-6">
										<div class="ibox float-e-margins">
											<h5 style="font-weight:700; padding-left:10px;">今日信息统计</h5>
											<table class="table table-stripped small m-t-md">
											<tbody>
											<tr>
												<td class="no-borders">
													<i class="fa fa-circle text-info"></i>
												</td>
												<td class="no-borders">
													正常用户：<span id="normaluser">加载中...</span> 个
												</td>
											</tr>
											<tr>
												<td>
													<i class="fa fa-circle text-info"></i>
												</td>
												<td>
													正常挂机：<span id="normaljob">加载中...</span> 个
												</td>
											</tr>
											<tr>
												<td>
													<i class="fa fa-circle text-info"></i>
												</td>
												<td>
													失效挂机：<span id="invalidjob">加载中...</span> 个
												</td>
											</tr>
											</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
		    </div>
	     </div>
   </div>
 </section>
</div>
<?php include 'footer.php'; ?>
<script type="text/javascript">
saves.amount('./ajax.php?act=adminamount','加载完成');
</script>