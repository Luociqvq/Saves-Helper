<?php
if(!defined('IN_CRONLITE'))exit();
if(!$userrow['power']==9){
	exit("<script language='javascript'>layer.msg('你无权限操作....', {icon:2}, function(){window.location.href='./index.php?m=User&v=index'});</script>");
}
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;
?>
    <!-- 发布新公告 -->
    <?php  if($_GET['act'] == 'addvip'){ ?>
    <div class="text-center"><b>新建VIP等级</b></div>
    <div class="line line-dashed b-b line-md"></div>
        <div class="form-group" style="overflow:hidden">
            <label class="col-sm-2 control-label" style="text-align:right;padding-top:9px">VIP时间: </label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="value" placeholder="请输入VIP时间" maxlength="7">
                <small class="help-block m-b-none text-muted">VIP时长! 例:一个月</small>
            </div>
        </div>
        <div class="line line-dashed b-b line-md"></div>
        <div class="form-group" style="overflow:hidden">
            <label class="col-sm-2 control-label" style="text-align:right;padding-top:9px">VIP类型: </label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="type" placeholder="请输入VIP类型" maxlength="7">
                <small class="help-block m-b-none text-muted">VIP类型!例:1(一个月),2(三个月),3(九个月)</small>
            </div>
        </div>
        <div class="line line-dashed b-b line-md"></div>
        <div class="form-group" style="overflow:hidden">
            <label class="col-sm-2 control-label" style="text-align:right;padding-top:9px">VIP价格: </label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="price" placeholder="请输入VIP价格" maxlength="7">
            </div>
        </div>
        <div class="line line-dashed b-b line-md"></div>
        <input onclick="addviplevel()" type="submit" value="添加" class="btn btn-info btn-block"/>
    <?php 
        }elseif($_GET['act'] == 'editvip'){
            $id=daddslashes($_GET['id']);
        	$row=$DB->get_row("SELECT * FROM saves_vip WHERE id='$id'");
            if($row == ''){
                swwalert('请勿恶意提交数据访问页面');
            }
    ?>
        <div class="input-group">
            <span class="input-group-addon">VIP类型: </span>
            <input type="text" class="form-control" name="type" value="<?=$row['type']?>">
        </div><div class="line line-dashed b-b line-md"></div>
        <div class="input-group">
            <span class="input-group-addon">VIP时间: </span>
            <input type="text" class="form-control" name="value" value="<?=$row['value']?>">
        </div>
        <div class="line line-dashed b-b line-md"></div>
        <div class="input-group">
            <span class="input-group-addon">VIP价格: </span>
            <input type="text" class="form-control" name="price" value="<?=$row['price']?>">
        </div>
        <div class="line line-dashed b-b line-md"></div>
            <button class="btn btn-info btn-block btn-outline btn-rounded font-bold" type="button" name="id" value="<?=$row['id']?>" onclick="editviplevel()">确定</button>
    <?php }else{ swwalert('What are you doing?'); } ?>