	  </div>
	  		<div>
			</div>
			<div id="footer" class="app-footer wrapper-sm b-t bg-light text-xs">
				<span class="pull-right"><?=$conf['version']?> <a href="#" class="m-l-sm text-muted"><i class="fa fa-long-arrow-up"></i></a></span><strong>Copyright</strong> Saves-Cloud &copy; 2020
			</div>
		</div>
		</div>
		</body>
		<button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#myModa" id="modal"
        style="display:none;"></button>
<div class="modal inmodal fade" id="myModa" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span
                        class="sr-only">关闭</span></button>
                <h4 class="modal-title" id="biaoti"></h4></div>
            <div class="modal-body" id="showInfo"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">关闭</button>
            </div>
        </div>
    </div>
</div>
</html>
