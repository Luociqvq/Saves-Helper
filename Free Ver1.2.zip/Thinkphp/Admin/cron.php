<?php
if(!defined('IN_CRONLITE'))exit();
$indextitle='监控列表';
include TEMPLATE_ROOT.'Admin/head.php';
$users=$DB->count("SELECT count(*) from saves_user WHERE 1");
$wyys=$DB->count("SELECT count(*) from saves_user WHERE wyyjob='1'");
?>
        <div class="wrapper">
			<div class="col-lg-8 col-md-12 col-lg-offset-2" role="main">
				<div class="panel panel-info">
					<div class="panel-heading font-bold">
				        监控列表
					</div>
            <div class="table-responsive">
                <table class="table table-striped b-t b-light">
                    <thead>
                    <tr>
                        <th>监控项目</th>
                        <th>监控频率</th>
                        <th>监控地址</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>网易云歌曲打卡</td>
                        <td>12H</td>
                        <td><?=$siteurl?>Taskcron/songcron.php
                            <a id="copy" data-clipboard-text="<?=$siteurl?>Taskcron/songcron.php" class="text-ab pull-right m-r-xs copy">复制</a>
                        </td>
                    </tr>
                    <tr>
                        <td>网易云签到</td>
                        <td>12H</td>
                        <td><?=$siteurl?>Taskcron/signcron.php
                            <a id="copy" data-clipboard-text="<?=$siteurl?>Taskcron/songcron.php" class="text-ab pull-right m-r-xs copy">复制</a>
                        </td>
                    </tr>
                    <tr>
                        <td>网易云云贝任务</td>
                        <td>12H</td>
                        <td><?=$siteurl?>Taskcron/yunbeitask.php
                            <a id="copy" data-clipboard-text="<?=$siteurl?>Taskcron/yunbeitask.php" class="text-ab pull-right m-r-xs copy">复制</a>
                        </td>
                    </tr>
                    <tr>
                        <td>网易云音乐人任务</td>
                        <td>12H</td>
                        <td><?=$siteurl?>Taskcron/musician.php
                            <a id="copy" data-clipboard-text="<?=$siteurl?>Taskcron/musician.php" class="text-ab pull-right m-r-xs copy">复制</a>
                        </td>
                    </tr>
                    <tr>
                        <td>网易云合伙人评分任务</td>
                        <td>12H</td>
                        <td><?=$siteurl?>Taskcron/evaluate.php
                            <a id="copy" data-clipboard-text="<?=$siteurl?>Taskcron/evaluate.php" class="text-ab pull-right m-r-xs copy">复制</a>
                        </td>
                    </tr>
                    <tr>
                        <td>网易云自动更新状态</td>
                        <td>12H</td>
                        <td><?=$siteurl?>Taskcron/wyyinfocron.php
                            <a id="copy" data-clipboard-text="<?=$siteurl?>Taskcron/wyyinfocron.php" class="text-ab pull-right m-r-xs copy">复制</a>
                        </td>
                    </tr>
                    <tr>
                        <td>步数任务</td>
                        <td>12H</td>
                        <td><?=$siteurl?>Taskcron/stepcron.php
                            <a id="copy" data-clipboard-text="<?=$siteurl?>Taskcron/stepcron.php" class="text-ab pull-right m-r-xs copy">复制</a>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="line line-dashed b-b line-md">
			</div>
            <div>
				<b class="font-bold"><center>监控完监控网址后即可执行任务，监控频率仅供参考，请根据自己需求和服务器配置监控!</center></b>
			</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
</div>
<?php include 'footer.php'; ?>
<script>
    var clipboard = new Clipboard('.copy');
    clipboard.on('success', function (e) {
        layer.msg("复制成功");
    });
    clipboard.on('error', function (e) {
        document.querySelector('.copy');
        layer.msg("复制失败");
    });
</script>