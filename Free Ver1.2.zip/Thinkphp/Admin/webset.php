<?php
$indextitle='网站管理';
include TEMPLATE_ROOT.'Admin/head.php';
?>
				<div class="wrapper">
					<div class="col-lg-8 col-md-12 col-lg-offset-2" role="main">
						<div class="panel panel-info">
							<div class="panel-heading font-bold">
				            网站资料
							</div>
							<div class="panel-body padder-v">
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">网站标题：</label>
										<div class="col-sm-10">
											<textarea class="form-control" style="height:35px;resize:none" name="web_title" id="web_title" rows="4"><?=$conf['web_title']?></textarea><small class="help-block m-b-none text-muted">网站名称建议4-6个文字，太长会造成前台显示问题</small>
										</div>
									</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">站长QQ：</label>
										<div class="col-sm-10">
											<textarea class="form-control" style="height:35px;resize:none" name="web_qq" id="web_qq" rows="4"><?=$conf['web_qq']?></textarea>
										</div>
									</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">访问域名：</label>
										<div class="col-sm-10">
											<textarea class="form-control" style="height:35px;resize:none" rows="4" disabled><?=$siteurl?></textarea>
											<small class="help-block m-b-none text-muted">用于访问，此域名禁止修改！</small>
										</div>
									</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">网站描述：</label>
										<div class="col-sm-10">
											<textarea class="form-control" name="web_description" id="web_description" rows="4"><?=$conf['web_description']?></textarea>
											<small class="help-block m-b-none text-muted">此项为搜索SEO优化作用，说明 <a href="http://www.chinaz.com/web/2014/0513/351260.shtml" target="_blank">点击查看</a></small>
										</div>
									</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">网站关键词：</label>
										<div class="col-sm-10">
											<textarea class="form-control" name="web_keywords" id="web_keywords" rows="4"><?=$conf['web_keywords']?></textarea>
											<small class="help-block m-b-none text-muted">此项为搜索SEO优化作用，说明 <a href="http://www.chinaz.com/web/2014/0513/351260.shtml" target="_blank">点击查看</a></small>
										</div>
									</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">在线支付API：</label>
										<div class="col-sm-10">
											<input class="form-control" name="payapi" value="<?=$conf['payapi']?>"></input>
										</div>
									</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">在线支付PID：</label>
										<div class="col-sm-10">
											<input class="form-control" name="paypid" value="<?=$conf['paypid']?>"></input>
										</div>
									</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">在线支付KEY：</label>
										<div class="col-sm-10">
											<input class="form-control" name="paykey" value="<?=$conf['paykey']?>"></input>
										</div>
									</div>
									<?php if($conf['regmoneyopen']==1){?>
                            		<div class="line line-dashed b-b line-md">
									</div>
									<div class="form-group" style="overflow:hidden;">
										<label class="col-sm-2 control-label" style="text-align:right;padding-top:9px;">注册赠送余额</label>
										<div class="col-sm-10">
											<input class="form-control" name="regmoney" value="<?=$conf['regmoney']?>"></input>
										</div>
									</div>
									<?php } ?>
									<div class="line line-dashed b-b line-md">
									</div>
									<div class="input-group" style="overflow:hidden;">
            							<span class="input-group-addon">注册赠送余额开关</span>
                							<select name="regmoneyopen" class="form-control m-b" value="<?=$conf['regmoneyopen']?>">
                    						<?php if($conf['regmoneyopen']==1){?>
                                           	 	<option value="1">开启</option>
                                            	<option value="2">关闭</option>
											<? }else{ ?>
												<option value="2">开启</option>
												<option value="1">关闭</option>
											<? } ?>
                							</select>
        							</div>
									<div class="line line-dashed b-b line-md">
									</div>
									<input class="btn btn-info btn-block btn-outline btn-rounded font-bold" onclick="webset()" type="submit">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
</div>
<?php include 'footer.php'; ?>