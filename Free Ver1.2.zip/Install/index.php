<?php
/*
 * 安装文件
 * Author：Luoci
 * Date:2021/12/30
 */

//设置程序根目录
define('ROOT', dirname(dirname(__FILE__)));
include '../Cores/function.php';
$databaseFile = '../Cores/config.php';
if (file_exists($databaseFile)) {
    error('你已经成功安装，如需重新安装，请手动删除Core/Config.php配置文件！');
}

$step = isset($_GET['step']) ? $_GET['step'] : 1;
$action = isset($_POST['action']) ? $_POST['action'] : null;

if ($action == 'install') {
    $host = isset($_POST['host']) ? $_POST['host'] : null;
    $port = isset($_POST['port']) ? $_POST['port'] : null;
    $user = isset($_POST['user']) ? $_POST['user'] : null;
    $pwd = isset($_POST['pwd']) ? $_POST['pwd'] : null;
    $database = isset($_POST['database']) ? $_POST['database'] : null;
    if (empty($host) || empty($port) || empty($user) || empty($pwd) || empty($database)) {
        $errorMsg = '请填完所有数据库信息';
    } else {
        $mysql['host'] = $host;
        $mysql['port'] = $port;
        $mysql['dbname'] = $database;
        $mysql['user'] = $user;
        $mysql['pwd'] = $pwd;
        try {
            $db = new PDO("mysql:host=" . $mysql['host'] . ";dbname=" . $mysql['dbname'] . ";port=" . $mysql['port'], $mysql['user'], $mysql['pwd']);
        } catch (Exception $e) {
            $errorMsg = '链接数据库失败:' . $e->getMessage();
        }
        if (empty($errorMsg)) {
            $data='<?php
/*Author：Luoci*/
/*数据库信息配置*/
$host = "'.$_POST['host'].'"; //MYSQL主机
$port = '.$_POST['port'].'; //MYSQL主机
$user = "'.$_POST['user'].'"; //MYSQL用户
$pwd ="'.$_POST['pwd'].'"; //MYSQL密码
$dbname = "'.$_POST['database'].'"; //数据库名
?>';
			writefile('../Cores/config.php',$data);
            $db->exec("set names utf8");
            $sqls = file_get_contents('install.sql');
            $sqls = explode(';', $sqls);
            $success = 0;
            $error = 0;
            $errorMsg = null;
            foreach ($sqls as $value) {
                $value = trim($value);
                if (!empty($value)) {
                    if ($db->exec($value) === false) {
                        $error++;
                        $dberror = $db->errorInfo();
                        $errorMsg .= $dberror[2] . "<br>";
                    } else {
                        $success++;
                    }
                }
            }
            $step = 3;
			@file_put_contents('Install.Lock','安装完成,欢迎使用Saves-云功能中心丨安装时间:'.date('y-m-d h:i:s',time()));
        }
    }
}

?>
<html lang="en"> 
	<head>
		<meta charset="utf-8" />
		<title>Saves-云功能中心 - 安装系统</title>
		<meta content="yes" name="apple-mobile-web-app-capable" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta name="renderer" content="webkit" />
		<link rel="stylesheet" href="../Assets/Install/css/wap.css" type="text/css" />
		<link rel="stylesheet" href="../Assets/Install/css/app.css" type="text/css" />
	</head>
	<body>
		<div class="container w-xxxl">
			<div class="bg-white b-t b-b">  
				<div class="panel-body">
					<div class="pull-hidden">
						<div class="pull-left m-r-sm">
							<img src="../Assets/Install/img/favicon.ico" class="img-rounded b b-2x b-default" width="60px" height="60px" />
						</div>
						<div class="h4 m-t-sm">
							Saves-云功能中心 - 安装系统
							<p class="text-muted pull-right text-xs" style="margin-top:15px;"></p>
						</div>
						<small class="text-muted">
							体验程序只差一步了!
						</small>
					</div>
				</div>
			</div>
			<div class="form-signin">
				<div class="login-wrap">	
                <?php
                if (isset($errorMsg)) {
                    echo '<div class="alert alert-danger text-center" role="alert">' . $errorMsg . '</div>';
                }
                if ($step == 2) {
                    ?>
                            <form class="form-horizontal" action="#" method="post">
                                <input type="hidden" name="action" class="form-control" value="install">
								<div class="list m-t-lg padder-0">
									<input type="text" placeholder="数据库地址" name="host" class="form-control no-border" value="localhost">
								</div>
								<div class="list m-t-lg padder-0">
									<input type="text" placeholder="数据库端口" name="port" class="form-control no-border" value="3306">
								</div>
								<div class="list m-t-lg padder-0">
									<input type="text" placeholder="数据库库名" name="database" class="form-control no-border">
								</div>
								<div class="list m-t-lg padder-0">
									<input type="text" placeholder="数据库用户名" name="user" class="form-control no-border">
								</div>
								<div class="list m-t-lg padder-0">
									<input type="password" placeholder="数据库密码" name="pwd" class="form-control no-border">
								</div>
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <button type="submit" class="btn btn-lg btn-info btn-block m-t-lg">确认无误，下一步</button>
                                    </div>
                                </div>
                            </form>
                <?php } elseif ($step == 3) { ?>
					<div class="list m-t">
						<i class="fa fa-heart fa-fw text-muted"></i>
						成功执行SQL语句<?php echo $success; ?>条，失败<?php echo $error; ?>条！
					</div>
                    <div class="list">
						<i class="fa fa-heart fa-fw text-muted"></i>
						系统安装完成！
					</div>
					<div class="list">
						<i class="fa fa-heart fa-fw text-muted"></i>
						账号：admin 密码：123456
					</div>
					<a href="/" class="btn btn-lg btn-info btn-block m-t-lg">访问首页</a>
                <?php } else { ?>
                        <?php
                        $install = true;
                        if (!file_exists('../Cores/config.php')) {
                            $check[2] = '<span class="badge">未锁定</span>';
                        } else {
                            $check[2] = '<span class="badge">已锁定</span>';
                            $install = false;
                        }
                        if (class_exists("PDO")) {
                            $check[0] = '<span class="badge">支持</span>';
                        } else {
                            $check[0] = '<span class="badge">不支持</span>';
                            $install = false;
                        }
                        if ($fp = @fopen("../Cores/test.txt", 'w')) {
                            @fclose($fp);
                            @unlink("../Cores/test.txt");
                            $check[1] = '<span class="badge">支持</span>';
                        } else {
                            $check[1] = '<span class="badge">不支持</span>';
                            $install = false;
                        }
                        if (version_compare(PHP_VERSION, '7.0.0', '<')) {
                            $check[3] = '<span class="badge">不支持</span>';
                        } else {
                            $check[3] = '<span class="badge">支持</span>';
                        }

                        ?>
						<div class="list m-t">
							<i class="fa fa-angle-right text-muted pull-right text-lg"></i>
							<p class="text-muted pull-right text-xs m-t-xxs"><?php echo $check[2]; ?></p>
							<i class="fa fa-heart fa-fw text-muted"></i>
							检测安装是否锁定 
						</div>
						<div class="list">
							<i class="fa fa-angle-right text-muted pull-right text-lg"></i>
							<p class="text-muted pull-right text-xs m-t-xxs"><?php echo $check[0]; ?></p>
							<i class="fa fa-heart fa-fw text-muted"></i>
							PDO_MYSQL组件 
						</div>
						<div class="list">
							<i class="fa fa-angle-right text-muted pull-right text-lg"></i>
							<p class="text-muted pull-right text-xs m-t-xxs"><?php echo $check[1]; ?></p>
							<i class="fa fa-heart fa-fw text-muted"></i>
							Core目录写入权限 
						</div>
						<div class="list">
							<i class="fa fa-angle-right text-muted pull-right text-lg"></i>
							<p class="text-muted pull-right text-xs m-t-xxs"><?php echo $check[3]; ?></p>
							<i class="fa fa-heart fa-fw text-muted"></i>
							PHP版本>=7.0 
						</div>
						<div class="list">
							<i class="fa fa-angle-right text-muted pull-right text-lg"></i>
							<i class="fa fa-heart fa-fw text-muted"></i>
							成功安装后安装文件就会锁定，如需重新安装，请手动删除Cores目录下config.php配置文件
						</div>
						<?php
							if ($install) echo '<a href="?step=2" class="btn btn-lg btn-info btn-block m-t-lg" type="submit">下一步</a>';
						?>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>