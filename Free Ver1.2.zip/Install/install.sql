/*
**Name：Saves-云功能中心
**Auther：Luoci
**Notes：数据表
*/

DROP TABLE IF EXISTS `saves_user`;
create table `saves_user` (
`uid` int(11) NOT NULL AUTO_INCREMENT,
`user` varchar(150) NOT NULL,
`pass` varchar(150) NOT NULL,
`last` datetime NOT NULL,
`dlip` varchar(15) DEFAULT NULL,
`active` int(1) DEFAULT NULL, /*1为正常  0为失效*/
`vip` INT(1) NOT NULL DEFAULT '0',
`vipdate` date NULL,
`email` varchar(150) NULL,
`city` varchar(16) DEFAULT NULL,
`money` decimal(10,2) NOT NULL DEFAULT '0.00',
`power` INT(1) NOT NULL DEFAULT '0',
`regtime` datetime NOT NULL,
`qq` VARCHAR(20) NOT NULL DEFAULT '0',
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `saves_user` (`uid`, `user`, `pass`, `last`, `dlip`, `active`, `qq`, `power`, `vip`, `regtime`) VALUES
(1, 'admin', '123456', '2022-06-07 20:57:28', '126.28.101.203', 1, '596844474', 9, 0, '2022-06-07 20:57:28');

DROP TABLE IF EXISTS `saves_wyy`;
CREATE TABLE IF NOT EXISTS `saves_wyy` (
  `wyyid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `tellphone` varchar(20) NOT NULL,
  `password` varchar(150) NOT NULL,
  `wyyuserid` varchar(20) NOT NULL,
  `MUSIC_U` varchar(888) DEFAULT NULL,
  `__csrf` varchar(888) DEFAULT NULL,
  `wyylevel` varchar(150) NULL,
  `wyyleveldays` varchar(150) NULL,
  `wyylevelsongs` varchar(150) NULL,
  `wyynowsongs` varchar(150) NULL,
  `wyynickname` varchar(150) NULL,
  `wyysignature` varchar(150) NULL,
  `wyyavatarUrl` varchar(150) NULL,
  `cookiezt` int(11) NOT NULL DEFAULT '0',/*0为正常  1为失效*/
  `addtime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`wyyid`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `saves_step`;
CREATE TABLE IF NOT EXISTS `saves_step` (
  `stepid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(21) NOT NULL,
  `stepuserid` varchar(20) NOT NULL,
  `stepapptoken` varchar(255) NOT NULL,
  `steplogintoken` varchar(255) NOT NULL,
  `stepuser` varchar(21) NOT NULL,
  `steppwd` varchar(21) NOT NULL,
  `stepnickname` varchar(21) NOT NULL,
  `stepavatarUrl` varchar(150) NULL,
  `cookiezt` int(11) NOT NULL DEFAULT '0',/*0为正常  1为失效*/
  `addtime` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL, /*COMMENT '打卡状态'*/
  PRIMARY KEY (`stepid`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 /*COMMENT '用户托管信息'*/;

DROP TABLE IF EXISTS `saves_stepjob`;
CREATE TABLE IF NOT EXISTS `saves_stepjob` (
  `jobid` int(11) NOT NULL AUTO_INCREMENT,
  `jobname` varchar(25) NOT NULL,
  `uid` int(11) NOT NULL,
  `stepuserid` varchar(20) NOT NULL,
  `type` varchar(25) NOT NULL,
  `start` int(1) DEFAULT '0',
  `change` int(1) DEFAULT '1',
  `startstep` int(21) NOT NULL DEFAULT '1',
  `endstep` int(21) NOT NULL DEFAULT '98000',
  `stepapptoken` varchar(255) NOT NULL,
  `steplogintoken` varchar(255) NOT NULL,
  `cookiezt` int(11) NOT NULL DEFAULT '0',/*0为正常  1为失效*/
  `times` int(255) DEFAULT '0',
  `lasttime` varchar(225) DEFAULT NULL,
  `adddate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`jobid`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `saves_wyyjob`;
CREATE TABLE IF NOT EXISTS `saves_wyyjob` (
  `jobid` int(11) NOT NULL AUTO_INCREMENT,
  `jobname` varchar(25) NOT NULL,
  `uid` int(11) NOT NULL,
  `wyyuserid` varchar(20) NOT NULL,
  `type` varchar(25) NOT NULL,
  `start` int(1) DEFAULT '0',
  `change` int(1) DEFAULT '1',
  `data` text,
  `cookiezt` int(11) NOT NULL DEFAULT '0',/*0为正常  1为失效*/
  `MUSIC_U` varchar(888) DEFAULT NULL,
  `__csrf` varchar(888) DEFAULT NULL,
  `times` int(255) DEFAULT '0',
  `lasttime` varchar(225) DEFAULT NULL,
  `adddate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`jobid`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `saves_vip`;
create table `saves_vip` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`type` varchar(10) NOT NULL,
`price` varchar(10) NOT NULL,
`value` varchar(15) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `saves_pay`;
create table `saves_pay` (
`trade_no` varchar(64) NOT NULL,
`type` varchar(20) DEFAULT NULL,
`addtime` datetime DEFAULT NULL,
`endtime` datetime DEFAULT NULL,
`name` varchar(64) DEFAULT NULL,
`money` varchar(32) NOT NULL,
`ip` varchar(20) DEFAULT NULL,
`uid` varchar(255) NOT NULL,
`status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`trade_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `saves_gonggao`;
CREATE TABLE `saves_gonggao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `publisher` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `look` varchar(255) DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `saves_log`;
CREATE TABLE `saves_log` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `user` varchar(20) DEFAULT NULL,
  `qq` varchar(20) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `time` datetime NOT NULL,
  `city` varchar(20) DEFAULT NULL,
  `data` text
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `saves_config`;
create table `saves_config` (
`k` varchar(32) NOT NULL,
`v` text NULL,

PRIMARY KEY  (`k`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `saves_config` (`k`, `v`) VALUES
('web_title', 'Save-Cloud'),
('web_keywords', 'Save-Cloud'),
('web_description', 'Save-Cloud'),
('cloudapi', 'api.t-ang.cn'),
('wyyapiurl', 'http://api.asenl.com'),
('stepapiurl', 'www.t-ang.cn'),
('biliapiurl', 'www.t-ang.cn'),
('iqyapiurl', 'www.t-ang.cn'),
('waimaiapiurl', 'www.t-ang.cn'),
('ksjsbapiurl', 'www.t-ang.cn'),
('apicode', ''),
('version', '1.2'),
('web_qq', '596844474'),
('wyyset', '2'),
('biliset', '2'),
('stepset', '2'),
('iqyset', '2'),
('regmoneyopen', '1'),
('regmoney', '2'),
('payapi', 'https://baidu.pc/'),
('paypid', '12312312'),
('paykey', '123123123');

