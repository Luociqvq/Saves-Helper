<?php
/*
 * 运行文件
 * Author：Luoci
 * Date:2022/1/12
 */
 
$Model=isset($_GET['m'])?$_GET['m']:'index';
$View=isset($_GET['v'])?$_GET['v']:'index';
$Controller=isset($_GET['c'])?$_GET['c']:'index';
include("./Cores/common.php");
?>