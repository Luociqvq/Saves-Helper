<?php
/*
 * 网易云打卡歌曲监控文件
 * Author：Luoci
 * Date:2022/1/12
 */
 
$Model = 'blank';
include '../Cores/common.php';
echo "<title>网易云打卡结果</title>";
$wyyusers = getwyyjob(wyysongs);
foreach ($wyyusers as $wyyuser){
	$url = "$wyyapi/Api/Music/daka.php";
	$cookie = "__csrf=".$wyyuser[10].";MUSIC_U=".$wyyuser[9]."";
	$output = curl_jsonget($url,$cookie);
	$time = $wyyuser[10]+1;
	$DB->query("update saves_wyyjob set times='{$time}',lasttime=Now() where jobid='{$wyyuser[0]}'");
	}
//$output = sendmsg($ids,$content);
//exit("Cron_Success: ".date("Y-m-d H:i:s"));
print_r($output);