<?php
$Model = 'blank';
include '../Cores/common.php';
echo "<title>步数任务执行结果</title>";
$stepusers = getstepjob(dailystep);
foreach ($stepusers as $stepuser){
	$url = "$stepapi/Api/Step/step.php?startstep=$stepuser[7]&endstep=$stepuser[8]&stepuserid=$stepuser[3]&stepapptoken=$stepuser[9]";
	$output = curl_get($url);
    $result=json_decode($output,true);
	$time = $stepuser[12]+1;
	$DB->query("update saves_stepjob set times='{$time}',lasttime=Now() where jobid='{$stepuser[0]}'");
    if($result['code']==1){
        $result = "Cron_Success : Task Success : ".date("Y-m-d H:i:s");
    }elseif($result['code'==2]){
        $DB->query("update saves_stepjob set cookiezt='1' where jobid='{$stepuser[0]}'");
        $DB->query("update saves_step set cookiezt='1' where jobid='{$stepuser[0]}'");
        $result = "Need Update Apptoken : ".date("Y-m-d H:i:s");
    }
}
echo($result);
?>