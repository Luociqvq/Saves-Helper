<?php
/*
 * 网易云信息更新监控文件
 * Author：Luoci
 * Date:2022/1/12
 */
 
$Model = 'blank';
include '../Cores/common.php';
echo "<title>网易云信息更新结果</title>";
$wyyusers = getwyyjob(wyyinfoupdate);
$ids = [];
foreach ($wyyusers as $wyyuser){
	$row = $DB->get_row("select * from saves_wyy where wyyuserid='$wyyuser[3]' limit 1");
	$tellphone = $row['tellphone'];
	$password = base16_decode($row['password']);
	$url = "$wyyapi/Api/Music/login.php?uin=$tellphone&pwd=$password";
	$loginoutput = curl_jsonget($url,$cookie);
	$wyyuserid = $loginoutput['wyyuserid'];
	$wyyavatarUrl = $loginoutput['wyyavatarUrl'];
	$wyynickname = $loginoutput['wyynickname'];
	$wyysignature = $loginoutput['wyysignature'];
	$MUSIC_U = $loginoutput['MUSIC_U'];
	$__csrf = $loginoutput['__csrf'];
	$levelurl = "$wyyapi/Api/Music/level.php";
	$cookie = "__csrf=".$wyyuser[10].";MUSIC_U=".$wyyuser[9]."";
	$leveloutput = curl_jsonget($levelurl,$cookie);	
	$wyylevel = $leveloutput['data']['level'];
	$wyyleveldays =$leveloutput['data']['nextLoginCount'] - $leveloutput['data']['nowLoginCount']; 
	$wyylevelsongs = $leveloutput['data']['nextPlayCount'] - $leveloutput['data']['nowPlayCount'];
	$time = $wyyuser[11]+1;
	$DB->query("update saves_wyy set MUSIC_U='{$MUSIC_U}',__csrf='{$__csrf}',wyyavatarUrl='{$wyyavatarUrl}',wyynickname='{$wyynickname}',wyysignature='{$wyysignature}',wyylevel='{$wyylevel}',wyylevelsongs='{$wyylevelsongs}',wyyleveldays='{$wyyleveldays}' where tellphone='{$tellphone}'");
	$DB->query("update saves_wyyjob set times='{$time}',lasttime=Now() where jobid='{$wyyuser[0]}'");
	}
exit("Cron_Success: ".date("Y-m-d H:i:s"));