<?php
/*
 * 网易云完成合伙人评分监控文件
 * Author：Luoci
 * Date:2022/2/12
 */
 
$Model = 'blank';
include '../Cores/common.php';
echo "<title>网易云完成合伙人评分结果</title>";
$wyyusers = getwyyjob(evaluate);
foreach ($wyyusers as $wyyuser){
	$url = "$wyyapi/Api/Music/evaluate.php";
	$cookie = "__csrf=".$wyyuser[10].";MUSIC_U=".$wyyuser[9]."";
	$output = curl_jsonget($url,$cookie);
	$time = $wyyuser[11]+1;
	$DB->query("update saves_wyyjob set times='{$time}',lasttime=Now() where jobid='{$wyyuser[0]}'");
	}
//exit("Cron_Success: ".date("Y-m-d H:i:s"));
print_r($output);